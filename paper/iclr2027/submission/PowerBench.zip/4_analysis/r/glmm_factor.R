args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_factor.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$ps <- as.integer(d$mode != "control")
d$xps <- d$x * d$ps
d$mode_he <- as.integer(d$mode == "he")
d$mode_de <- as.integer(d$mode == "de")

fits <- list()
for (md in c("he", "de", "pg", "control")) {
  dd <- droplevels(d[d$mode == md, ])
  fits[[paste0("A_", md)]] <- one(paste0("A_", md), dd,
    list(refuse ~ x + (1 + x || model) + (1 | prompt_id), refuse ~ x + (1 + x | model) + (1 | prompt_id)),
    "x", slope = "x")
}
dd <- droplevels(d[d$mode %in% c("he", "de", "pg"), ])
dd$mode <- relevel(factor(dd$mode), ref = "pg")
fits[["B_power_shifting"]] <- one("B_power_shifting", dd,
  list(refuse ~ x + mode + (1 + x || model) + (1 | prompt_id), refuse ~ x + mode + (1 + x | model) + (1 | prompt_id)),
  "x", slope = "x")

fits[["E_ps_vs_control"]] <- one("E_ps_vs_control", d,
  list(refuse ~ x * ps + mode_he + mode_de + (1 + x + ps + xps || model) + (1 | prompt_id),
       refuse ~ x * ps + mode_he + mode_de + (1 + x + ps + xps | model) + (1 | prompt_id)),
  "x:ps", slope = "xps")
for (md in c("he", "de", "pg")) {
  dd <- droplevels(d[d$mode %in% c(md, "control"), ])
  fits[[paste0("F_", md, "_vs_control")]] <- one(paste0("F_", md, "_vs_control"), dd,
    list(refuse ~ x * ps + (1 + x + ps + xps || model) + (1 | prompt_id),
         refuse ~ x * ps + (1 + x + ps + xps | model) + (1 | prompt_id)),
    "x:ps", slope = "xps")
}
finish(fits, args[2])
