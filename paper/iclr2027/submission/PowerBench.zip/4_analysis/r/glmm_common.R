suppressPackageStartupMessages(library(lme4))

optimizers <- list(
  list(name = "bobyqa",     ctrl = glmerControl(optimizer = "bobyqa")),
  list(name = "nlminbwrap", ctrl = glmerControl(optimizer = "nlminbwrap"))
)
msgs_of <- function(m) unlist(m@optinfo$conv$lme4$messages)
is_sing_msg <- function(x) grepl("singular", x, fixed = TRUE)
clean <- function(m) { x <- msgs_of(m); length(x[!is_sing_msg(x)]) == 0 }

NAGQ <- 1L
fit_any <- function(formulas, dd) {
  for (fi in seq_along(formulas)) {
    for (o in optimizers) {
      m <- suppressWarnings(glmer(formulas[[fi]], data = dd, family = binomial, control = o$ctrl, nAGQ = NAGQ))
      if (clean(m)) return(list(m = m, optimizer = o$name, variant = fi))
    }
  }
  list(m = m, optimizer = o$name, variant = fi)
}

vc_sd <- function(m, grp, var1, var2 = NA) {
  vc <- as.data.frame(VarCorr(m))
  sel <- (vc$grp == grp | grepl(paste0("^", grp, ".[0-9]+$"), vc$grp)) & !is.na(vc$var1) & vc$var1 == var1 &
    (if (is.na(var2)) is.na(vc$var2) else !is.na(vc$var2) & vc$var2 == var2)
  if (any(sel, na.rm = TRUE)) vc$sdcor[which(sel)[1]] else NA_real_
}

one <- function(key, dd, fulls, term, slope = NULL) {
  res <- tryCatch({
    f1 <- fit_any(fulls, dd); m <- f1$m
    s <- summary(m)$coefficients
    data.frame(fit = key, term = rownames(s), estimate = s[, "Estimate"], se = s[, "Std. Error"],
               z = s[, "z value"], p = s[, "Pr(>|z|)"],
               sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), sd_model = vc_sd(m, "model", "(Intercept)"),
               sd_model_slope = if (is.null(slope)) NA_real_ else vc_sd(m, "model", slope),
               cor_model_int_slope = if (is.null(slope)) NA_real_ else vc_sd(m, "model", "(Intercept)", slope),
               slope_name = if (is.null(slope)) "" else slope,
               singular = isSingular(m), messages = paste(msgs_of(m), collapse = " | "),
               optimizer = f1$optimizer, formula_used = paste(deparse(fulls[[f1$variant]]), collapse = ""),
               variant = f1$variant, loglik = as.numeric(logLik(m)), nobs = nobs(m),
               n_prompts = nlevels(droplevels(dd$prompt_id)), n_models = nlevels(droplevels(dd$model)),
               term_interest = term, error = "", row.names = NULL, stringsAsFactors = FALSE)
  }, error = function(e) {
    data.frame(fit = key, term = NA, estimate = NA, se = NA, z = NA, p = NA, sd_prompt = NA, sd_model = NA,
               sd_model_slope = NA, cor_model_int_slope = NA, slope_name = if (is.null(slope)) "" else slope,
               singular = NA, messages = "", optimizer = NA, formula_used = NA, variant = NA,
               loglik = NA, nobs = nrow(dd),
               n_prompts = nlevels(droplevels(dd$prompt_id)), n_models = nlevels(droplevels(dd$model)),
               term_interest = term, error = conditionMessage(e), row.names = NULL, stringsAsFactors = FALSE)
  })
  res
}

finish <- function(fits, outfile) {
  out <- do.call(rbind, fits)
  out$lme4_version <- as.character(packageVersion("lme4"))
  out$r_version <- R.version.string
  write.csv(out, outfile, row.names = FALSE)
}

read_input <- function(infile) {
  d <- read.csv(infile, stringsAsFactors = FALSE)
  d$model <- factor(d$model)
  d$prompt_id <- factor(d$prompt_id)
  d
}
