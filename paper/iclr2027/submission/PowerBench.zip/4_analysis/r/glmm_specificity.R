args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_specificity.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$mt <- d$m * d$t

fit_test <- function(key, dd) {
  t0 <- proc.time()[["elapsed"]]
  kind <- dd$kind[1]
  dd$dyad <- factor(dd$dyad)
  has_dyad <- nlevels(dd$dyad) > 1
  has_mode <- any(dd$mode_he != 0) || any(dd$mode_de != 0)
  md <- if (has_mode) "+ mode_he + mode_de" else ""
  if (kind == "inter") {
    fe <- paste("refuse ~ m * t", if (has_dyad) "+ dyad * t" else "", md)
    re <- c("+ (1 + m + t + mt || model) + (1 | prompt_id)", "+ (1 + m + t + mt | model) + (1 | prompt_id)")
    slope <- "mt"
  } else if (kind == "diff2") {
    fe <- paste("refuse ~ m + m2", md)
    re <- c("+ (1 + m + m2 || model) + (1 | prompt_id)", "+ (1 + m + m2 | model) + (1 | prompt_id)")
    slope <- "m"
  } else if (kind == "counterpart") {
    fe <- "refuse ~ m + m2 + dyad"
    re <- c("+ (1 + m + m2 || model) + (1 | prompt_id)", "+ (1 + m + m2 | model) + (1 | prompt_id)")
    slope <- "m2"
  } else stop("unknown kind: ", kind)
  fl <- lapply(re, function(r) as.formula(paste(fe, r)))
  f1 <- fit_any(fl, dd); m <- f1$m
  b <- fixef(m); V <- as.matrix(vcov(m))
  lc <- function(w) {
    est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w)); c(est, se)
  }
  q <- if (kind == "inter") rbind("interaction" = lc(c("m:t" = 1)), "slope_reference" = lc(c("m" = 1)),
                                  "slope_target" = lc(c("m" = 1, "m:t" = 1)))
       else if (kind == "diff2") rbind("difference" = lc(c("m" = 1, "m2" = -1)), "slope_m" = lc(c("m" = 1)), "slope_m2" = lc(c("m2" = 1)))
       else rbind("interaction" = lc(c("m2" = 1)), "slope_common" = lc(c("m" = 1)))
  el <- proc.time()[["elapsed"]] - t0
  data.frame(test = key, kind = kind, quantity = rownames(q), estimate = q[, 1], se = q[, 2], z = q[, 1] / q[, 2],
             p = 2 * pnorm(-abs(q[, 1] / q[, 2])),
             sd_model_slope = vc_sd(m, "model", slope), sd_model = vc_sd(m, "model", "(Intercept)"),
             sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), singular = isSingular(m),
             messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer, variant = f1$variant,
             formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m),
             n_prompts = nlevels(droplevels(dd$prompt_id)), n_models = nlevels(droplevels(dd$model)),
             nagq = NAGQ, seconds = el, row.names = NULL, stringsAsFactors = FALSE)
}

fits <- list()
for (k in unique(as.character(d$test))) fits[[k]] <- fit_test(k, droplevels(d[d$test == k, ]))
finish(fits, args[2])
