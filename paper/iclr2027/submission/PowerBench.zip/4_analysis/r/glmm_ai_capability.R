args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) stop("usage: Rscript glmm_ai_capability.R <input.csv> <output.csv> <bymode|pooled>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
what <- args[3]

fit_cap <- function(key, dd, rhs, quants) {
  t0 <- proc.time()[["elapsed"]]
  f <- function(corr) as.formula(paste("refuse ~", rhs, if (corr) "+ (1 + ai | model)" else "+ (1 + ai || model)", "+ (1 | prompt_id)"))
  f1 <- fit_any(list(f(FALSE), f(TRUE)), dd); m <- f1$m
  b <- fixef(m); V <- as.matrix(vcov(m))
  lc <- function(w) {
    est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w)); c(est, se)
  }
  q <- t(sapply(quants, lc))
  el <- proc.time()[["elapsed"]] - t0
  out <- data.frame(fit = key, quantity = names(quants), estimate = q[, 1], se = q[, 2], z = q[, 1] / q[, 2],
                    p = 2 * pnorm(-abs(q[, 1] / q[, 2])),
                    sd_model_slope = vc_sd(m, "model", "ai"), sd_model = vc_sd(m, "model", "(Intercept)"),
                    sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), singular = isSingular(m),
                    messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer, variant = f1$variant,
                    formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m), n_models = nlevels(droplevels(dd$model)),
                    seconds = el, row.names = NULL, stringsAsFactors = FALSE)
  out
}

fits <- list()
if (what == "bymode") {
  for (md in c("he", "de", "pg", "control")) {
    dd <- droplevels(d[d$mode == md, ])
    x <- fit_cap(paste0("cap__", md), dd, "ai * cap_z",
                 list("ai (mean capability)" = c("ai" = 1), "ai x capability (per 1 SD)" = c("ai:cap_z" = 1)))
    x$set <- md; fits[[md]] <- x
  }
} else {
  dps <- droplevels(d[d$ps == 1, ]); dps$mode <- factor(dps$mode)
  x <- fit_cap("cap__power_shifting", dps, "ai * cap_z + mode",
               list("ai (mean capability)" = c("ai" = 1), "ai x capability (per 1 SD)" = c("ai:cap_z" = 1)))
  x$set <- "power_shifting"; fits[["ps"]] <- x
  dct <- droplevels(d[d$ps == 0, ])
  x <- fit_cap("cap__control", dct, "ai * cap_z",
               list("ai (mean capability)" = c("ai" = 1), "ai x capability (per 1 SD)" = c("ai:cap_z" = 1)))
  x$set <- "control"; fits[["ct"]] <- x
  dall <- droplevels(d); dall$mode <- factor(dall$mode)
  x <- fit_cap("cap__stacked", dall, "ai * cap_z * ps + mode",
               list("ai x capability, control" = c("ai:cap_z" = 1),
                    "ai x capability, power-shifting" = c("ai:cap_z" = 1, "ai:cap_z:ps" = 1),
                    "slope difference (ps - control)" = c("ai:cap_z:ps" = 1)))
  x$set <- "stacked"; fits[["all"]] <- x
}
finish(fits, args[2])
