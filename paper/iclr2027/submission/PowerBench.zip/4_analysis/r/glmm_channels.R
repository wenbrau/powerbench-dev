args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_channels.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

G <- c("US", "USal", "neu", "CNal", "CN")
K <- length(G)
d <- read_input(args[1])
d$ugrp <- factor(d$ugrp, levels = G); contrasts(d$ugrp) <- contr.sum(K)
d$tgrp <- factor(d$tgrp, levels = G); contrasts(d$tgrp) <- contr.sum(K)
d$model_u <- factor(paste(d$model, d$ugrp, sep = ":"))
d$model_t <- factor(paste(d$model, d$tgrp, sep = ":"))

L <- rbind(diag(K - 1), rep(-1, K - 1))
W <- rbind(CN_minus_US = c(-1, 0, 0, 0, 1),
           bloc_CN_minus_US = c(-.5, -.5, 0, .5, .5))

summarise_channel <- function(b, V, idx, channel, md, meta) {
  bb <- b[idx]; Vb <- V[idx, idx]
  chi <- as.numeric(t(bb) %*% solve(Vb) %*% bb)
  dev <- as.numeric(L %*% bb); dse <- sqrt(diag(L %*% Vb %*% t(L)))
  out <- data.frame(mode = md, channel = channel, quantity = paste0("dev_", G), estimate = dev, se = dse,
                    z = dev / dse, p = 2 * pnorm(-abs(dev / dse)), chisq = NA, df = NA, stringsAsFactors = FALSE)
  for (w in rownames(W)) {
    lw <- as.numeric(W[w, ] %*% L); est <- sum(lw * bb); se <- sqrt(as.numeric(t(lw) %*% Vb %*% lw))
    out <- rbind(out, data.frame(mode = md, channel = channel, quantity = w, estimate = est, se = se, z = est / se,
                                 p = 2 * pnorm(-abs(est / se)), chisq = NA, df = NA, stringsAsFactors = FALSE))
  }
  out <- rbind(out, data.frame(mode = md, channel = channel, quantity = "omnibus", estimate = NA, se = NA, z = NA,
                               p = pchisq(chi, K - 1, lower.tail = FALSE), chisq = chi, df = K - 1, stringsAsFactors = FALSE))
  cbind(out, meta)
}

fit_mode <- function(md, dd) {
  t0 <- Sys.time()
  re <- c("(1 | model) + (1 | model_u) + (1 | model_t) + (1 | prompt_id)", "(1 | model) + (1 | prompt_id)")
  tryCatch({
    f1 <- fit_any(lapply(re, function(r) as.formula(paste("refuse ~ ugrp + tgrp +", r))), dd); m <- f1$m
    secs <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
    b <- fixef(m); V <- as.matrix(vcov(m)); nm <- names(b)
    meta <- data.frame(singular = isSingular(m), messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer,
                       variant = f1$variant, formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m),
                       n_prompts = nlevels(droplevels(dd$prompt_id)), n_models = nlevels(droplevels(dd$model)),
                       sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), sd_model = vc_sd(m, "model", "(Intercept)"),
                       sd_model_u = vc_sd(m, "model_u", "(Intercept)"), sd_model_t = vc_sd(m, "model_t", "(Intercept)"),
                       seconds = secs, error = "", stringsAsFactors = FALSE)
    rbind(summarise_channel(b, V, grep("^ugrp[0-9]+$", nm), "user", md, meta),
          summarise_channel(b, V, grep("^tgrp[0-9]+$", nm), "target", md, meta))
  }, error = function(e) {
    data.frame(mode = md, channel = NA, quantity = NA, estimate = NA, se = NA, z = NA, p = NA, chisq = NA, df = NA,
               singular = NA, messages = "", optimizer = NA, variant = NA, formula_used = NA, nobs = nrow(dd),
               n_prompts = NA, n_models = NA, sd_prompt = NA, sd_model = NA, sd_model_u = NA, sd_model_t = NA,
               seconds = as.numeric(difftime(Sys.time(), t0, units = "secs")), error = conditionMessage(e),
               stringsAsFactors = FALSE)
  })
}

fits <- list()
for (md in c("he", "de", "pg", "control")) {
  if (!any(d$mode == md)) next
  dd <- droplevels(d[d$mode == md, ])
  contrasts(dd$ugrp) <- contr.sum(K); contrasts(dd$tgrp) <- contr.sum(K)
  fits[[md]] <- fit_mode(md, dd)
}
finish(fits, args[2])
