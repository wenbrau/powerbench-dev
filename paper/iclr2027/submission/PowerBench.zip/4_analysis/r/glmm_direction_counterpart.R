args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_direction_counterpart.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
DY <- c("us_ally", "us_rival", "us_neutral", "us_cn")

rows <- list()
for (md in unique(d$mode)) {
  t0 <- proc.time()[["elapsed"]]
  dd <- droplevels(d[d$mode == md, ]); dd$dyad <- factor(dd$dyad, levels = DY)
  f <- function(corr) as.formula(paste("refuse ~ 0 + dyad + dyad:toward + origin_c + toward:origin_c",
        if (corr) "+ (1 + toward | model)" else "+ (1 + toward || model)", "+ (1 | prompt_id)"))
  f1 <- fit_any(list(f(FALSE), f(TRUE)), dd); m <- f1$m
  b <- fixef(m); V <- as.matrix(vcov(m))
  tw <- function(k) paste0("dyad", k, ":toward")
  lc <- function(w) { est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w)); c(est, se) }
  w_of <- function(pos, negs) { w <- c(1, rep(-1 / length(negs), length(negs))); names(w) <- tw(c(pos, negs)); w }
  q <- rbind(
    "direction us_ally"               = lc(setNames(1, tw("us_ally"))),
    "direction us_rival"              = lc(setNames(1, tw("us_rival"))),
    "direction us_neutral"            = lc(setNames(1, tw("us_neutral"))),
    "direction us_cn"                 = lc(setNames(1, tw("us_cn"))),
    "China - ally"                    = lc(w_of("us_cn", "us_ally")),
    "China - rival"                   = lc(w_of("us_cn", "us_rival")),
    "China - neutral"                 = lc(w_of("us_cn", "us_neutral")),
    "China - mean of the other three" = lc(w_of("us_cn", c("us_ally", "us_rival", "us_neutral"))))
  el <- proc.time()[["elapsed"]] - t0
  rows[[md]] <- data.frame(mode = md, quantity = rownames(q), estimate = q[, 1], se = q[, 2], z = q[, 1] / q[, 2],
                           p = 2 * pnorm(-abs(q[, 1] / q[, 2])),
                           sd_model_slope = vc_sd(m, "model", "toward"), sd_model = vc_sd(m, "model", "(Intercept)"),
                           sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), singular = isSingular(m),
                           messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer, variant = f1$variant,
                           formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m), seconds = el,
                           row.names = NULL, stringsAsFactors = FALSE)
}
finish(rows, args[2])
