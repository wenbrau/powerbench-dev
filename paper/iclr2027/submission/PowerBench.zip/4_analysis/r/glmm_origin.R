args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_origin.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$ps <- as.integer(d$mode != "control")
d$mode_he <- as.integer(d$mode == "he")
d$mode_de <- as.integer(d$mode == "de")

fits <- list()
for (md in c("he", "de", "pg", "control")) {
  dd <- droplevels(d[d$mode == md, ])
  fits[[paste0("A_", md)]] <- one(paste0("A_", md), dd, list(refuse ~ cn + (1 | prompt_id) + (1 | model)), "cn")
  fits[[paste0("C_", md)]] <- one(paste0("C_", md), dd, list(refuse ~ cn + cap_z + (1 | prompt_id) + (1 | model)), "cn")
}
dd <- droplevels(d[d$mode %in% c("he", "de", "pg"), ])
dd$mode <- relevel(factor(dd$mode), ref = "pg")
fits[["B_power_shifting"]] <- one("B_power_shifting", dd, list(refuse ~ cn + mode + (1 | prompt_id) + (1 | model)), "cn")
fits[["D_power_shifting"]] <- one("D_power_shifting", dd, list(refuse ~ cn + cap_z + mode + (1 | prompt_id) + (1 | model)), "cn")

fits[["E_ps_vs_control"]] <- one("E_ps_vs_control", d,
  list(refuse ~ cn * ps + mode_he + mode_de + (1 + ps || model) + (1 | prompt_id),
       refuse ~ cn * ps + mode_he + mode_de + (1 + ps | model) + (1 | prompt_id)), "cn:ps", slope = "ps")
for (md in c("he", "de", "pg")) {
  dd <- droplevels(d[d$mode %in% c(md, "control"), ])
  fits[[paste0("F_", md, "_vs_control")]] <- one(paste0("F_", md, "_vs_control"), dd,
    list(refuse ~ cn * ps + (1 + ps || model) + (1 | prompt_id),
         refuse ~ cn * ps + (1 + ps | model) + (1 | prompt_id)), "cn:ps", slope = "ps")
}
finish(fits, args[2])
