args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_modes.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
fits <- list()
for (pair in list(c("he", "de"), c("de", "pg"))) {
  key <- paste0(pair[1], "_vs_", pair[2])
  dd <- droplevels(d[d$mode %in% pair, ])
  dd$m2 <- as.integer(dd$mode == pair[2])
  fits[[key]] <- one(key, dd,
    list(refuse ~ m2 + (1 + m2 || model) + (1 | prompt_id),
         refuse ~ m2 + (1 + m2 | model) + (1 | prompt_id)), "m2", slope = "m2")
}
finish(fits, args[2])
