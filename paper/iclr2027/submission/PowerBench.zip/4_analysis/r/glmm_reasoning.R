args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_reasoning.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$r1 <- as.integer(d$level == "r1"); d$r2 <- as.integer(d$level == "r2")
d$mode <- factor(d$mode, levels = c("he", "de", "pg", "ctl")); contrasts(d$mode) <- contr.sum(4)
d$origin <- factor(d$origin, levels = c("US", "CN")); contrasts(d$origin) <- contr.sum(2)

t0 <- proc.time()[["elapsed"]]
f <- function(corr) as.formula(paste("refuse ~ (r1 + r2) * (mode + origin)",
                                     if (corr) "+ (1 + r1 + r2 | model)" else "+ (1 + r1 + r2 || model)", "+ (1 | prompt_id)"))
f1 <- fit_any(list(f(FALSE), f(TRUE)), d); m <- f1$m
b <- fixef(m); V <- as.matrix(vcov(m))
lc <- function(w) {
  est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w)); c(est, se)
}
wald <- function(terms) { bb <- b[terms]; as.numeric(t(bb) %*% solve(V[terms, terms]) %*% bb) }
mode_w <- list(he = c(1, 0, 0), de = c(0, 1, 0), pg = c(0, 0, 1), ctl = c(-1, -1, -1))
orig_w <- list(US = 1, CN = -1)
q <- list()
for (r in c("r1", "r2")) {
  q[[paste0(r, " (mean)")]] <- lc(setNames(1, r))
  for (o in names(orig_w)) q[[paste0(r, " in models ", o)]] <- lc(setNames(c(1, orig_w[[o]]), c(r, paste0(r, ":origin1"))))
  q[[paste0(r, " x origin (US - CN)")]] <- lc(setNames(2, paste0(r, ":origin1")))
  for (md in names(mode_w)) {
    w <- mode_w[[md]]
    q[[paste0(r, " in ", md)]] <- lc(setNames(c(1, w), c(r, paste0(r, ":mode", 1:3))))
  }
  q[[paste0(r, " in pg - in ctl")]] <- lc(setNames(c(mode_w$pg - mode_w$ctl), paste0(r, ":mode", 1:3)))
  q[[paste0(r, " in de - in ctl")]] <- lc(setNames(c(mode_w$de - mode_w$ctl), paste0(r, ":mode", 1:3)))
  q[[paste0(r, " in he - in ctl")]] <- lc(setNames(c(mode_w$he - mode_w$ctl), paste0(r, ":mode", 1:3)))
}
Q <- t(sapply(q, identity))
om <- rbind("omnibus level (r1, r2)" = c(wald(c("r1", "r2")), 2),
            "omnibus level x origin" = c(wald(c("r1:origin1", "r2:origin1")), 2),
            "omnibus level x type" = c(wald(c(paste0("r1:mode", 1:3), paste0("r2:mode", 1:3))), 6))
el <- proc.time()[["elapsed"]] - t0
out <- rbind(
  data.frame(quantity = rownames(Q), kind = "contrast", estimate = Q[, 1], se = Q[, 2], z = Q[, 1] / Q[, 2],
             p = 2 * pnorm(-abs(Q[, 1] / Q[, 2])), df = NA_real_, row.names = NULL, stringsAsFactors = FALSE),
  data.frame(quantity = rownames(om), kind = "omnibus", estimate = om[, 1], se = NA_real_, z = NA_real_,
             p = pchisq(om[, 1], df = om[, 2], lower.tail = FALSE), df = om[, 2], row.names = NULL, stringsAsFactors = FALSE))
out$sd_model <- vc_sd(m, "model", "(Intercept)"); out$sd_model_r1 <- vc_sd(m, "model", "r1"); out$sd_model_r2 <- vc_sd(m, "model", "r2")
out$sd_prompt <- vc_sd(m, "prompt_id", "(Intercept)"); out$singular <- isSingular(m)
out$messages <- paste(msgs_of(m), collapse = " | "); out$optimizer <- f1$optimizer; out$variant <- f1$variant
out$formula_used <- paste(deparse(formula(m)), collapse = ""); out$nobs <- nobs(m)
out$n_models <- nlevels(droplevels(d$model)); out$n_prompts <- nlevels(droplevels(d$prompt_id)); out$seconds <- el
out$lme4_version <- as.character(packageVersion("lme4")); out$r_version <- R.version.string
write.csv(out, args[2], row.names = FALSE)
