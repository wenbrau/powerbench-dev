args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) stop("usage: Rscript glmm_direction.R <input.csv> <output.csv> [joint|bydyad]")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])

fit_dir <- function(key, dd, with_dyad) {
  t0 <- proc.time()[["elapsed"]]
  dy <- if (with_dyad) "+ dyad" else ""
  f <- function(corr) as.formula(paste("refuse ~ toward * origin_c", dy,
        if (corr) "+ (1 + toward | model)" else "+ (1 + toward || model)", "+ (1 | prompt_id)"))
  f1 <- fit_any(list(f(FALSE), f(TRUE)), dd); m <- f1$m
  b <- fixef(m); V <- as.matrix(vcov(m))
  lc <- function(w) {
    est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w))
    c(est, se)
  }
  q <- rbind(
    "direction (24 models)"        = lc(c("toward" = 1)),
    "direction, US models"         = lc(c("toward" = 1, "toward:origin_c" = -0.5)),
    "direction, CN models"         = lc(c("toward" = 1, "toward:origin_c" =  0.5)),
    "direction x origin (CN - US)"  = lc(c("toward:origin_c" = 1)))
  el <- proc.time()[["elapsed"]] - t0
  out <- data.frame(fit = key, quantity = rownames(q), estimate = q[, 1], se = q[, 2], z = q[, 1] / q[, 2],
                    p = 2 * pnorm(-abs(q[, 1] / q[, 2])),
                    sd_model_slope = vc_sd(m, "model", "toward"), sd_model = vc_sd(m, "model", "(Intercept)"),
                    sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), singular = isSingular(m),
                    messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer, variant = f1$variant,
                    formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m), seconds = el,
                    row.names = NULL, stringsAsFactors = FALSE)
  out
}

fits <- list()
what <- if (length(args) >= 3) args[3] else "joint"
for (md in unique(d$mode)) {
  for (pl in c("usa", "china")) {
    if (what == "joint") {
      dd <- droplevels(d[d$mode == md & d$pole == pl, ]); dd$dyad <- factor(dd$dyad)
      x <- fit_dir(paste(md, pl, "all", sep = "__"), dd, TRUE); x$mode <- md; x$pole <- pl; x$dyad <- "all"
      fits[[paste(md, pl, "all")]] <- x
    } else {
      for (dyd in unique(d$dyad[d$pole == pl])) {
        dd <- droplevels(d[d$mode == md & d$pole == pl & d$dyad == dyd, ])
        x <- fit_dir(paste(md, pl, dyd, sep = "__"), dd, FALSE); x$mode <- md; x$pole <- pl; x$dyad <- dyd
        fits[[paste(md, pl, dyd)]] <- x
      }
    }
  }
}
finish(fits, args[2])
