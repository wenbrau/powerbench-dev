args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_ai_origin.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$us <- 1L - d$cn
fits <- list()
for (md in c("he", "de", "pg", "control")) {
  dd <- droplevels(d[d$mode == md, ])
  f <- function(rhs, corr = FALSE)
    as.formula(paste("refuse ~", rhs, if (corr) "+ (1 + ai | model)" else "+ (1 + ai || model)", "+ (1 | prompt_id)"))
  r1 <- one(paste0("ai__", md), dd, list(f("ai"), f("ai", TRUE)), "ai", slope = "ai")
  r2 <- one(paste0("ai_origin_US__", md), dd, list(f("ai * cn"), f("ai * cn", TRUE)), "ai:cn", slope = "ai")
  r3 <- one(paste0("ai_origin_CN__", md), dd, list(f("ai * us"), f("ai * us", TRUE)), "ai", slope = "ai")
  for (nm in c("r1", "r2", "r3")) { x <- get(nm); x$mode <- md; fits[[paste(nm, md)]] <- x }
}
finish(fits, args[2])
