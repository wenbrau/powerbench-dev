args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_side.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$us <- 1L - d$cn
fits <- list()
for (st in c("geo", "neutral")) {
  for (md in c("he", "de", "pg", "control")) {
    dd <- droplevels(d[d$set == st & d$mode == md, ])
    dd$dyad <- factor(dd$dyad)
    dy <- if (st == "geo") "+ dyad" else ""
    f <- function(rhs, corr = FALSE)
      as.formula(paste("refuse ~", rhs, dy, if (corr) "+ (1 + side | model)" else "+ (1 + side || model)", "+ (1 | prompt_id)"))
    k <- paste(st, md, sep = "_")
    r1 <- one(paste0("side__", k), dd, list(f("side"), f("side", TRUE)), "side", slope = "side")
    r2 <- one(paste0("side_origin_US__", k), dd, list(f("side * cn"), f("side * cn", TRUE)), "side:cn", slope = "side")
    r3 <- one(paste0("side_origin_CN__", k), dd, list(f("side * us"), f("side * us", TRUE)), "side", slope = "side")
    for (nm in c("r1", "r2", "r3")) { x <- get(nm); x$set <- st; x$mode <- md; fits[[paste(nm, k)]] <- x }
  }
}
finish(fits, args[2])
