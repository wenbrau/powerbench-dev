args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) stop("usage: Rscript glmm_ai_level.R <input.csv> <output.csv> <comma-separated levels>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
levels_ <- strsplit(args[3], ",")[[1]]
d$level <- factor(d$level, levels = levels_)
fits <- list()
for (md in c("he", "de", "pg", "control")) {
  dd <- droplevels(d[d$mode == md, ])
  t0 <- proc.time()[["elapsed"]]
  f <- function(corr) as.formula(paste("refuse ~ ai * level", if (corr) "+ (1 + ai | model)" else "+ (1 + ai || model)", "+ (1 | prompt_id)"))
  f1 <- fit_any(list(f(FALSE), f(TRUE)), dd); m <- f1$m
  b <- fixef(m); V <- as.matrix(vcov(m))
  lc <- function(w) {
    est <- sum(w * b[names(w)]); se <- sqrt(as.numeric(t(w) %*% V[names(w), names(w)] %*% w))
    c(est, se)
  }
  L2 <- paste0("ai:level", levels_[2]); L3 <- paste0("ai:level", levels_[3])
  q <- rbind(
    "ai at level 1" = lc(c("ai" = 1)),
    "ai at level 2" = lc(setNames(c(1, 1), c("ai", L2))),
    "ai at level 3" = lc(setNames(c(1, 1), c("ai", L3))),
    "level 2 - level 1" = lc(setNames(1, L2)),
    "level 3 - level 1" = lc(setNames(1, L3)),
    "level 3 - level 2" = lc(setNames(c(1, -1), c(L3, L2))))
  bb <- b[c(L2, L3)]; W <- as.numeric(t(bb) %*% solve(V[c(L2, L3), c(L2, L3)]) %*% bb)
  el <- proc.time()[["elapsed"]] - t0
  out <- data.frame(fit = paste0("ai_level__", md), mode = md, quantity = c(rownames(q), "omnibus ai x level"),
                    estimate = c(q[, 1], W), se = c(q[, 2], NA), z = c(q[, 1] / q[, 2], NA),
                    p = c(2 * pnorm(-abs(q[, 1] / q[, 2])), pchisq(W, df = 2, lower.tail = FALSE)), df = c(rep(NA, nrow(q)), 2),
                    sd_model_slope = vc_sd(m, "model", "ai"), sd_model = vc_sd(m, "model", "(Intercept)"),
                    sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), singular = isSingular(m),
                    messages = paste(msgs_of(m), collapse = " | "), optimizer = f1$optimizer, variant = f1$variant,
                    formula_used = paste(deparse(formula(m)), collapse = ""), nobs = nobs(m), seconds = el,
                    level1 = levels_[1], level2 = levels_[2], level3 = levels_[3], row.names = NULL, stringsAsFactors = FALSE)
  fits[[md]] <- out
}
finish(fits, args[2])
