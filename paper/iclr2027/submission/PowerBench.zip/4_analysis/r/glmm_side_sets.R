args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_side_sets.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
fits <- list()
for (st in unique(d$set)) {
  for (md in c("he", "de", "pg", "control")) {
    dd <- droplevels(d[d$set == st & d$mode == md, ])
    dd$dyad <- factor(dd$dyad)
    dy <- if (nlevels(dd$dyad) > 1) "+ dyad" else ""
    f <- function(rhs, corr = FALSE)
      as.formula(paste("refuse ~", rhs, dy, if (corr) "+ (1 + side | model)" else "+ (1 + side || model)", "+ (1 | prompt_id)"))
    k <- paste(st, md, sep = "_")
    r1 <- one(paste0("side__", k), dd, list(f("side"), f("side", TRUE)), "side", slope = "side")
    r1$set <- st; r1$mode <- md
    fits[[k]] <- r1
  }
}
finish(fits, args[2])
