args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript glmm_baseline_panels.R <input.csv> <output.csv>")
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))
source(file.path(here, "glmm_common.R"))

d <- read_input(args[1])
d$mode <- factor(d$mode, levels = c("pg", "he", "de", "control"))
fits <- list()
fits$origin_all <- one("origin_all", d, list(refuse ~ cn + mode + (1 | prompt_id) + (1 | model)), "cn")

dev_fit <- function(key, dd, var, K) {
  dd[[var]] <- factor(dd[[var]], levels = 1:K)
  contrasts(dd[[var]]) <- contr.sum(K)
  dd$model_lv <- factor(paste(dd$model, dd[[var]], sep = ":"))
  fixed <- paste("refuse ~", var, "+ mode")
  fulls <- lapply(c("(1 | model) + (1 | model_lv) + (1 | prompt_id)", "(1 | model) + (1 | prompt_id)"),
                  function(re) as.formula(paste(fixed, "+", re)))
  t0 <- Sys.time()
  f1 <- fit_any(fulls, dd); m <- f1$m
  secs <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  s <- summary(m)$coefficients; V <- as.matrix(vcov(m))
  idx <- grep(paste0("^", var, "[0-9]+$"), rownames(s))
  b <- s[idx, "Estimate"]; Vb <- V[idx, idx]
  L <- rbind(diag(K - 1), rep(-1, K - 1))
  dev <- as.numeric(L %*% b); dse <- sqrt(diag(L %*% Vb %*% t(L)))
  dz <- dev / dse; dp <- 2 * pnorm(-abs(dz)); dbh <- p.adjust(dp, method = "BH")
  W <- as.numeric(t(b) %*% solve(Vb) %*% b)
  data.frame(fit = key, kind = c(rep("dev", K), "omnibus"), level = c(1:K, NA), estimate = c(dev, W), se = c(dse, NA), z = c(dz, NA),
             p = c(dp, pchisq(W, df = K - 1, lower.tail = FALSE)), p_bh = c(dbh, NA), df = c(rep(NA, K), K - 1),
             sd_prompt = vc_sd(m, "prompt_id", "(Intercept)"), sd_model = vc_sd(m, "model", "(Intercept)"),
             sd_model_level = if (f1$variant == 1) vc_sd(m, "model_lv", "(Intercept)") else NA_real_,
             singular = isSingular(m), optimizer = f1$optimizer, variant = f1$variant,
             formula_used = paste(deparse(fulls[[f1$variant]]), collapse = ""), messages = paste(msgs_of(m), collapse = " | "),
             fit_seconds = round(secs, 1), nobs = nobs(m), stringsAsFactors = FALSE)
}
dps <- droplevels(d[d$mode != "control", ])
dps$mode <- factor(dps$mode, levels = c("pg", "he", "de"))
ctx <- dev_fit("ctx_ps", dps, "ctx", 8)
dom <- dev_fit("dom_ps", dps, "dom", 8)
out <- rbind(ctx, dom)
out$lme4_version <- as.character(packageVersion("lme4")); out$r_version <- R.version.string
write.csv(out, paste0(args[2], ".dev.csv"), row.names = FALSE)
finish(fits, args[2])
