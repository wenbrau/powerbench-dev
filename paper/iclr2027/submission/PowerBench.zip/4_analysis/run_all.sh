#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
JOBS="${JOBS:-$(getconf _NPROCESSORS_ONLN)}"
PY="${PYTHON:-python}"

R_BLOCKS="analysis_30_ analysis_31_ analysis_32_ analysis_33_ analysis_36_ analysis_45_ analysis_46_
analysis_58_ analysis_60_ analysis_64_ analysis_68_ analysis_75_ analysis_78_ analysis_80_ analysis_82_
analysis_85_ analysis_86_ analysis_90_ analysis_93_ analysis_100_ analysis_101_ language/step1_glmm"

uses_r() {
  for b in $R_BLOCKS; do
    case "$1" in "$b"*) return 0 ;; esac
  done
  return 1
}

wave() {
  for s in "$@"; do
    if [ "${SKIP_R:-0}" = 1 ] && uses_r "$s"; then continue; fi
    printf '%s\n' "$s"
  done | xargs -P "$JOBS" -I{} sh -c "$PY 4_analysis/scripts/{}"
}

wave \
  analysis_09_judge_comparison_d1_english.py \
  analysis_10_judge_comparison_d1_languages.py \
  analysis_11_judge_comparison_d2_d3.py \
  analysis_18_reasoning_ladder.py \
  analysis_19_d1_english.py \
  analysis_20_d1_languages.py \
  analysis_21_d2_nationality.py \
  analysis_22_d3_ai_agent.py \
  analysis_25_baseline_rates.py \
  analysis_26_language_rates.py \
  analysis_30_baseline_glmm.py \
  "analysis_31_baseline_scale_standing_glmm.py --factor scale" \
  "analysis_31_baseline_scale_standing_glmm.py --factor standing" \
  analysis_32_baseline_context_glmm.py \
  analysis_33_baseline_domain_glmm.py \
  analysis_36_language_glmm.py \
  analysis_39_language_order_tests.py \
  analysis_45_nationality_side.py \
  analysis_46_nationality_direction_glmm.py \
  analysis_68_reasoning_glmm.py \
  analysis_69_reasoning_bias.py \
  analysis_72_language_usage_weighted.py \
  analysis_73_nationality_usage_weighted.py \
  analysis_79_language_pairwise_bias.py \
  analysis_81_language_rank_concordance.py \
  analysis_82_language_glmm_power_shifting.py \
  analysis_90_baseline_context_within_type_glmm.py \
  analysis_100_us_counterpart_contrast.py \
  analysis_101_nationality_channels.py \
  language/step0_excluded_models.py \
  language/step1_glmm.py \
  language/step2_concordance.py \
  language/step4_range_excess_pp.py \
  language/step6_deviation_bootstrap.py \
  language_all_models/range_excess_pp.py

wave \
  analysis_54_ai_agent_levels.py \
  analysis_55_nationality_side_excess.py \
  analysis_56_ai_agent_bias_direction.py \
  analysis_58_ai_agent_origin_glmm.py \
  analysis_59_ai_agent_by_dimension.py \
  analysis_61_ai_agent_scale_levels.py \
  analysis_70_baseline_model_mean_refusal.py \
  analysis_74_ai_agent_usage_weighted.py \
  analysis_75_nationality_by_pairing.py \
  analysis_85_ai_agent_glmm.py \
  analysis_86_nationality_power_shifting.py \
  analysis_88_pg_excess.py \
  analysis_89_bh_nationality_direction.py \
  analysis_94_pg_excess_logodds.py \
  language/step3_range_excess_bootstrap.py \
  language/step5_rank_agreement.py \
  language_all_models/range_excess_bootstrap.py \
  language_all_models/rank_agreement.py

wave \
  analysis_57_ai_agent_by_origin.py \
  analysis_93_specificity_interactions.py \
  analysis_98_language_range_permutation.py \
  analysis_60_ai_agent_level_glmm.py \
  analysis_62_ai_agent_capability.py \
  analysis_64_ai_agent_capability_glmm.py \
  analysis_76_ai_agent_direction_vs_control.py \
  analysis_77_bh_baseline_language.py \
  analysis_80_language_bias_vs_prevalence.py \
  analysis_91_nationality_specificity.py \
  language/step7_q_values.py

wave \
  analysis_78_baseline_panels.py \
  analysis_99_usage_weighted_without_luna.py \
  analysis_83_bh_ai_agent_nationality.py \
  analysis_84_ai_agent_capability_ivw.py

wave \
  analysis_87_model_rank_spearman.py \
  analysis_95_model_level_small_sample.py \
  analysis_96_capability_per_model.py

wave \
  analysis_97_intervals_capability_fits.py
