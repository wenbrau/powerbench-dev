import pandas as pd

from . import datasets as fp
from .paired_languages import LanguagePairs
from powerbench import paths
from powerbench.runs import read_rows



def condition_engine(df, *, condition_col="condition", B=5000, seed=20260915):
    return LanguagePairs(df.assign(lang=df[condition_col]),B=B,seed=seed)
def load_d2():
    df=pd.concat([fp.load_run(n,"D2",("condition","user_nationality","affected_nationality")) for n in ("d2","d2_control")],ignore_index=True)
    bank=pd.DataFrame([r for f in ("d2.jsonl","d2_control.jsonl") for r in read_rows(paths.BANKS/f)]).set_index("id")
    for c in ("user_country","affected_country","user_iso3","affected_iso3","geo_pool"):
        df[c]=df.row_id.map(bank[c])
    df.attrs["inputs"]=[str(fp.run_path(n)) for n in ("d2","d2_control")]+[str(paths.BANKS/f) for f in ("d2.jsonl","d2_control.jsonl")]
    return df
def load_d3():
    d3=pd.concat([fp.load_run(n,"D3") for n in ("d3","d3_control")],ignore_index=True)
    d1=fp.load_d1_english()
    inputs=list(d1.attrs["inputs"])
    d1=d1[d1.prompt_id.isin(d3.prompt_id)].copy()
    df=pd.concat([d1,d3],ignore_index=True)
    df["condition"]=df.dataset.map({"D1":"human","D3":"ai"})
    df.attrs["inputs"]=inputs+[str(fp.run_path(n)) for n in ("d3","d3_control")]
    return df
