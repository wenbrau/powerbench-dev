from __future__ import annotations

import numpy as np
import pandas as pd

from . import metrics
from .metrics import MODES


def ci(arr, level: float = 0.95) -> dict:
    arr = np.asarray(arr, float)
    est, draws = arr[0], arr[1:]
    draws = draws[np.isfinite(draws)]
    if draws.size == 0:
        return {"est": float(est), "lo": float("nan"), "hi": float("nan"), "p": float("nan"),
                "n_draws": 0}
    a = (1 - level) / 2
    lo, hi = np.quantile(draws, [a, 1 - a])
    p = 2 * min((draws <= 0).mean(), (draws >= 0).mean())
    return {"est": float(est), "lo": float(lo), "hi": float(hi), "p": float(min(1.0, p)),
            "n_draws": int(draws.size)}


class Boot:
    def __init__(self, df: pd.DataFrame, B: int = 3000, seed: int = 0, modes=None):
        d = df[df["valid"]].reset_index(drop=True)
        self.df = d
        self.B = int(B)
        self.seed = int(seed)
        self.modes = tuple(MODES if modes is None else modes)
        self.n = len(d)
        self._refuse = d["refuse"].to_numpy(float)
        self._mode = d["mode"].astype(str).to_numpy()
        rng = np.random.default_rng(seed)
        self._pidx, self._counts, self._nprompt = {}, {}, {}
        for m in self.modes:
            rows = np.flatnonzero(self._mode == m)
            prompts = d["prompt_id"].astype(str).to_numpy()[rows]
            uniq, inv = np.unique(prompts, return_inverse=True)
            k = len(uniq)
            idx = np.full(self.n, -1, dtype=np.int64)
            idx[rows] = inv
            self._pidx[m] = idx
            self._nprompt[m] = k
            if k:
                draws = rng.multinomial(k, np.full(k, 1.0 / k), size=self.B)
                self._counts[m] = np.vstack([np.ones((1, k)), draws]).astype(float)
            else:
                self._counts[m] = np.ones((self.B + 1, 0))

    def mask(self, **kw) -> np.ndarray:
        m = np.ones(self.n, dtype=bool)
        for col, val in kw.items():
            s = self.df[col].astype(str) if str(self.df[col].dtype) == "category" else self.df[col]
            if isinstance(val, (list, tuple, set, np.ndarray)):
                m &= s.isin([str(v) if str(self.df[col].dtype) == "category" else v for v in val]).to_numpy()
            else:
                m &= (s == (str(val) if str(self.df[col].dtype) == "category" else val)).to_numpy()
        return m

    def _rate(self, mask: np.ndarray, values: np.ndarray, mode: str) -> np.ndarray:
        sel = mask & (self._mode == mode) & np.isfinite(values)
        k = self._nprompt[mode]
        if k == 0 or not sel.any():
            return np.full(self.B + 1, np.nan)
        pid = self._pidx[mode][sel]
        s = np.bincount(pid, weights=values[sel], minlength=k)
        n = np.bincount(pid, minlength=k).astype(float)
        C = self._counts[mode]
        num, den = C @ s, C @ n
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(den > 0, num / den, np.nan)

    def rate(self, mask: np.ndarray, mode: str) -> np.ndarray:
        return self._rate(mask, self._refuse, mode)

    def rates(self, mask: np.ndarray) -> dict:
        return {m: self.rate(mask, m) for m in self.modes}

    def summary(self, mask: np.ndarray) -> dict:
        r = self.rates(mask)
        return metrics.summary(r["he"], r["de"], r["pg"])

    def n_rows(self, mask: np.ndarray) -> dict:
        return {m: int((mask & (self._mode == m)).sum()) for m in self.modes}

    def n_prompts(self, mask: np.ndarray) -> dict:
        return {m: int(len(np.unique(self._pidx[m][mask & (self._mode == m)]))) for m in self.modes}

    def table(self, groups: dict, stats=("he", "de", "pg", "components", "excess", "mean3"),
              pp: bool = True) -> pd.DataFrame:
        rows = []
        for name, m in groups.items():
            S = self.summary(m)
            np_ = self.n_prompts(m)
            rec = {"group": name, "prompts_he": np_["he"], "prompts_de": np_["de"],
                   "prompts_pg": np_["pg"], "rows": int(m.sum())}
            for s in stats:
                c = ci(S[s])
                f = 100.0 if pp else 1.0
                rec[s] = c["est"] * f
                rec[f"{s}_lo"] = c["lo"] * f
                rec[f"{s}_hi"] = c["hi"] * f
                if s == "excess":
                    rec["excess_p"] = c["p"]
            rows.append(rec)
        return pd.DataFrame(rows)

    def contrast(self, mask_a: np.ndarray, mask_b: np.ndarray,
                 stats=("pg", "excess", "he", "de", "mean3"), pp: bool = True) -> dict:
        SA, SB = self.summary(mask_a), self.summary(mask_b)
        out = {}
        f = 100.0 if pp else 1.0
        for s in stats:
            c = ci(SA[s] - SB[s])
            out[s] = {k: (v * f if k in ("est", "lo", "hi") else v) for k, v in c.items()}
        return out

    def contrast_table(self, pairs: dict, **kw) -> pd.DataFrame:
        rows = []
        for name, (a, b) in pairs.items():
            c = self.contrast(a, b, **kw)
            rec = {"contrast": name}
            for s, v in c.items():
                rec.update({s: v["est"], f"{s}_lo": v["lo"], f"{s}_hi": v["hi"], f"{s}_p": v["p"]})
            rows.append(rec)
        return pd.DataFrame(rows)
