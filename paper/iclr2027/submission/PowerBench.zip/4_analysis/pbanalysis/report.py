from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "4_analysis" / "results"


class Result:
    def __init__(self, name, results_dir=RESULTS):
        self.name = name
        self.dir = Path(results_dir) / name
        self._tables = []

    def table(self, name, df):
        self._tables.append((name, df))

    def write(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        for name, df in self._tables:
            df.to_csv(self.dir / f"{name}.csv", index=False, encoding="utf-8")
        return self.dir
