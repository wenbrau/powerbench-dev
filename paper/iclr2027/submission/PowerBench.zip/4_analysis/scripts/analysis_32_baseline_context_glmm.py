import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd

from pbanalysis import report
from pbanalysis.load import CONTEXTS
from pbanalysis.datasets import load_d1_english

NAME = "32_baseline_context_glmm"
POWER = ["he", "de", "pg"]
LABELS = {"he": "Self-empowerment", "de": "Disempowerment", "pg": "Power grabbing", "control": "Control"}
R_SCRIPT = HERE / "r" / "glmm_context.R"
FITS = [("E_ps_vs_control", "Power shifting (he + de + pg) vs control")] + \
       [(f"F_{m}_vs_control", f"{LABELS[m]} vs control") for m in POWER]


def find_rscript():
    exe = shutil.which("Rscript")
    if not exe:
        sys.exit("Rscript not found: install R and lme4.")
    return exe


def main():
    df = load_d1_english()
    d0 = df[df.valid].copy()
    d0["refuse"] = d0.refuse.astype(int)
    ctx_index = {c: i + 1 for i, c in enumerate(CONTEXTS)}
    d0["ctx"] = d0.context.map(ctx_index)
    assert d0.ctx.notna().all(), f"contexts outside {CONTEXTS}"

    rscript = find_rscript()
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        d0[["refuse", "mode", "prompt_id", "model", "ctx"]].to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout)], capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr)
            sys.exit(f"Rscript exited with code {proc.returncode}")
        o = pd.read_csv(fout)
    for col in ("messages", "error", "formula_used", "optimizer", "kind"):
        o[col] = o[col].fillna("").astype(str)

    res = report.Result(NAME)

    om_rows, dev_rows = [], []
    for key, label in FITS:
        g = o[o.fit == key]
        first = g.iloc[0]
        bad = [m for m in first.messages.split(" | ") if m and "singular" not in m]
        converged = first.error == "" and not bad and (g.kind == "omnibus").any()
        base = dict(fit=key, label=label, converged=converged, optimizer=first.optimizer, formula=first.formula_used,
                    variant=first.variant, n_rows=int(first.nobs), n_prompts=int(first.n_prompts),
                    n_models=int(first.n_models))
        if converged:
            om = g[g.kind == "omnibus"].iloc[0]
            om_rows.append(dict(**base, omnibus_chi2=float(om.estimate), df=int(om.df), p=float(om.p),
                                sd_prompt=float(first.sd_prompt), sd_model=float(first.sd_model),
                                sd_model_ps=float(first.sd_model_ps), singular=bool(first.singular), messages=first.messages))
            for _, t in g[g.kind == "ctx_dev"].iterrows():
                dev_rows.append(dict(fit=key, label=label, context=CONTEXTS[int(t.ctx) - 1], dev_logodds=float(t.estimate),
                                     se=float(t.se), lo=float(t.estimate - 1.96 * t.se), hi=float(t.estimate + 1.96 * t.se),
                                     z=float(t.z), p=float(t.p), p_bh=float(t.p_bh)))
        else:
            om_rows.append(dict(**base, omnibus_chi2=np.nan, df=np.nan, p=np.nan, sd_prompt=np.nan, sd_model=np.nan,
                                sd_model_ps=np.nan, singular=np.nan, messages=(first.error or first.messages)))
    res.table("glmm_context_interaction_omnibus", pd.DataFrame(om_rows))
    res.table("glmm_context_interaction_by_context", pd.DataFrame(dev_rows))
    res.write()


if __name__ == "__main__":
    main()
