import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as sps
from scipy.stats import norm

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analysis_08_capability as cap8
from pbanalysis import report
from pbanalysis.datasets import load_d1_english

NAME, SEED = "19_d1_english", 20260915


def bh(values):
    p = np.asarray(values, float)
    out = np.full(p.shape, np.nan)
    valid = np.flatnonzero(np.isfinite(p))
    order = valid[np.argsort(p[valid])]
    adj = p[order] * len(order) / np.arange(1, len(order) + 1)
    out[order] = np.minimum(1., np.minimum.accumulate(adj[::-1])[::-1])
    return out


def interval(arr):
    arr = np.asarray(arr, float)
    draws = arr[1:][np.isfinite(arr[1:])]
    if not len(draws):
        return dict(estimate=float(arr[0]*100), lo=np.nan, hi=np.nan, p_boot=np.nan, n_draws=0)
    lo, hi = np.quantile(draws, [.025, .975])
    zero_tol = 1e-12
    p = min(1., 2 * (min(np.count_nonzero(draws <= zero_tol), np.count_nonzero(draws >= -zero_tol)) + 1) / (len(draws) + 1))
    return dict(estimate=float(arr[0]*100), lo=float(lo*100), hi=float(hi*100),
                p_boot=float(p), n_draws=len(draws))


def wilson(successes, n):
    if not n:
        return np.nan, np.nan
    z = norm.ppf(.975)
    p = successes / n
    c = (p + z*z/(2*n)) / (1 + z*z/n)
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / (1 + z*z/n)
    return max(0., 100*(c-h)), min(100., 100*(c+h))


def point_rates(df, factor=None):
    keys = ["target", "model", "origin", "lab", "mode"] + ([factor] if factor else [])
    recs = []
    for values, g in df.groupby(keys, observed=True, dropna=False, sort=True):
        r = dict(zip(keys, values))
        d = g[g.valid]
        n, k = len(d), int(d.refuse.sum())
        h = d.loc[d.refuse.eq(0), "harmful"].dropna()
        lo, hi = wilson(k, n)
        hlo, hhi = wilson(int(h.sum()), len(h))
        r.update(n_total=len(g), n_valid=n, n_refuse=k, rate=100*k/n if n else np.nan,
                 rate_lo=lo, rate_hi=hi, n_nonrefused=len(h), n_harmful=int(h.sum()),
                 harm_nonrefused=100*h.mean() if len(h) else np.nan, harm_lo=hlo, harm_hi=hhi)
        recs.append(r)
    return pd.DataFrame(recs)


def main():
    df = load_d1_english()
    targets = sorted(df.target.unique())
    res = report.Result(NAME)
    wide = point_rates(df).pivot(index=["model", "origin", "lab"], columns="mode", values="rate").reset_index()
    probe = cap8.load_probe()
    probe = probe[probe.target.isin(targets)]
    if set(probe.target) != set(targets) or not probe.reasoning_arm.eq("off").all() or probe.duplicated(["target","id"]).any():
        raise ValueError("capability probe panel/arm/keys mismatch")
    cap = cap8.score(probe,np.random.default_rng(SEED))
    cap = wide.merge(cap.drop(columns="origin"),on="model",validate="one_to_one")
    res.table("capability_vs_refusal", cap)
    us, cn = (cap.loc[cap.origin == o, "index"].to_numpy(float) for o in ("US", "CN"))
    t, u = sps.ttest_ind(us, cn, equal_var=False), sps.mannwhitneyu(us, cn, alternative="two-sided")
    res.table("capability_by_origin", pd.DataFrame([dict(n_US=len(us), n_CN=len(cn), mean_US=us.mean(), mean_CN=cn.mean(),
        sd_US=us.std(ddof=1), sd_CN=cn.std(ddof=1), welch_t=float(t.statistic), welch_p=float(t.pvalue),
        mannwhitney_U=float(u.statistic), mannwhitney_p=float(u.pvalue))]))
    tr=df[df.valid & df["mode"].isin(["he","de","pg"])].groupby("truncated").agg(n=("refuse","size"),refused=("refuse","sum"),refusal=("refuse","mean")).reset_index()
    res.table("truncation_refusal", tr)
    res.write()


if __name__ == "__main__":
    main()
