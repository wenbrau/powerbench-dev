import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import report

NAME = "95_model_level_small_sample"
R = HERE / "results"
SRC = {"origin": R / "30_baseline_glmm" / "glmm_origin.csv", "origin_x": R / "30_baseline_glmm" / "glmm_interaction_ps_vs_control.csv",
       "overall": R / "78_baseline_panels" / "origin_overall_glmm.csv", "side": R / "45_nationality_side" / "side_glmm.csv",
       "direction": R / "46_nationality_direction_glmm" / "direction_glmm.csv", "ai_dc": R / "58_ai_agent_origin_glmm" / "ai_origin_glmm.csv",
       "cap": R / "64_ai_agent_capability_glmm" / "capability_glmm.csv", "reasoning": R / "68_reasoning_glmm" / "reasoning_glmm.csv"}
DF24, DF8 = 22, 6
LAB = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}


def bh(p):
    p = np.asarray(p, float); m = len(p); o = np.argsort(p)
    adj = np.minimum.accumulate((p[o] * m / np.arange(1, m + 1))[::-1])[::-1]
    q = np.empty(m); q[o] = np.minimum(adj, 1); return q


def row(panel, test, family, est, se, df):
    z = est / se
    return dict(panel=panel, test=test, family=family, estimate=est, se=se, ratio=np.exp(est), z=z,
                p_wald_z=2 * stats.norm.sf(abs(z)), df=df, p_t=2 * stats.t.sf(abs(z), df),
                ratio_lo_z=np.exp(est - 1.96 * se), ratio_hi_z=np.exp(est + 1.96 * se),
                ratio_lo_t=np.exp(est - stats.t.ppf(.975, df) * se), ratio_hi_t=np.exp(est + stats.t.ppf(.975, df) * se), paper="")


def main():
    rows = []
    o = pd.read_csv(SRC["origin"]).set_index("fit")
    for f, md in (("A_he", "he"), ("A_de", "de"), ("A_pg", "pg"), ("A_control", "control")):
        rows.append(row("Fig 1B", f"DC (CN/US), {LAB[md]}", "Fig 1B: DC by request type (4)", o.loc[f, "cn_logodds"], o.loc[f, "cn_se"], DF24))
    rows.append(row("Fig 1B", "DC (CN/US), PS pooled", "single: DC, PS pooled", o.loc["B_power_shifting", "cn_logodds"], o.loc["B_power_shifting", "cn_se"], DF24))
    ov = pd.read_csv(SRC["overall"]).iloc[0]
    rows.append(row("Fig 1B", "DC (CN/US), four types", "single: DC, four types", ov.cn_logodds, ov.se, DF24))
    x = pd.read_csv(SRC["origin_x"]).set_index("fit")
    rows.append(row("Fig 1B", "DC × (PS vs CT)", "single: DC × (PS vs CT)", x.loc["E_ps_vs_control", "cnxps_logodds"], x.loc["E_ps_vs_control", "cnxps_se"], DF24))
    for md in ("he", "de", "pg"):
        f = f"F_{md}_vs_control"
        rows.append(row("Fig 1B", f"DC × ({LAB[md]} vs CT)", "DC × (type vs CT) (3)", x.loc[f, "cnxps_logodds"], x.loc[f, "cnxps_se"], DF24))

    s = pd.read_csv(SRC["side"])
    s = s[(s["set"] == "geo") & s.quantity.str.startswith("side ×")]
    for _, r in s.iterrows():
        rows.append(row("Fig A2 (DC)", f"side × DC, {LAB[r['mode']]}", "side × DC, geo set (4)", np.log(r.OR), (np.log(r.OR_hi) - np.log(r.OR_lo)) / (2 * 1.96), DF24))
    d = pd.read_csv(SRC["direction"])
    d = d[d.quantity.str.startswith("direction x origin")]
    for _, r in d.iterrows():
        rows.append(row("Fig 2E", f"direction × DC, {r.country}, {LAB[r['mode']]}", f"direction × DC, {r.country} (4)", r.estimate, r.se, DF24))
    a = pd.read_csv(SRC["ai_dc"])
    a = a[a.family == "interaction"]
    for _, r in a.iterrows():
        rows.append(row("Fig 3 (DC)", f"AI × DC, {LAB[r['mode']]}", "AI × DC (4)", r.estimate, r.se, DF24))
    c = pd.read_csv(SRC["cap"])
    for _, r in c[(c.run == "pooled") & (c.set.isin(["power_shifting", "control"])) & c.quantity.str.startswith("ai x capability")].iterrows():
        rows.append(row("Fig 3F", f"AI × capability, {'PS' if r.set == 'power_shifting' else 'CT'}", "Fig 3F: AI × capability (2)", r.estimate, r.se, DF24))
    r = c[(c.run == "pooled") & (c.set == "stacked") & c.quantity.str.startswith("slope difference")].iloc[0]
    rows.append(row("Fig 3F", "AI × capability, PS − CT", "single: capability slope PS − CT", r.estimate, r.se, DF24))
    for _, r in c[(c.run == "bymode") & c.quantity.str.startswith("ai x capability")].iterrows():
        rows.append(row("Fig A3 (capability)", f"AI × capability, {LAB[r.set]}", "AI × capability by type (4)", r.estimate, r.se, DF24))
    g = pd.read_csv(SRC["reasoning"])
    for lvl in ("r1", "r2"):
        r = g[g.quantity == f"{lvl} x origin (US - CN)"].iloc[0]
        rows.append(row("Reasoning", f"level {lvl[1]} × DC", "reasoning: level × DC (2)", r.estimate, r.se, DF8))

    T = pd.DataFrame(rows)
    T["q_z"], T["q_t"] = np.nan, np.nan
    for f, idx in T.groupby("family").groups.items():
        T.loc[idx, "q_z"] = bh(T.loc[idx, "p_wald_z"].to_numpy()); T.loc[idx, "q_t"] = bh(T.loc[idx, "p_t"].to_numpy())
    T["n_family"] = T.groupby("family").family.transform("size")
    T["flips_at_05"] = (T.q_z < .05) != (T.q_t < .05)
    om = g[g.quantity == "omnibus level x origin"].iloc[0]
    chi2 = float(om.estimate); F = chi2 / 2
    omni = pd.DataFrame([dict(test="reasoning: level × DC omnibus", chi2=chi2, df_chi2=2, p_chi2=stats.chi2.sf(chi2, 2),
                              F=F, df1=2, df2=DF8, p_F=stats.f.sf(F, 2, DF8))])

    res = report.Result(NAME)
    res.table("between_model_tests", T)
    res.table("reasoning_omnibus", omni)
    res.write()


if __name__ == "__main__":
    main()
