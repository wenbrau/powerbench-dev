import pandas as pd

from _common import OUT, load22
from range_excess_bootstrap import excess_bootstrap

if __name__ == "__main__":
    draws = {}
    tab = excess_bootstrap(load22(), draws)
    tab.to_csv(OUT / "range_excess_bootstrap.csv", index=False)
    pd.concat([pd.DataFrame({"mode": m, "draw": range(len(b)), "eq": b[:, 0], "use": b[:, 1]}) for m, b in draws.items()]).to_csv(
        OUT / "range_excess_bootstrap_draws.csv", index=False)
