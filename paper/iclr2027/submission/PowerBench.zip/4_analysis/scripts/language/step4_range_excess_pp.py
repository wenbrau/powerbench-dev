from _common import OUT, load22
from range_excess_pp import excess_table

d = load22()
excess_table(d[d["mode"].isin(["he", "de", "pg"])], 576).to_csv(OUT / "range_excess_pp_ps.csv", index=False)
