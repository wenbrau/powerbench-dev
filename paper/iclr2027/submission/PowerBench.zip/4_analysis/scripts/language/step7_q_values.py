import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

from _common import OUT
from pbanalysis.datasets import MODES
from powerbench.paths import RESULTS
from rank_agreement import KINDS

ALL = RESULTS / "language_all_models"


def bh(p):
    return multipletests(np.asarray(p, float), method="fdr_bh")[1]


def stars(p):
    return "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else ""


def q_values(glmm, concordance, bootstrap, agreement):
    b = pd.read_csv(glmm / "glmm_language_by_language.csv"); b = b[b.fit.str.startswith("A_")].copy(); b["mode"] = b.fit.str[2:]
    assert np.allclose(b.groupby("mode").p.transform(bh), b.p_bh), "p_bh is not BH over the 8 languages of the mode"
    rows = [dict(panel="A", family=f"8 languages of {m}", test=l, p=float(r.p), q=float(r.p_bh)) for (m, l), r in b.set_index(["mode", "lang"]).iterrows()]
    s = pd.read_csv(concordance / "summary.csv")
    for lab, key in (("C B1", "Q1 in rho"), ("C B2", "Q2")):
        r = s[s.question.str.startswith(key)].iloc[0]; rows.append(dict(panel="C", family="single test", test=lab, p=float(r.p_t), q=float(r.p_t)))
    tb = pd.read_csv(bootstrap).set_index(["mode", "weights"])
    for ser, wname in (("eq", "eq"), ("wt", "use")):
        t_ = tb.xs(wname, level="weights").loc[list(MODES)]
        assert np.allclose(bh(t_.p_boot), t_.q_bh), "q_bh is not BH over the 4 modes of the weighting"
        rows += [dict(panel="D", family=f"4 types, weight {ser}", test=m, p=float(t_.loc[m, "p_boot"]), q=float(t_.loc[m, "q_bh"])) for m in MODES]
    st = pd.read_csv(agreement); t1 = st[(st.test == "test1_langperm") & st.quantity.isin(KINDS)].set_index("quantity").loc[KINDS]
    rows += [dict(panel="F", family="3 pair types", test=k, p=float(t1.loc[k, "p"]), q=float(q)) for k, q in zip(KINDS, bh(t1.p))]
    c = float(st[(st.test == "test2_blockperm") & (st.quantity == "within − mixed")].p.iloc[0])
    rows.append(dict(panel="F", family="single test", test="within − mixed", p=c, q=c))
    out = pd.DataFrame(rows); out["sig_p05"] = out.p < .05; out["sig_q05"] = out.q < .05
    return out


q22 = q_values(OUT / "glmm", OUT / "concordance", OUT / "range_excess_bootstrap.csv", OUT / "rank_agreement_tests_power_shifting.csv")
q24 = q_values(RESULTS / "36_language_glmm", RESULTS / "81_language_rank_concordance", ALL / "range_excess_bootstrap.csv",
               ALL / "rank_agreement_tests_power_shifting.csv")
q22.to_csv(OUT / "bh_q_values.csv", index=False)
m = q24.merge(q22, on=["panel", "family", "test"], suffixes=("_24", "_22"), how="outer")
m["stars_24"] = m.q_24.map(stars); m["stars_22"] = m.q_22.map(stars)
m.to_csv(OUT / "q_values_22_vs_24_models.csv", index=False)
