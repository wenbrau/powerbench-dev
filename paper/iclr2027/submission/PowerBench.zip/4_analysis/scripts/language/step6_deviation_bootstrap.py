import numpy as np
import pandas as pd

from _common import OUT, load22
from pbanalysis import Boot
from pbanalysis.datasets import MODES

B, SEED = 2000, 36

d = load22()
bs = Boot(d, B=B, seed=SEED, modes=MODES)
models = sorted(d.model.unique()); langs = sorted(d.lang.unique())
rows = []
for mode in MODES:
    R = np.stack([np.nanmean(np.vstack([bs.rate(bs.mask(model=m, lang=l), mode) for m in models]), axis=0) for l in langs])
    dev = R - R.mean(0, keepdims=True)
    for i, l in enumerate(langs):
        lo, hi = np.percentile(dev[i, 1:], [2.5, 97.5])
        rows.append(dict(mode=mode, lang=l, rate=100 * R[i, 0], dev=100 * dev[i, 0], lo=100 * lo, hi=100 * hi,
                         n_models=len(models), B=B, seed=SEED))
pd.DataFrame(rows).to_csv(OUT / "deviation_bootstrap.csv", index=False)
