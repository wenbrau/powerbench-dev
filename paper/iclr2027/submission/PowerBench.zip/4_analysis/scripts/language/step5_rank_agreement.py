from _common import OUT, load22
from rank_agreement import agreement_tests, PS

agreement_tests(load22(), [PS]).to_csv(OUT / "rank_agreement_tests_power_shifting.csv", index=False)
