from _common import OUT, EXCLUDE, load_d1_multilingual

df = load_d1_multilingual()
sw, en = df[df.lang == "sw"], df[df.lang == "en"]
g = sw.groupby("model").agg(origin=("origin", "first"), rows_sw=("valid", "size"), valid_sw=("valid", "mean"),
                            R_sw=("refuse", "mean"))
g["R_en"] = en.groupby("model").refuse.mean()
g["excluded"] = g.index.isin(EXCLUDE)
g.sort_values(["excluded", "R_sw"], ascending=False).to_csv(OUT / "excluded_models.csv")
