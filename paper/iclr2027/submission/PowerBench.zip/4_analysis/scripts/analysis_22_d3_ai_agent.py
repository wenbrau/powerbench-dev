import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
from analysis_19_d1_english import bh, interval, point_rates
from analysis_20_d1_languages import model_contrasts, aggregate_contrasts
from pbanalysis import report, models as M
from pbanalysis.datasets import MODES
from pbanalysis.conditions import condition_engine, load_d3

B, SEED = 5000, 20260915
KEY, POS, NEG = 'ai_minus_human', 'ai', 'human'


def frames(result, targets, blocs, mode, key, **extra):
    per=pd.DataFrame(model_contrasts(result,targets,mode,key,**extra)).rename(columns={
        'lang':'contrast','language_rate':'positive_rate','reference_rate':'negative_rate'})
    per=per.drop(columns='reference')
    pooled=pd.DataFrame(aggregate_contrasts(result,blocs,mode,key,**extra)).rename(columns={
        'lang':'contrast','language_rate':'positive_rate','reference_rate':'negative_rate'})
    return per,pooled


def main():
    df=load_d3()
    e=condition_engine(df,B=B,seed=SEED); targets=e.targets
    blocs={'all':list(range(len(targets))),**{b:[i for i,t in enumerate(targets) if M.origin(t)==b] for b in ('US','CN')}}
    res=report.Result('22_d3_ai_agent')
    per,pooled,rate_rows=[],[],[]
    for mode in MODES:
        r=e.compare(POS,NEG,mode)
        p,a=frames(r,targets,blocs,mode,KEY,positive_condition=POS,negative_condition=NEG)
        per.append(p);pooled.append(a)
        for bloc,ix in blocs.items():
            for col,condition in [('rate_reference',NEG),('rate_language',POS)]:
                rate_rows.append(dict(bloc=bloc,mode=mode,condition=condition,**interval(r[col][:,ix].mean(axis=1))))
    per=pd.concat(per,ignore_index=True);pooled=pd.concat(pooled,ignore_index=True)
    per['q']=bh(per.p_exact);pooled['q']=bh(pooled.p_boot)
    res.table('paired_per_model', per)
    res.table('paired_pooled', pooled)
    res.table('paired_refusal_levels', pd.DataFrame(rate_rows))
    res.table('per_model_rates', point_rates(df,factor='condition'))
    res.table('data_audit', df.groupby(['model','origin','condition','mode']).agg(rows=('valid','size'),valid=('valid','sum'),truncated=('truncated','sum')).reset_index())
    res.write()
    df.to_csv(res.dir/'analysis_rows.csv.gz',index=False,compression={'method':'gzip','mtime':0})


if __name__=='__main__':main()
