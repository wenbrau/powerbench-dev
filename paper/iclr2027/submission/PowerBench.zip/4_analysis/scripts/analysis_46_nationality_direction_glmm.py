import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd

from pbanalysis import report
from pbanalysis.conditions import load_d2

NAME = "46_nationality_direction_glmm"
MODES = ("he", "de", "pg", "control")
POLES = {"usa": [("us_ally", "us_ally", "ally_us"), ("us_rival", "us_rival", "rival_us"),
                 ("us_neutral", "us_neutral", "neutral_us"), ("us_cn", "us_cn", "cn_us")],
         "china": [("cn_ally", "cn_ally", "ally_cn"), ("cn_rival", "cn_rival", "rival_cn"),
                   ("cn_neutral", "cn_neutral", "neutral_cn"), ("cn_us", "cn_us", "us_cn")]}
R_SCRIPT = HERE / "r" / "glmm_direction.R"


def run_r(g, what):
    rscript = shutil.which("Rscript")
    if not rscript:
        sys.exit("Rscript not found: install R and lme4.")
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        g[["refuse", "mode", "pole", "dyad", "toward", "origin_c", "prompt_id", "model"]].to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout), what], capture_output=True, text=True, encoding="utf-8",
                              errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {proc.returncode}")
        return pd.read_csv(fout)


def tidy(o):
    for col in ("messages", "formula_used", "optimizer"):
        o[col] = o[col].fillna("").astype(str)
    o["OR"], o["OR_lo"], o["OR_hi"] = np.exp(o.estimate), np.exp(o.estimate - 1.96 * o.se), np.exp(o.estimate + 1.96 * o.se)
    return o[["mode", "pole", "dyad", "quantity", "estimate", "se", "z", "p", "OR", "OR_lo", "OR_hi", "sd_model_slope", "sd_model", "sd_prompt",
              "singular", "optimizer", "variant", "formula_used", "messages", "nobs", "seconds", "lme4_version", "r_version"]].rename(columns={"pole": "country"})


def bh(p):
    p = np.asarray(p, float); ok = np.isfinite(p); q = np.full(p.shape, np.nan)
    if ok.sum():
        v = p[ok]; o = np.argsort(v); m = len(v)
        adj = np.minimum.accumulate((v[o] * m / np.arange(1, m + 1))[::-1])[::-1]
        r = np.empty(m); r[o] = np.minimum(adj, 1); q[ok] = r
    return q


def holm(p):
    p = np.asarray(p, float); ok = np.isfinite(p); h = np.full(p.shape, np.nan)
    if ok.sum():
        v = p[ok]; o = np.argsort(v); m = len(v)
        adj = np.maximum.accumulate(v[o] * (m - np.arange(m)))
        r = np.empty(m); r[o] = np.minimum(adj, 1); h[ok] = r
    return h


def correct(df):
    df = df.copy()
    kind = np.where(df.dyad == "all", "body", "appendix")
    what = np.select([df.quantity == "direction (24 models)", df.quantity == "direction x origin (CN - US)"], ["direction", "interaction"], "by_origin")
    df["family"] = [f"{k}_{w}" for k, w in zip(kind, what)]
    df["q_bh"] = np.nan; df["p_holm"] = np.nan
    for fam, idx in df.groupby("family").groups.items():
        df.loc[idx, "q_bh"] = bh(df.loc[idx, "p"].to_numpy()); df.loc[idx, "p_holm"] = holm(df.loc[idx, "p"].to_numpy())
    df["n_family"] = df.groupby("family")["family"].transform("size")
    return df


def main():
    d2 = load_d2()
    base = d2[d2["mode"].isin(MODES) & d2.valid]
    rows = []
    for pole, dyads in POLES.items():
        for key, c_user, c_aff in dyads:
            for cond, toward in ((c_user, .5), (c_aff, -.5)):
                x = base[base.condition == cond][["refuse", "mode", "prompt_id", "model", "origin"]].copy()
                x["pole"], x["dyad"], x["toward"] = pole, key, toward
                rows.append(x)
    g = pd.concat(rows, ignore_index=True)
    g["refuse"] = g.refuse.astype(int); g["origin_c"] = np.where(g.origin == "CN", .5, -.5)

    res = report.Result(NAME)
    res.table("direction_glmm", correct(tidy(run_r(g, "joint"))))
    res.table("direction_glmm_by_dyad", correct(tidy(run_r(g, "bydyad"))))
    res.write()


if __name__ == "__main__":
    main()
