import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy.stats import rankdata

from pbanalysis import report
from pbanalysis.datasets import load_d1_multilingual, MODES

NAME = "39_language_order_tests"
NPERM_LABELS, NPERM_LANGS, SEED = 10000, 5000, 39
LANGS = ["en", "de", "fr", "es", "pt", "zh", "hi", "sw"]
EXCL_SW = {"nemotron-3.5-lightning", "nova-2-lite"}


def rank_corr(R):
    K = rankdata(R, axis=1)
    K = K - K.mean(1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        K = K / np.sqrt((K ** 2).sum(1, keepdims=True))
    return K @ K.T


def main():
    df = load_d1_multilingual()
    d = df[df.valid].copy()
    origin = d.drop_duplicates("model").set_index("model").origin
    models = sorted(origin.index, key=lambda m: (origin[m] != "CN", m))
    n = len(models)
    is_cn = np.array([origin[m] == "CN" for m in models])
    excl = np.array([m in EXCL_SW for m in models])
    uses7 = excl[:, None] | excl[None, :]
    iu = np.triu_indices(n, 1)
    rng = np.random.default_rng(SEED)
    rates = d.groupby(["mode", "model", "lang"]).refuse.mean().rename("rate").reset_index()

    def corr_matrix(T):
        C = np.where(uses7, rank_corr(T[:, :7]), rank_corr(T))
        np.fill_diagonal(C, np.nan)
        return C

    def means(C, lab):
        a, b = lab[iu[0]], lab[iu[1]]
        v = C[iu]
        cc, uu, mx = np.nanmean(v[a & b]), np.nanmean(v[~a & ~b]), np.nanmean(v[a != b])
        win = np.nanmean(v[a == b])
        return cc, uu, mx, win

    rows = []
    for mode in MODES:
        T = rates[rates["mode"] == mode].pivot(index="model", columns="lang", values="rate").reindex(index=models, columns=LANGS).to_numpy(float)
        C = corr_matrix(T)
        cc, uu, mx, win = means(C, is_cn)
        obs = {"within − mixed": win - mx, "CN–CN − mixed": cc - mx, "US–US − mixed": uu - mx}
        perm = {k: np.empty(NPERM_LABELS) for k in obs}
        for i in range(NPERM_LABELS):
            c2, u2, m2, w2 = means(C, rng.permutation(is_cn))
            perm["within − mixed"][i] = w2 - m2; perm["CN–CN − mixed"][i] = c2 - m2; perm["US–US − mixed"][i] = u2 - m2
        for k in obs:
            rows.append(dict(mode=mode, question="origin", statistic=k, observed=float(obs[k]),
                             null_mean=float(perm[k].mean()), null_lo=float(np.percentile(perm[k], 2.5)), null_hi=float(np.percentile(perm[k], 97.5)),
                             p_right=float(np.mean(perm[k] >= obs[k])), p_left=np.nan, n_perm=NPERM_LABELS))
        obs2 = {"CN–CN": cc, "US–US": uu, "mixed": mx, "all pairs": float(np.nanmean(C[iu]))}
        perm2 = {k: np.empty(NPERM_LANGS) for k in obs2}
        for i in range(NPERM_LANGS):
            Tp = T.copy()
            for r in range(n):
                k_ = 7 if excl[r] else 8
                Tp[r, :k_] = T[r, rng.permutation(k_)]
            Cp = corr_matrix(Tp)
            c2, u2, m2, _ = means(Cp, is_cn)
            perm2["CN–CN"][i] = c2; perm2["US–US"][i] = u2; perm2["mixed"][i] = m2; perm2["all pairs"][i] = np.nanmean(Cp[iu])
        for k in obs2:
            rows.append(dict(mode=mode, question="agreement ≠ 0", statistic=k, observed=float(obs2[k]),
                             null_mean=float(perm2[k].mean()), null_lo=float(np.percentile(perm2[k], 2.5)), null_hi=float(np.percentile(perm2[k], 97.5)),
                             p_right=float(np.mean(perm2[k] >= obs2[k])), p_left=float(np.mean(perm2[k] <= obs2[k])), n_perm=NPERM_LANGS))

    res = report.Result(NAME)
    res.table("order_agreement_tests", pd.DataFrame(rows))
    res.write()


if __name__ == "__main__":
    main()
