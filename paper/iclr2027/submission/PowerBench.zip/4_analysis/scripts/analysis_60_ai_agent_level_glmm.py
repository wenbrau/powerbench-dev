import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "60_ai_agent_level_glmm"
SRC_ROWS = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
SRC_LEVEL = HERE / "results" / "59_ai_agent_by_dimension" / "bias_direction_by_level_per_model.csv"
R_SCRIPT = HERE / "r" / "glmm_ai_level.R"
MODES = ["he", "de", "pg", "control"]
DIMS = {"scale": ["individual", "group", "society"], "standing": ["low", "med", "high"]}


def run_r(g: pd.DataFrame, dim: str) -> pd.DataFrame:
    rscript = shutil.which("Rscript")
    if not rscript:
        sys.exit("Rscript not found: install R and lme4.")
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        g.to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout), ",".join(DIMS[dim])], capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {proc.returncode}")
        return pd.read_csv(fout)


def main():
    rows = pd.read_csv(SRC_ROWS, low_memory=False)
    rows = rows[(rows.valid == True) & rows["mode"].isin(MODES)].copy()
    per_level = pd.read_csv(SRC_LEVEL)
    all_glmm, all_t = [], []
    for dim, lv in DIMS.items():
        g = pd.DataFrame({"refuse": rows.refuse.astype(int), "mode": rows["mode"], "ai": np.where(rows.condition == "ai", .5, -.5),
                          "level": rows[dim], "prompt_id": rows.prompt_id, "model": rows.model}).dropna(subset=["level"])
        o = run_r(g, dim)
        o["dim"] = dim
        name = {"ai at level 1": f"AI at {lv[0]}", "ai at level 2": f"AI at {lv[1]}", "ai at level 3": f"AI at {lv[2]}",
                "level 2 - level 1": f"{lv[1]} − {lv[0]}", "level 3 - level 1": f"{lv[2]} − {lv[0]}", "level 3 - level 2": f"{lv[2]} − {lv[1]}",
                "omnibus ai x level": "omnibus AI × level"}
        o["quantity"] = o.quantity.map(name)
        o["family"] = np.select([o.quantity.str.startswith("omnibus"), o.quantity.str.startswith("AI at")], ["omnibus", "level"], "contrast")
        o["OR"] = np.exp(o.estimate.where(o.family != "omnibus")); o["OR_lo"] = np.exp(o.estimate - 1.96 * o.se); o["OR_hi"] = np.exp(o.estimate + 1.96 * o.se)
        o["q_bh"] = np.nan
        for fam in ("omnibus", "contrast", "level"):
            idx = o.family == fam
            o.loc[idx, "q_bh"] = multipletests(o.loc[idx, "p"].to_numpy(), method="fdr_bh")[1]
        all_glmm.append(o)
        pl = per_level[per_level.dim == dim]
        for mode in MODES:
            w = pl[pl["mode"] == mode].pivot(index="model", columns="level", values="bias")[[lv[0], lv[2]]].dropna()
            d = (w[lv[2]] - w[lv[0]]).to_numpy()
            tt = stats.ttest_1samp(d, 0.0); half = stats.t.ppf(.975, len(d) - 1) * d.std(ddof=1) / np.sqrt(len(d))
            all_t.append(dict(dim=dim, mode=mode, contrast=f"{lv[2]} − {lv[0]}", n_models=len(d), diff=float(d.mean()), lo=float(d.mean() - half),
                              hi=float(d.mean() + half), t=float(tt.statistic), p=float(tt.pvalue), n_positive=int((d > 0).sum())))
    glmm = pd.concat(all_glmm, ignore_index=True)
    tpair = pd.DataFrame(all_t)
    for dim in DIMS:
        idx = tpair.dim == dim
        tpair.loc[idx, "q_bh"] = multipletests(tpair.loc[idx, "p"].to_numpy(), method="fdr_bh")[1]
    pl = per_level[per_level.dim == "scale"]
    cells = []
    for lv in ("individual", "society"):
        for mode in MODES:
            e = pl[(pl["mode"] == mode) & (pl.level == lv)].bias.dropna().to_numpy()
            half = stats.t.ppf(.975, len(e) - 1) * e.std(ddof=1) / np.sqrt(len(e))
            cells.append(dict(mode=mode, level=lv, n_models=len(e), bias=float(e.mean()), lo=float(e.mean() - half), hi=float(e.mean() + half)))
    cols = ["dim", "mode", "quantity", "family", "estimate", "se", "OR", "OR_lo", "OR_hi", "p", "q_bh", "df", "sd_model_slope", "sd_prompt", "sd_model",
            "singular", "optimizer", "variant", "nobs", "seconds", "formula_used"]
    res = report.Result(NAME)
    res.table("ai_level_glmm", glmm[cols])
    res.table("bias_direction_paired_t", tpair)
    res.table("scale_4x2_cells", pd.DataFrame(cells))
    res.write()


if __name__ == "__main__":
    main()
