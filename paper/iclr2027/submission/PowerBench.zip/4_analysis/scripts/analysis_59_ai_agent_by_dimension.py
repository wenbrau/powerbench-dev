import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "59_ai_agent_by_dimension"
SRC = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
MODES = ["he", "de", "pg", "control"]
DIMS = {"scale": ["individual", "group", "society"], "standing": ["low", "med", "high"],
        "context": ["Academia", "Diplomacy", "Fiction", "Government", "Interpersonal", "Markets", "Media", "Work"],
        "domain": ["Attentional", "Epistemic", "Legal", "Physical", "Rank", "Status", "Wealth"]}


def per_model_bias(rows: pd.DataFrame, dim: str) -> pd.DataFrame:
    p = rows.pivot_table(index=["model", "origin", "mode", dim, "prompt_id"], columns="condition", values="refuse", aggfunc="first").dropna()
    p["only_ai"] = ((p["ai"] == 1) & (p["human"] == 0)).astype(int); p["only_human"] = ((p["ai"] == 0) & (p["human"] == 1)).astype(int)
    g = p.groupby(["model", "origin", "mode", dim]).agg(n_pairs=("ai", "size"), n_only_ai=("only_ai", "sum"), n_only_human=("only_human", "sum")).reset_index()
    g["n_discordant"] = g.n_only_ai + g.n_only_human
    g["bias"] = np.where(g.n_discordant > 0, (g.n_only_ai - g.n_only_human) / g.n_discordant.replace(0, np.nan), np.nan)
    return g.rename(columns={dim: "level"}).assign(dim=dim)


def summarise(g: pd.DataFrame, dim: str) -> pd.DataFrame:
    rows = []
    for mode in MODES:
        for lv in DIMS[dim]:
            e = g[(g["mode"] == mode) & (g.level == lv)].bias.dropna().to_numpy()
            if len(e) < 2:
                continue
            half = stats.t.ppf(.975, len(e) - 1) * e.std(ddof=1) / np.sqrt(len(e))
            rows.append(dict(dim=dim, mode=mode, level=lv, n_models=len(e), n_discordant_median=float(g[(g["mode"] == mode) & (g.level == lv)].n_discordant.median()),
                             bias=float(e.mean()), lo=float(e.mean() - half), hi=float(e.mean() + half), sd_models=float(e.std(ddof=1)),
                             p_t=float(stats.ttest_1samp(e, 0).pvalue), n_positive=int((e > 0).sum())))
    out = pd.DataFrame(rows)
    if len(out):
        out["q_bh"] = out.groupby("mode").p_t.transform(lambda p: multipletests(p, method="fdr_bh")[1])
    return out


def main():
    rows = pd.read_csv(SRC, low_memory=False)
    rows = rows[(rows.valid == True) & rows["mode"].isin(MODES)].copy()
    rows["refuse"] = rows.refuse.astype(int)
    allpm, allsum = [], []
    for dim in DIMS:
        g = per_model_bias(rows[rows[dim].notna()], dim)
        allpm.append(g); allsum.append(summarise(g, dim))
    res = report.Result(NAME)
    res.table("bias_direction_by_level_per_model", pd.concat(allpm))
    res.table("bias_direction_by_level", pd.concat(allsum))
    res.write()


if __name__ == "__main__":
    main()
