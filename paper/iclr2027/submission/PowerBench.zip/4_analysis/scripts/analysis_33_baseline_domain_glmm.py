import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pandas as pd

from pbanalysis import report
from pbanalysis.load import DOMAINS
from pbanalysis.datasets import load_d1_english

NAME = "33_baseline_domain_glmm"
POWER = ["he", "de", "pg"]
LABELS = {"he": "Self-empowerment", "de": "Disempowerment", "pg": "Power grabbing"}
R_SCRIPT = HERE / "r" / "glmm_domain.R"


def find_rscript():
    exe = shutil.which("Rscript")
    if not exe:
        sys.exit("Rscript not found: install R and lme4.")
    return exe


def main():
    df = load_d1_english()
    d0 = df[df.valid & df["mode"].isin(POWER)].copy()
    d0["refuse"] = d0.refuse.astype(int)
    dom_index = {c: i + 1 for i, c in enumerate(DOMAINS)}
    d0["dom"] = d0.domain.map(dom_index)
    assert d0.dom.notna().all(), f"domains outside {DOMAINS}"

    rscript = find_rscript()
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        d0[["refuse", "mode", "prompt_id", "model", "dom"]].to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout)], capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr)
            sys.exit(f"Rscript exited with code {proc.returncode}")
        o = pd.read_csv(fout)
    for col in ("messages", "error", "kind"):
        o[col] = o[col].fillna("").astype(str)

    res = report.Result(NAME)

    dev_rows = []
    for mode in POWER:
        key, label = f"A_{mode}", LABELS[mode]
        g = o[o.fit == key]
        first = g.iloc[0]
        bad = [m for m in first.messages.split(" | ") if m and "singular" not in m]
        if first.error == "" and not bad and (g.kind == "omnibus").any():
            for _, t in g[g.kind == "dom_dev"].iterrows():
                dev_rows.append(dict(fit=key, label=label, domain=DOMAINS[int(t.dom) - 1], dev_logodds=float(t.estimate),
                                     se=float(t.se), lo=float(t.estimate - 1.96 * t.se), hi=float(t.estimate + 1.96 * t.se),
                                     z=float(t.z), p=float(t.p), p_bh=float(t.p_bh)))
    res.table("glmm_domain_by_domain", pd.DataFrame(dev_rows))
    res.write()


if __name__ == "__main__":
    main()
