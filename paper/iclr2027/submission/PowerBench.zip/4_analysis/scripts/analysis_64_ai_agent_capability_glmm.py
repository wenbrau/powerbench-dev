import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "64_ai_agent_capability_glmm"
SRC_ROWS = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
SRC_CAP = HERE / "results" / "30_baseline_glmm" / "capability_index.csv"
R_SCRIPT = HERE / "r" / "glmm_ai_capability.R"
MODES = ["he", "de", "pg", "control"]


def run_r(g: pd.DataFrame, what: str) -> pd.DataFrame:
    rscript = shutil.which("Rscript")
    if not rscript:
        sys.exit("Rscript not found: install R and lme4.")
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        g.to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout), what], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {proc.returncode}")
        return pd.read_csv(fout)


def main():
    rows = pd.read_csv(SRC_ROWS, low_memory=False)
    rows = rows[(rows.valid == True) & rows["mode"].isin(MODES)].copy()
    cap = pd.read_csv(SRC_CAP).set_index("model")
    g = pd.DataFrame({"refuse": rows.refuse.astype(int), "mode": rows["mode"], "ai": np.where(rows.condition == "ai", .5, -.5),
                      "cap_z": rows.model.map(cap.cap_z), "ps": (rows["mode"] != "control").astype(int), "prompt_id": rows.prompt_id, "model": rows.model})
    assert g.cap_z.notna().all()
    o1 = run_r(g, "bymode")
    o2 = run_r(g, "pooled")
    o = pd.concat([o1.assign(run="bymode"), o2.assign(run="pooled")], ignore_index=True)
    for col in ("formula_used", "optimizer"):
        o[col] = o[col].fillna("").astype(str)
    o["OR_or_ratio"] = np.exp(o.estimate); o["lo"] = np.exp(o.estimate - 1.96 * o.se); o["hi"] = np.exp(o.estimate + 1.96 * o.se)
    o["q_bh"] = np.nan
    idx = (o.run == "bymode") & (o.quantity == "ai x capability (per 1 SD)")
    o.loc[idx, "q_bh"] = multipletests(o.loc[idx, "p"].to_numpy(), method="fdr_bh")[1]
    tab = o[["run", "set", "quantity", "estimate", "se", "OR_or_ratio", "lo", "hi", "p", "q_bh", "sd_model_slope", "sd_prompt", "sd_model", "singular",
             "optimizer", "variant", "nobs", "n_models", "seconds", "formula_used"]]

    def per_model_lor(sub):
        gg = sub.groupby(["model", "condition"]).refuse.agg(["sum", "size"]).unstack("condition")
        a, na = gg[("sum", "ai")] + .5, gg[("size", "ai")] + 1; h, nh = gg[("sum", "human")] + .5, gg[("size", "human")] + 1
        lor = np.log(a / (na - a)) - np.log(h / (nh - h)); se = np.sqrt(1 / a + 1 / (na - a) + 1 / h + 1 / (nh - h))
        return pd.DataFrame({"log_or": lor, "se": se, "cap_z": cap.loc[lor.index, "cap_z"].values, "capability": cap.loc[lor.index, "index"].values,
                             "origin": cap.loc[lor.index, "origin"].values}).reset_index()

    pm_tabs = []
    for mode in MODES:
        pm = per_model_lor(rows[rows["mode"] == mode]); pm["set"] = mode; pm_tabs.append(pm)
    pm_ps = pd.concat(pm_tabs[:3]).groupby("model").agg(log_or=("log_or", "mean"), se=("se", lambda s: float(np.sqrt((s ** 2).sum()) / len(s))),
                                                        capability=("capability", "first"), cap_z=("cap_z", "first"), origin=("origin", "first")).reset_index()
    pm_ps["set"] = "power_shifting_mean_of_modes"; pm_tabs.append(pm_ps)

    res = report.Result(NAME)
    res.table("capability_glmm", tab.round(5))
    res.table("capability_per_model_log_or", pd.concat(pm_tabs))
    res.write()


if __name__ == "__main__":
    main()
