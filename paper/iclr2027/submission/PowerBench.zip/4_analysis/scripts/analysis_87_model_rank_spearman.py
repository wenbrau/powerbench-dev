import sys
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "87_model_rank_spearman"
RATES = HERE / "results" / "78_baseline_panels" / "rates_per_model.csv"
RANK25 = HERE / "results" / "25_baseline_rates" / "rank_correlation_between_modes.csv"
TYPES = ["he", "de", "pg", "control"]
LABEL = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}
N_PERM, SEED = 10_000, 87


def perm_test(x, y, n_perm, seed):
    rho = stats.spearmanr(x, y).statistic
    rng = np.random.default_rng(seed)
    rx = stats.rankdata(x)
    hits = 0
    for _ in range(n_perm):
        ry = stats.rankdata(rng.permutation(y))
        r = np.corrcoef(rx, ry)[0, 1]
        hits += abs(r) >= abs(rho) - 1e-12
    return float(rho), (1 + hits) / (n_perm + 1)


def main():
    R = pd.read_csv(RATES)
    assert len(R) == 24 and set(TYPES) <= set(R.columns), (len(R), R.columns.tolist())
    rows = []
    for a, b in combinations(TYPES, 2):
        rho, p_perm = perm_test(R[a].to_numpy(float), R[b].to_numpy(float), N_PERM, SEED)
        p_t = float(stats.spearmanr(R[a], R[b]).pvalue)
        rows.append({"type_a": LABEL[a], "type_b": LABEL[b], "pair": f"{LABEL[a]}-{LABEL[b]}", "rho": rho,
                     "p_perm": p_perm, "p_t": p_t, "n_models": len(R), "n_perm": N_PERM, "seed": SEED})
    T = pd.DataFrame(rows)
    T["q_bh"] = multipletests(T.p_perm, method="fdr_bh")[1]
    T["q_bh_t"] = multipletests(T.p_t, method="fdr_bh")[1]

    K = pd.read_csv(RANK25)
    for r in T.itertuples():
        a = [k for k, v in LABEL.items() if v == r.type_a][0]; b = [k for k, v in LABEL.items() if v == r.type_b][0]
        ref = K[(K.mode_a == a) & (K.mode_b == b)].spearman
        assert len(ref) == 1 and abs(float(ref.iloc[0]) - r.rho) < 1e-6, (r.pair, r.rho, ref.tolist())

    res = report.Result(NAME)
    res.table("spearman_pairs", T)
    res.write()


if __name__ == "__main__":
    main()
