import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import pandas as pd

from pbanalysis import report

NAME = "54_ai_agent_levels"
SRC_LEVELS = HERE / "results" / "22_d3_ai_agent" / "paired_refusal_levels.csv"
SRC_DELTA = HERE / "results" / "22_d3_ai_agent" / "paired_pooled.csv"
MODES = ["he", "de", "pg", "control"]


def main():
    lv = pd.read_csv(SRC_LEVELS)
    lv = lv[(lv["bloc"] == "all") & lv["mode"].isin(MODES)].copy()
    assert len(lv) == 8, lv
    dl = pd.read_csv(SRC_DELTA)
    dl = dl[(dl["bloc"] == "all") & (dl["contrast"] == "ai_minus_human") & dl["mode"].isin(MODES)].copy()
    assert len(dl) == 4, dl
    res = report.Result(NAME)
    res.table("levels_pooled", lv[["mode", "condition", "estimate", "lo", "hi", "n_draws"]].round(2))
    res.table("delta_paired_pooled", dl[["mode", "estimate", "lo", "hi", "q"]].round(3))
    res.write()


if __name__ == "__main__":
    main()
