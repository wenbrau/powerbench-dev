import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "58_ai_agent_origin_glmm"
SRC_ROWS = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
R_SCRIPT = HERE / "r" / "glmm_ai_origin.R"
MODES = ["he", "de", "pg", "control"]


def main():
    rows = pd.read_csv(SRC_ROWS, low_memory=False)
    rows = rows[(rows.valid == True) & rows["mode"].isin(MODES)].copy()
    g = pd.DataFrame({"refuse": rows.refuse.astype(int), "mode": rows["mode"], "ai": np.where(rows.condition == "ai", .5, -.5),
                      "cn": (rows.origin == "CN").astype(int), "prompt_id": rows.prompt_id, "model": rows.model})
    rscript = shutil.which("Rscript")
    if not rscript:
        sys.exit("Rscript not found: install R and lme4.")
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        g.to_csv(fin, index=False)
        proc = subprocess.run([rscript, str(R_SCRIPT), str(fin), str(fout)], capture_output=True, text=True, encoding="utf-8",
                              errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {proc.returncode}")
        o = pd.read_csv(fout)
    for col in ("formula_used", "optimizer", "term"):
        o[col] = o[col].fillna("").astype(str)
    o["kind"] = o.fit.str.split("__").str[0]
    keep = o[((o.kind == "ai") & (o.term == "ai")) | ((o.kind == "ai_origin_US") & o.term.isin(["ai", "ai:cn"])) |
             ((o.kind == "ai_origin_CN") & (o.term == "ai"))].copy()
    keep["quantity"] = np.select([keep.kind == "ai", (keep.kind == "ai_origin_US") & (keep.term == "ai"), keep.term == "ai:cn"],
                                 ["AI vs human (24 models)", "AI vs human, US models", "AI × origin (CN / US)"], "AI vs human, CN models")
    keep["family"] = np.select([keep.quantity == "AI vs human (24 models)", keep.quantity == "AI × origin (CN / US)"],
                               ["main", "interaction"], "by_origin")
    keep["OR"] = np.exp(keep.estimate); keep["OR_lo"] = np.exp(keep.estimate - 1.96 * keep.se); keep["OR_hi"] = np.exp(keep.estimate + 1.96 * keep.se)
    keep["q_bh"] = np.nan; keep["p_holm"] = np.nan
    for fam in keep.family.unique():
        idx = keep.family == fam
        keep.loc[idx, "q_bh"] = multipletests(keep.loc[idx, "p"].to_numpy(), method="fdr_bh")[1]
        keep.loc[idx, "p_holm"] = multipletests(keep.loc[idx, "p"].to_numpy(), method="holm")[1]
    tab = keep[["mode", "quantity", "family", "estimate", "se", "OR", "OR_lo", "OR_hi", "p", "q_bh", "p_holm", "sd_model_slope",
                "sd_prompt", "sd_model", "singular", "optimizer", "variant", "n_prompts", "n_models", "nobs", "formula_used"]].copy()
    tab["mode"] = pd.Categorical(tab["mode"], MODES); tab = tab.sort_values(["mode", "family", "quantity"]).reset_index(drop=True)

    res = report.Result(NAME)
    res.table("ai_origin_glmm", tab)
    res.write()


if __name__ == "__main__":
    main()
