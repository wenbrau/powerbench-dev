import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import Boot, ci, report
from pbanalysis.datasets import load_d1_english, MODES as FP_MODES

NAME = "94_pg_excess_logodds"
SRC = HERE / "results" / "25_baseline_rates" / "components_excess_per_model.csv"
B, SEED = 5000, 25


def elogit(k, n):
    return np.log((k + .5) / (n - k + .5))


def prompt_bootstrap_elogit(df):
    bs = Boot(df, B=B, seed=SEED, modes=FP_MODES)
    targets = sorted(df.target.unique())

    def counts(t, mode):
        sel = bs.mask(target=t) & (bs._mode == mode) & np.isfinite(bs._refuse)
        k = bs._nprompt[mode]; pid = bs._pidx[mode][sel]; C = bs._counts[mode]
        return C @ np.bincount(pid, weights=bs._refuse[sel], minlength=k), C @ np.bincount(pid, minlength=k).astype(float)

    ex = []
    for t in targets:
        (kh, nh), (kd, nd), (kp, npg) = counts(t, "he"), counts(t, "de"), counts(t, "pg")
        ex.append(elogit(kp, npg) - elogit(kh + kd, (nh + nd) / 2))
    c = ci(np.vstack(ex).mean(0))
    return dict(statistic="mean empirical-logit excess over the sum", value=c["est"], lo95=c["lo"], hi95=c["hi"], p=c["p"],
                test="bootstrap over prompts")


def logit(p):
    return np.log(p / (1 - p))


def summary(x, label, test_extra=""):
    x = np.asarray(x, float); n = len(x); m = x.mean(); se = x.std(ddof=1) / np.sqrt(n); tc = stats.t.ppf(.975, n - 1)
    t = stats.ttest_1samp(x, 0.0); w = stats.wilcoxon(x)
    return [dict(statistic=f"mean {label}", value=m, lo95=m - tc * se, hi95=m + tc * se, p=t.pvalue, test=f"one-sample t, {n} models{test_extra}"),
            dict(statistic=f"OR (exp of the mean {label})", value=np.exp(m), lo95=np.exp(m - tc * se), hi95=np.exp(m + tc * se), p=t.pvalue,
                 test="same test"),
            dict(statistic=f"median {label}", value=float(np.median(x)), lo95=np.nan, hi95=np.nan, p=w.pvalue, test=f"Wilcoxon signed-rank, {n} models"),
            dict(statistic=f"models with {label} > 0", value=int((x > 0).sum()), lo95=np.nan, hi95=np.nan,
                 p=stats.binomtest(int((x > 0).sum()), n, .5).pvalue, test="binomial against 1/2")]


def main():
    E = pd.read_csv(SRC)
    assert len(E) == 24
    r = {m: E[m].to_numpy(float) / 100 for m in ("he", "de", "pg")}
    s = r["he"] + r["de"]; u = 1 - (1 - r["he"]) * (1 - r["de"])
    assert (s > 0).all() and (r["pg"] > 0).all() and (s < 1).all()
    E["logit_excess_sum"] = logit(r["pg"]) - logit(s)
    E["logit_excess_union"] = logit(r["pg"]) - logit(u)
    d_all = load_d1_english(); d = d_all[d_all.valid & d_all["mode"].isin(["he", "de", "pg"])]
    k = d.groupby(["model", "mode"]).refuse.agg(["sum", "count"]).unstack("mode")
    k = k.reindex(E.group)
    ks, ns = k[("sum", "he")] + k[("sum", "de")], (k[("count", "he")] + k[("count", "de")]) / 2
    E["elogit_excess_sum"] = (elogit(k[("sum", "pg")], k[("count", "pg")]) - elogit(ks, ns)).to_numpy()
    assert np.allclose(k[("sum", "pg")].to_numpy() / k[("count", "pg")].to_numpy(), r["pg"])

    boot = prompt_bootstrap_elogit(d_all)
    assert np.isclose(boot["value"], E.elogit_excess_sum.mean())
    rows = [boot]
    rows += summary(E.logit_excess_sum, "log-odds excess over the sum")
    rows += summary(E.logit_excess_union, "log-odds excess over the union")
    rows += summary(E.elogit_excess_sum, "empirical-logit excess over the sum", " (counts + 0.5)")
    for o in ("US", "CN"):
        rows += summary(E.loc[E.origin == o, "logit_excess_sum"], f"log-odds excess over the sum, {o} models")[:2]
    pp = E.pg - (E.he + E.de)
    rows += [dict(statistic="reference: mean excess over the sum (pp), block 88", value=pp.mean(), lo95=np.nan, hi95=np.nan,
                  p=stats.ttest_1samp(pp, 0).pvalue, test="one-sample t, 24 models")]

    res = report.Result(NAME)
    res.table("logodds_excess_tests", pd.DataFrame(rows))
    res.write()


if __name__ == "__main__":
    main()
