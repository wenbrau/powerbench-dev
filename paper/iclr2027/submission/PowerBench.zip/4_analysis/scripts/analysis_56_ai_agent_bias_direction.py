import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "56_ai_agent_bias_direction"
SRC = HERE / "results" / "22_d3_ai_agent" / "paired_per_model.csv"
MODES = ["he", "de", "pg", "control"]


def main():
    pm = pd.read_csv(SRC)
    pm = pm[(pm.contrast == "ai_minus_human") & pm["mode"].isin(MODES)].copy()
    pm = pm.rename(columns={"n_more": "n_only_ai", "n_less": "n_only_human", "direction": "bias"})
    pm = pm[pm.n_discordant > 0]
    rows = []
    for mode in MODES:
        e = pm[pm["mode"] == mode].bias.to_numpy()
        tt = stats.ttest_1samp(e, 0.0)
        half = stats.t.ppf(.975, len(e) - 1) * e.std(ddof=1) / np.sqrt(len(e))
        rows.append(dict(mode=mode, n_models=len(e), n_discordant_median=float(pm[pm["mode"] == mode].n_discordant.median()),
                         n_discordant_total=int(pm[pm["mode"] == mode].n_discordant.sum()),
                         bias=float(e.mean()), lo=float(e.mean() - half), hi=float(e.mean() + half), sd_models=float(e.std(ddof=1)),
                         t=float(tt.statistic), p_t=float(tt.pvalue), n_positive=int((e > 0).sum()),
                         n_models_p05=int((pm[pm["mode"] == mode].p_exact < .05).sum())))
    summ = pd.DataFrame(rows)
    summ["q_bh"] = multipletests(summ.p_t, method="fdr_bh")[1]
    summ["p_holm"] = multipletests(summ.p_t, method="holm")[1]

    res = report.Result(NAME)
    res.table("bias_direction_per_model", pm[["model", "origin", "mode", "n_pairs", "n_only_ai", "n_only_human", "n_discordant", "bias", "p_exact"]])
    res.table("bias_direction_summary", summ)
    res.write()


if __name__ == "__main__":
    main()
