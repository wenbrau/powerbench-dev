import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "85_ai_agent_glmm"
ROWS = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
R_SCRIPT = HERE / "r" / "glmm_ai_main.R"
MODES = ["he", "de", "pg", "control"]


def main():
    d = pd.read_csv(ROWS, low_memory=False)
    d = d[d.valid & d.condition.isin(["human", "ai"])]
    g = pd.DataFrame({"refuse": d.refuse.astype(int), "mode": d["mode"], "ai": np.where(d.condition == "ai", .5, -.5),
                      "prompt_id": d.prompt_id, "model": d.model})
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        g.to_csv(fin, index=False)
        pr = subprocess.run(["Rscript", str(R_SCRIPT), str(fin), str(fout)], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if pr.returncode != 0:
            print(pr.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {pr.returncode}")
        G = pd.read_csv(fout)
    G = G.set_index("mode").loc[MODES].reset_index()
    G["q_bh"] = multipletests(G.p, method="fdr_bh")[1]

    res = report.Result(NAME)
    res.table("ai_glmm_main", G)
    res.write()


if __name__ == "__main__":
    main()
