import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "91_nationality_specificity"
PS = HERE / "results" / "86_nationality_power_shifting" / "side_abs_bias_excess_ps_per_model.csv"
BY_MODE = HERE / "results" / "55_nationality_side_excess" / "side_abs_bias_excess_per_model.csv"


def paired(a, b, label):
    d = (a - b).dropna()
    n = len(d)
    tt = stats.ttest_1samp(d, 0)
    half = stats.t.ppf(.975, n - 1) * d.std(ddof=1) / np.sqrt(n)
    return {"contrast": label, "n_models": n, "diff": d.mean(), "lo": d.mean() - half, "hi": d.mean() + half,
            "t": tt.statistic, "p_t": tt.pvalue, "p_wilcoxon": stats.wilcoxon(d).pvalue, "n_positive": int((d > 0).sum())}


def main():
    ps = pd.read_csv(PS).set_index(["set", "model"])["excess"]
    bm = pd.read_csv(BY_MODE).set_index(["set", "mode", "model"])["excess"]

    A = pd.DataFrame([paired(ps.loc["geo"], bm.loc[("geo", "control")], "PS geo − control geo"),
                      paired(ps.loc["geo"], ps.loc["neutral"], "PS geo − PS neutral")])
    A["q_bh"] = multipletests(A.p_t, method="fdr_bh")[1]

    diag = []
    for m in ("he", "de", "pg"):
        diag.append(paired(bm.loc[("geo", m)], bm.loc[("geo", "control")], f"{m} geo − control geo"))
        diag.append(paired(bm.loc[("geo", m)], bm.loc[("neutral", m)], f"{m} geo − {m} neutral"))
    D = pd.DataFrame(diag)
    D["q_bh"] = multipletests(D.p_t, method="fdr_bh")[1]

    res = report.Result(NAME)
    res.table("direct_contrasts", A)
    res.table("direct_contrasts_by_mode", D)
    res.write()


if __name__ == "__main__":
    main()
