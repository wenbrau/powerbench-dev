import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import report

NAME = "76_ai_agent_direction_vs_control"
SRC = HERE / "results" / "56_ai_agent_bias_direction" / "bias_direction_per_model.csv"
PS_MODES = ("he", "de", "pg")


def bh(p):
    p = np.asarray(p, float); m = len(p); order = np.argsort(p); q = np.empty(m); prev = 1.0
    for rank, i in zip(range(m, 0, -1), order[::-1]):
        prev = min(prev, p[i] * m / rank); q[i] = prev
    return q


def paired(diff):
    diff = np.asarray(diff, float); diff = diff[np.isfinite(diff)]
    n = len(diff); tt = stats.ttest_1samp(diff, 0.0)
    half = stats.t.ppf(.975, n - 1) * diff.std(ddof=1) / np.sqrt(n)
    w = stats.wilcoxon(diff) if n >= 6 else None
    return dict(n_models=n, mean_diff=float(diff.mean()), lo=float(diff.mean() - half), hi=float(diff.mean() + half),
                t=float(tt.statistic), p_t=float(tt.pvalue), p_wilcoxon=float(w.pvalue) if w else np.nan,
                n_positive=int((diff > 0).sum()), n_negative=int((diff < 0).sum()))


def level(name, b, n):
    b = np.asarray(b, float); tt = stats.ttest_1samp(b, 0.0); half = stats.t.ppf(.975, len(b) - 1) * b.std(ddof=1) / np.sqrt(len(b))
    return dict(set=name, n_models=int(len(b)), n_discordant_median=float(np.median(n)), bias=float(b.mean()), lo=float(b.mean() - half),
                hi=float(b.mean() + half), t=float(tt.statistic), p_t=float(tt.pvalue), n_positive=int((b > 0).sum()))


def main():
    pm = pd.read_csv(SRC)
    models = sorted(pm.model.unique())
    ps = (pm[pm["mode"].isin(PS_MODES)].groupby("model")[["n_only_ai", "n_only_human", "n_discordant", "n_pairs"]].sum()
          .reindex(models))
    ps["bias"] = (ps.n_only_ai - ps.n_only_human) / ps.n_discordant
    ctrl = pm[pm["mode"] == "control"].set_index("model").reindex(models)
    per = pd.DataFrame({"n_discordant_ps": ps.n_discordant.values, "bias_ps": ps.bias.values,
                        "n_discordant_control": ctrl.n_discordant.values, "bias_control": ctrl.bias.values})
    per["diff_ps_minus_control"] = per.bias_ps - per.bias_control
    for m in PS_MODES:
        per[f"diff_{m}_minus_control"] = pm[pm["mode"] == m].set_index("model").reindex(models).bias.values - per.bias_control
    rows = [dict(contrast="power_shifting - control", family="main", **paired(per.diff_ps_minus_control))]
    sec = [dict(contrast=f"{m} - control", family="secondary (3 types)", **paired(per[f"diff_{m}_minus_control"])) for m in PS_MODES]
    q = bh([r["p_t"] for r in sec])
    for r, qq in zip(sec, q):
        r["q_bh"] = float(qq)
    rows[0]["q_bh"] = rows[0]["p_t"]
    summ = pd.DataFrame(rows + sec)
    lev = pd.DataFrame([level("power_shifting", per.bias_ps, per.n_discordant_ps), level("control", per.bias_control, per.n_discordant_control)])

    res = report.Result(NAME)
    res.table("ps_vs_control_summary", summ)
    res.table("levels", lev)
    res.write()


if __name__ == "__main__":
    main()
