import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pandas as pd

from pbanalysis import report
from pbanalysis.datasets import load_d1_multilingual

NAME = "82_language_glmm_power_shifting"
LANGS = ["de", "pt", "en", "es", "sw", "zh", "fr", "hi"]
LANG_NAME = {"en": "English", "de": "German", "fr": "French", "es": "Spanish", "pt": "Portuguese", "zh": "Chinese", "hi": "Hindi", "sw": "Swahili"}
EXCL_SW = {"nemotron-3.5-lightning", "nova-2-lite"}
R_SCRIPT = HERE / "r" / "glmm_language_ps.R"


def main():
    df = load_d1_multilingual(); d = df[df.valid].copy()
    d = d[~((d.lang == "sw") & d.model.isin(EXCL_SW))]
    d = d[d["mode"].isin(["he", "de", "pg"])]
    x = d[["refuse", "mode", "prompt_id", "model", "lang"]].copy()
    x["refuse"] = x.refuse.astype(int); x["lang"] = x.lang.map({l: i + 1 for i, l in enumerate(LANGS)})
    with tempfile.TemporaryDirectory() as tmp:
        fin, fout = Path(tmp) / "glmm_input.csv", Path(tmp) / "glmm_out.csv"
        x.to_csv(fin, index=False)
        proc = subprocess.run(["Rscript", str(R_SCRIPT), str(fin), str(fout)], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr); sys.exit(f"Rscript exited with code {proc.returncode}")
        o = pd.read_csv(fout)
    dev = o[o.kind == "dev"].copy(); dev["lang"] = dev.lang.astype(int).map(dict(enumerate(LANGS, 1))); dev["language"] = dev.lang.map(LANG_NAME)
    dev["lo"], dev["hi"] = dev.estimate - 1.96 * dev.se, dev.estimate + 1.96 * dev.se

    res = report.Result(NAME)
    res.table("language_deviation_ps", dev[["lang", "language", "estimate", "se", "lo", "hi", "z", "p", "p_bh"]])
    res.table("glmm_fit", o[o.kind == "omnibus"][["estimate", "df", "p", "sd_prompt", "sd_model", "sd_model_lang", "singular", "optimizer", "variant", "formula_used", "fit_seconds", "nobs"]]
              .rename(columns={"estimate": "wald_chi2"}))
    res.write()


if __name__ == "__main__":
    main()
