import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from analysis_19_d1_english import bh, interval, wilson
from pbanalysis import report, models as M
from pbanalysis.datasets import MODES, LANGUAGES, load_d1_multilingual
from pbanalysis.paired_languages import LanguagePairs

NAME, B, SEED = "20_d1_languages", 5000, 20260915
NON_EN = LANGUAGES[1:]


def model_contrasts(result, targets, mode, language, reference="en", **extra):
    rows = []
    for j, t in enumerate(targets):
        more, less = int(result["more"][j]), int(result["less"][j])
        dlo, dhi = wilson(more, more+less)
        rows.append(dict(target=t, model=M.short(t), origin=M.origin(t), mode=mode,
            lang=language, reference=reference, **extra, n_pairs=int(result["n_pairs"][j]),
            n_more=more, n_less=less, n_both=int(result["both"][j]), n_discordant=more+less,
            reference_rate=100*result["rate_reference"][0, j],
            language_rate=100*result["rate_language"][0, j],
            direction=result["direction"][j], direction_lo=2*dlo/100-1,
            direction_hi=2*dhi/100-1, p_exact=result["p_exact"][j],
            **{k:v for k,v in interval(result["delta"][:, j]).items() if k != "p_boot"}))
    return rows


def aggregate_contrasts(result, blocs, mode, language, **extra):
    out = []
    for bloc, ix in blocs.items():
        out.append(dict(bloc=bloc, mode=mode, lang=language, **extra, n_models=len(ix),
                        min_pairs=int(result["n_pairs"][ix].min()),
                        max_pairs=int(result["n_pairs"][ix].max()),
                        reference_rate=100*result["rate_reference"][0, ix].mean(),
                        language_rate=100*result["rate_language"][0, ix].mean(),
                        **interval(np.mean(result["delta"][:, ix], axis=1))))
    return out


def main():
    df = load_d1_multilingual()
    e = LanguagePairs(df, B=B, seed=SEED)
    targets = e.targets
    blocs = {"all": list(range(len(targets))), **{b:[j for j,t in enumerate(targets) if M.origin(t)==b] for b in ("US","CN")}}
    res = report.Result(NAME)

    pooled, sensitivity = [], []
    for mode in MODES:
        for lang in NON_EN:
            pooled += aggregate_contrasts(e.compare(lang,"en",mode), blocs, mode, lang)
            sensitivity += aggregate_contrasts(e.compare(lang,"en",mode,exclude_truncated=True), blocs, mode, lang)
    pooled = pd.DataFrame(pooled)
    pooled["q"] = bh(pooled.p_boot)
    sensitivity = pd.DataFrame(sensitivity).drop(columns="p_boot")
    sensitivity = sensitivity.merge(pooled[["bloc","mode","lang","estimate"]].rename(columns={"estimate":"full_estimate"}),on=["bloc","mode","lang"])
    sensitivity["change_from_full"] = sensitivity.estimate-sensitivity.full_estimate
    res.table("language_vs_english_panel", pooled)
    res.table("truncation_sensitivity", sensitivity)
    ta=df.groupby("lang").agg(rows=("valid","size"),valid=("valid","sum"),truncated=("truncated","sum")).reindex(LANGUAGES).reset_index()
    ta["truncated_pct"]=100*ta.truncated/ta.rows
    res.table("language_data_audit", ta)
    tr=df[df.valid & df["mode"].isin(["he","de","pg"])].groupby(["lang","truncated"]).agg(n=("refuse","size"),refused=("refuse","sum"),refusal=("refuse","mean")).reset_index()
    res.table("truncation_refusal", tr)
    res.write()


if __name__ == "__main__":
    main()
