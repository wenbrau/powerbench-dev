import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd

from pbanalysis import report

NAME = "77_bh_baseline_language"
R = HERE / "results"
SRC = {"modes": R / "30_baseline_glmm" / "glmm_mode_contrasts.csv",
       "origin": R / "30_baseline_glmm" / "glmm_origin.csv",
       "origin_x": R / "30_baseline_glmm" / "glmm_interaction_ps_vs_control.csv",
       "scale": R / "31_baseline_scale_glmm" / "glmm_scale_trend.csv",
       "scale_x": R / "31_baseline_scale_glmm" / "glmm_scale_interaction_ps_vs_control.csv",
       "standing": R / "31_baseline_standing_glmm" / "glmm_standing_trend.csv",
       "standing_x": R / "31_baseline_standing_glmm" / "glmm_standing_interaction_ps_vs_control.csv",
       "order": R / "39_language_order_tests" / "order_agreement_tests.csv"}


def bh(p):
    p = np.asarray(p, float); m = len(p); order = np.argsort(p); q = np.empty(m); prev = 1.0
    for rank, i in zip(range(m, 0, -1), order[::-1]):
        prev = min(prev, p[i] * m / rank); q[i] = prev
    return q


def rows_from(df, block, panel, family, key_col, est_col, p_col, keys, labels, single=False):
    out = []
    for k in keys:
        r = df[df[key_col] == k].iloc[0]
        out.append(dict(block=block, panel=panel, family=family, test=labels[k],
                        estimate=float(r[est_col]), p=float(r[p_col]), singular=bool(r["singular"]),
                        n_family=1 if single else len(keys)))
    return out


def main():
    d = {k: pd.read_csv(v) for k, v in SRC.items()}
    L = {"A_he": "he", "A_de": "de", "A_pg": "pg", "A_control": "control", "B_power_shifting": "power shifting (pooled)",
         "F_he_vs_control": "he vs control", "F_de_vs_control": "de vs control", "F_pg_vs_control": "pg vs control",
         "E_ps_vs_control": "power shifting vs control (pooled)"}
    fam = []
    fam += rows_from(d["modes"], "30", "Figure 1 · A types", "type contrasts (2)", "fit", "m2_logodds", "m2_p", ["he_vs_de", "de_vs_pg"],
                     {"he_vs_de": "de − he", "de_vs_pg": "pg − de"})
    fam += rows_from(d["origin"], "30", "Figure 1 · origin", "effect CN − US by type (4)", "fit", "cn_logodds", "cn_p", ["A_he", "A_de", "A_pg", "A_control"], L)
    fam += rows_from(d["origin"], "30", "Figure 1 · origin", "effect CN − US, pooled (1)", "fit", "cn_logodds", "cn_p", ["B_power_shifting"], L, single=True)
    fam += rows_from(d["origin_x"], "30", "Figure 1 · origin", "interaction CN × (type vs control) by type (3)", "fit", "cnxps_logodds", "cnxps_p",
                     ["F_he_vs_control", "F_de_vs_control", "F_pg_vs_control"], L)
    fam += rows_from(d["origin_x"], "30", "Figure 1 · origin", "interaction CN × (power shifting vs control), pooled (1)", "fit", "cnxps_logodds", "cnxps_p",
                     ["E_ps_vs_control"], L, single=True)
    for dim in ("scale", "standing"):
        P = f"Figure 1 · {'C scale' if dim == 'scale' else 'D standing'}"
        fam += rows_from(d[dim], "31", P, f"slope of {dim} by type (4)", "fit", "x_logodds", "x_p", ["A_he", "A_de", "A_pg", "A_control"], L)
        fam += rows_from(d[dim], "31", P, f"slope of {dim}, pooled (1)", "fit", "x_logodds", "x_p", ["B_power_shifting"], L, single=True)
        fam += rows_from(d[f"{dim}_x"], "31", P, f"interaction {dim} × (type vs control) by type (3)", "fit", "xxps_logodds", "xxps_p",
                         ["F_he_vs_control", "F_de_vs_control", "F_pg_vs_control"], L)
        fam += rows_from(d[f"{dim}_x"], "31", P, f"interaction {dim} × (power shifting vs control), pooled (1)", "fit", "xxps_logodds", "xxps_p",
                         ["E_ps_vs_control"], L, single=True)
    o = d["order"]
    groups = {"same origin − mixed, by type (4)": ["within − mixed"],
              "each bloc − mixed, by type (8)": ["CN–CN − mixed", "US–US − mixed"],
              "shared order, all pairs, by type (4)": ["all pairs"],
              "each pair type against shuffled languages, by type (12)": ["CN–CN", "US–US", "mixed"]}
    for family, stats_ in groups.items():
        sub = o[o.statistic.isin(stats_)]
        for _, r in sub.iterrows():
            fam.append(dict(block="39", panel="language · C agreement between rankings", family=family,
                            test=f"{r.statistic} · {r['mode']}", estimate=float(r.observed), p=float(r.p_right), singular=np.nan, n_family=len(sub)))
    tab = pd.DataFrame(fam)
    tab["q_bh"] = np.nan
    for (panel, family), sub in tab.groupby(["panel", "family"], sort=False):
        tab.loc[sub.index, "q_bh"] = bh(sub.p.values)
    tab["sig_p05"] = tab.p < .05; tab["sig_q05"] = tab.q_bh < .05

    res = report.Result(NAME)
    res.table("bh_families", tab)
    res.write()


if __name__ == "__main__":
    main()
