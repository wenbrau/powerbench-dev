import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import Boot, ci, report
from pbanalysis.datasets import load_d1_english, MODES as FP_MODES

NAME = "88_pg_excess"
SRC = HERE / "results" / "25_baseline_rates" / "components_excess_per_model.csv"
B, SEED = 5000, 25


def prompt_bootstrap():
    df = load_d1_english()
    bs = Boot(df, B=B, seed=SEED, modes=FP_MODES)
    targets = sorted(df.target.unique())
    R = {m: np.vstack([bs.rate(bs.mask(target=t), m) for t in targets]) for m in ("he", "de", "pg")}
    arrays = {"mean excess over the sum (pp)": 100 * (R["pg"] - R["he"] - R["de"]).mean(0),
              "mean excess over the union (pp)": 100 * (R["pg"] - (1 - (1 - R["he"]) * (1 - R["de"]))).mean(0)}
    rows = []
    for lab, arr in arrays.items():
        c = ci(arr)
        rows.append({"statistic": lab, "value": c["est"], "lo95": c["lo"], "hi95": c["hi"], "p": c["p"],
                     "test": "bootstrap over prompts"})
    return pd.DataFrame(rows)


def main():
    E = pd.read_csv(SRC)
    assert len(E) == 24 and {"group", "excess", "pg", "components", "origin"} <= set(E.columns), (len(E), E.columns.tolist())
    E["excess_sum"] = E.pg - (E.he + E.de)
    xs = E.excess_sum.to_numpy(float)
    x = E.excess.to_numpy(float); n = len(x)
    m = x.mean(); sd = x.std(ddof=1); se = sd / np.sqrt(n); tcrit = stats.t.ppf(.975, n - 1)
    t = stats.ttest_1samp(x, 0.0)
    w = stats.wilcoxon(x, alternative="two-sided")
    rows = [{"statistic": "mean excess (pp)", "value": m, "lo95": m - tcrit * se, "hi95": m + tcrit * se, "p": t.pvalue, "test": "one-sample t, 24 models"},
            {"statistic": "median excess (pp)", "value": float(np.median(x)), "lo95": np.nan, "hi95": np.nan, "p": w.pvalue, "test": "Wilcoxon signed-rank, 24 models"},
            {"statistic": "models with excess > 0", "value": int((x > 0).sum()), "lo95": np.nan, "hi95": np.nan, "p": stats.binomtest(int((x > 0).sum()), n, .5).pvalue, "test": "binomial against 1/2"}]
    for o in ("US", "CN"):
        xo = E.loc[E.origin == o, "excess"].to_numpy(float); to = stats.ttest_1samp(xo, 0.0); seo = xo.std(ddof=1) / np.sqrt(len(xo)); tc = stats.t.ppf(.975, len(xo) - 1)
        rows.append({"statistic": f"mean excess (pp), {o} models", "value": xo.mean(), "lo95": xo.mean() - tc * seo, "hi95": xo.mean() + tc * seo, "p": to.pvalue, "test": f"one-sample t, {len(xo)} models"})
    ms_, ses_ = xs.mean(), xs.std(ddof=1) / np.sqrt(n); ts_ = stats.ttest_1samp(xs, 0.0); ws_ = stats.wilcoxon(xs, alternative="two-sided")
    rows_sum = [{"statistic": "mean excess over the sum (pp)", "value": ms_, "lo95": ms_ - tcrit * ses_, "hi95": ms_ + tcrit * ses_, "p": ts_.pvalue, "test": "one-sample t, 24 models"},
                {"statistic": "median excess over the sum (pp)", "value": float(np.median(xs)), "lo95": np.nan, "hi95": np.nan, "p": ws_.pvalue, "test": "Wilcoxon signed-rank, 24 models"},
                {"statistic": "models with excess over the sum > 0", "value": int((xs > 0).sum()), "lo95": np.nan, "hi95": np.nan, "p": stats.binomtest(int((xs > 0).sum()), n, .5).pvalue, "test": "binomial against 1/2"}]
    for o in ("US", "CN"):
        xo = E.loc[E.origin == o, "excess_sum"].to_numpy(float); to = stats.ttest_1samp(xo, 0.0); seo = xo.std(ddof=1) / np.sqrt(len(xo)); tc = stats.t.ppf(.975, len(xo) - 1)
        rows_sum.append({"statistic": f"mean excess over the sum (pp), {o} models", "value": xo.mean(), "lo95": xo.mean() - tc * seo, "hi95": xo.mean() + tc * seo, "p": to.pvalue, "test": f"one-sample t, {len(xo)} models"})
    boot = prompt_bootstrap()
    TS = pd.concat([boot.iloc[[0]], pd.DataFrame(rows_sum)], ignore_index=True)
    T = pd.concat([boot.iloc[[1]], pd.DataFrame(rows)], ignore_index=True)

    res = report.Result(NAME)
    res.table("excess_sum_tests", TS)
    res.table("excess_tests", T)
    res.write()


if __name__ == "__main__":
    main()
