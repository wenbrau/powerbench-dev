import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd

from pbanalysis import report

NAME = "74_ai_agent_usage_weighted"
SRC = HERE / "results" / "22_d3_ai_agent" / "analysis_rows.csv.gz"
USAGE = HERE / "inputs" / "openrouter_usage.csv"
B_BOOT, SEED_BOOT = 1000, 63
B_PERM, SEED_PERM = 5000, 174
MODES = ["he", "de", "pg", "control"]
PS = "power_shifting"
GROUPS = MODES + [PS]


def logit(x):
    x = np.clip(x, 1e-6, 1 - 1e-6)
    return np.log(x / (1 - x))


def stat(cube, w):
    n = np.sum(np.isfinite(cube), axis=1)
    with np.errstate(invalid="ignore"):
        r = np.nansum(cube, axis=1) / np.where(n > 0, n, np.nan)
    ok = np.isfinite(r[:, 0]) & np.isfinite(r[:, 1]) & (w > 0)
    ww = w[ok] / w[ok].sum()
    rh, ra = float((ww * r[ok, 0]).sum()), float((ww * r[ok, 1]).sum())
    return float(logit(ra) - logit(rh)), 100 * (ra - rh), rh, ra, int(ok.sum())


def bh(p):
    p = np.asarray(p, float); m = len(p); order = np.argsort(p)
    q = np.empty(m); prev = 1.0
    for rank, i in zip(range(m, 0, -1), order[::-1]):
        prev = min(prev, p[i] * m / rank); q[i] = prev
    return q


def main():
    d = pd.read_csv(SRC, low_memory=False)
    d = d[(d.valid == True) & d["mode"].isin(MODES)].copy(); d["refuse"] = d.refuse.astype(float)
    use = pd.read_csv(USAGE).set_index("model")
    models = sorted(use.index)
    assert set(models) == set(d.model.unique()), "usage table does not match the panel"
    w = use.loc[models, "requests_30d"].to_numpy(float); w = w / w.sum()
    origin = d.drop_duplicates("model").set_index("model").loc[models, "origin"].to_numpy()
    neff = [dict(models="all", n_eff=float(1 / (w ** 2).sum()))]
    for o in ("US", "CN"):
        v = w * (origin == o); v = v / v.sum()
        neff.append(dict(models=o, n_eff=float(1 / (v ** 2).sum())))

    cubes, strata = {}, {}
    for mode in MODES:
        dm = d[d["mode"] == mode]
        prompts = sorted(dm.prompt_id.unique())
        cubes[mode] = np.stack([dm[dm.model == m].pivot(index="prompt_id", columns="condition", values="refuse")
                                .reindex(index=prompts, columns=["human", "ai"]).to_numpy(float) for m in models])
        strata[mode] = np.zeros(len(prompts), int)
    cubes[PS] = np.concatenate([cubes[m] for m in ("he", "de", "pg")], axis=1)
    strata[PS] = np.concatenate([np.full(cubes[m].shape[1], k) for k, m in enumerate(("he", "de", "pg"))])

    rng_boot = np.random.default_rng(SEED_BOOT)
    rows = []
    for g in GROUPS:
        cube, st = cubes[g], strata[g]
        est, pp, rh, ra, nm = stat(cube, w)
        blocks = [np.where(st == v)[0] for v in np.unique(st)]
        dr_or, dr_pp = np.empty(B_BOOT), np.empty(B_BOOT)
        for b in range(B_BOOT):
            idx = rng_boot.integers(0, cube.shape[1], cube.shape[1]) if g in MODES else \
                np.concatenate([rng_boot.choice(blk, len(blk), replace=True) for blk in blocks])
            s = stat(cube[:, idx, :], w); dr_or[b], dr_pp[b] = s[0], s[1]
        rng = np.random.default_rng(SEED_PERM)
        pm_or, pm_pp = np.empty(B_PERM), np.empty(B_PERM)
        for b in range(B_PERM):
            S = rng.random(cube.shape[:2]) < .5
            s = stat(np.where(S[:, :, None], cube[:, :, ::-1], cube), w); pm_or[b], pm_pp[b] = s[0], s[1]
        lo, hi = np.percentile(dr_or, [2.5, 97.5]); plo, phi = np.percentile(dr_pp, [2.5, 97.5])
        pboot = min(1.0, 2 * min((dr_or <= 0).mean(), (dr_or >= 0).mean()))
        pperm = (1 + (np.abs(pm_or) >= abs(est)).sum()) / (B_PERM + 1)
        pperm_pp = (1 + (np.abs(pm_pp) >= abs(pp)).sum()) / (B_PERM + 1)
        rows.append(dict(group=g, n_models=nm, n_prompts=int(cube.shape[1]),
                         rate_human=100 * rh, rate_ai=100 * ra, odds_ratio=float(np.exp(est)), boot_lo=float(np.exp(lo)), boot_hi=float(np.exp(hi)),
                         boot_p=float(pboot), perm_p=float(pperm), pp=float(pp), pp_boot_lo=float(plo), pp_boot_hi=float(phi), pp_perm_p=float(pperm_pp)))
    tab = pd.DataFrame(rows)
    tab["boot_q"] = np.nan; tab["perm_q"] = np.nan; tab["pp_perm_q"] = np.nan
    m = tab.group.isin(MODES)
    for src, dst in (("boot_p", "boot_q"), ("perm_p", "perm_q"), ("pp_perm_p", "pp_perm_q")):
        tab.loc[m, dst] = bh(tab.loc[m, src]); tab.loc[~m, dst] = tab.loc[~m, src]

    res = report.Result(NAME)
    res.table("usage_weighted_or_requests", tab)
    res.table("effective_models", pd.DataFrame(neff))
    res.write()


if __name__ == "__main__":
    main()
