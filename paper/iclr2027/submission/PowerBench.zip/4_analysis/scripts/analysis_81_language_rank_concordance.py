import sys
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import report
from pbanalysis.datasets import load_d1_multilingual

NAME = "81_language_rank_concordance"
LANGS = ["de", "pt", "en", "es", "sw", "zh", "fr", "hi"]
EXCL_SW = {"nemotron-3.5-lightning", "nova-2-lite"}
PS = ["he", "de", "pg"]
MODES = ["he", "de", "pg", "control"]
B_PERM, SEED = 5000, 81
B_POOL = 20000


def kendall_w(R):
    ranks = np.vstack([stats.rankdata(r) for r in R]); m, n = ranks.shape
    S = ((ranks.sum(0) - m * (n + 1) / 2) ** 2).sum()
    T = 0.0
    for r in ranks:
        _, c = np.unique(r, return_counts=True); T += float((c ** 3 - c).sum())
    return float(12 * S / (m ** 2 * (n ** 3 - n) - m * T))


def consensus_rho(Rps, ctrl):
    cons = np.vstack([stats.rankdata(r) for r in Rps]).mean(0)
    return float(stats.spearmanr(cons, ctrl).statistic)


def tci(v):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    half = stats.t.ppf(.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v)); tt = stats.ttest_1samp(v, 0.0)
    return dict(mean=float(v.mean()), lo=float(v.mean() - half), hi=float(v.mean() + half), t=float(tt.statistic), p_t=float(tt.pvalue), n=int(len(v)))


def main():
    df = load_d1_multilingual(); d = df[df.valid].copy()
    d = d[~((d.lang == "sw") & d.model.isin(EXCL_SW))]
    models = sorted(d.model.unique())
    rate = d.groupby(["model", "mode", "lang"]).refuse.mean().unstack("lang") * 100
    rng = np.random.default_rng(SEED)
    rows = []
    for m in models:
        langs = [l for l in LANGS if not (l == "sw" and m in EXCL_SW)]
        R = np.vstack([rate.loc[(m, md), langs].to_numpy(float) for md in MODES])
        Rps, ctrl = R[:3], R[3]
        w3, w4, rho = kendall_w(Rps), kendall_w(R), consensus_rho(Rps, ctrl)
        w3n = np.empty(B_PERM); w4n = np.empty(B_PERM); rhon = np.empty(B_PERM)
        for b in range(B_PERM):
            P = np.vstack([rng.permutation(r) for r in R])
            w3n[b], w4n[b], rhon[b] = kendall_w(P[:3]), kendall_w(P), consensus_rho(P[:3], P[3])
        rows.append(dict(model=m, W_ps_excess=w3 - float(w3n.mean()), p_W_ps=float((1 + (w3n >= w3).sum()) / (B_PERM + 1)),
                         W_all4_excess=w4 - float(w4n.mean()), p_W_all4=float((1 + (w4n >= w4).sum()) / (B_PERM + 1)),
                         rho_control_vs_ps=rho, p_rho=float((1 + (np.abs(rhon) >= abs(rho)).sum()) / (B_PERM + 1))))
    per = pd.DataFrame(rows)
    rmp = {}
    for m in models:
        langs = [l for l in LANGS if not (l == "sw" and m in EXCL_SW)]
        R = [rate.loc[(m, md), langs].to_numpy(float) for md in PS]
        rmp[m] = float(np.mean([stats.spearmanr(a, b).statistic for a, b in combinations(R, 2)]))
    per["rho_mean_pairs_ps"] = per.model.map(rmp)
    summ = pd.DataFrame([dict(question="Q1: W of the 3 power-shifting types, excess over chance", **tci(per.W_ps_excess), n_models_p05=int((per.p_W_ps < .05).sum())),
                         dict(question="Q1 in rho: mean Spearman between the orderings of he, de and pg", **tci(per.rho_mean_pairs_ps), n_models_p05=np.nan),
                         dict(question="Q2: rho of the control against the power-shifting consensus", **tci(per.rho_control_vs_ps), n_models_p05=int((per.p_rho < .05).sum())),
                         dict(question="ref: W of the 4 types, excess over chance", **tci(per.W_all4_excess), n_models_p05=int((per.p_W_all4 < .05).sum()))])

    res = report.Result(NAME)
    res.table("summary", summ)
    res.write()


if __name__ == "__main__":
    main()
