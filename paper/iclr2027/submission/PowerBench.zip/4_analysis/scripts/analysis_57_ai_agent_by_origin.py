import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats

from pbanalysis import report

NAME = "57_ai_agent_by_origin"
SRC_BIAS = HERE / "results" / "56_ai_agent_bias_direction" / "bias_direction_per_model.csv"
MODES = ["he", "de", "pg", "control"]


def main():
    bias = pd.read_csv(SRC_BIAS)
    rows = []
    for mode in MODES:
        for org in ("US", "CN"):
            e = bias[(bias["mode"] == mode) & (bias.origin == org)].bias.dropna().to_numpy()
            tt = stats.ttest_1samp(e, 0.0)
            half = stats.t.ppf(.975, len(e) - 1) * e.std(ddof=1) / np.sqrt(len(e))
            rows.append(dict(mode=mode, origin=org, n_models=len(e), mean=float(e.mean()), lo=float(e.mean() - half),
                             hi=float(e.mean() + half), sd_models=float(e.std(ddof=1)), t=float(tt.statistic), p_t=float(tt.pvalue),
                             n_positive=int((e > 0).sum())))

    res = report.Result(NAME)
    res.table("bias_direction_by_origin", pd.DataFrame(rows))
    res.write()


if __name__ == "__main__":
    main()
