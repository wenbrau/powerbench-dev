import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pandas as pd
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "89_bh_nationality_direction"
B46 = HERE / "results" / "46_nationality_direction_glmm"
SRC = {"pooled": B46 / "direction_glmm.csv", "dyad": B46 / "direction_glmm_by_dyad.csv"}
Q = "direction (24 models)"
QX = "direction x origin (CN - US)"
POWER_OF_DYAD = {"us_ally": "usa", "us_rival": "usa", "us_neutral": "usa", "us_cn": "usa",
                 "cn_ally": "china", "cn_rival": "china", "cn_neutral": "china", "cn_us": "china"}


def main():
    P0 = pd.read_csv(SRC["pooled"]); P = P0[P0.quantity == Q].copy(); X = P0[P0.quantity == QX].copy()
    D = pd.read_csv(SRC["dyad"]); D = D[D.quantity == Q].copy()
    assert len(P) == 8 and len(D) == 32 and len(X) == 8, (len(P), len(D), len(X))
    P["level"] = "pooled"; P["power"] = P.country
    D["level"] = "by_dyad"; D["power"] = D.dyad.map(POWER_OF_DYAD)
    X["level"] = "dc_interaction"; X["power"] = X.country
    assert D.power.notna().all()
    out = []
    for lvl, T in (("pooled", P), ("by_dyad", D), ("dc_interaction", X)):
        for pw, g in T.groupby("power"):
            g = g.copy()
            g["family"] = f"direction, {pw}, {lvl} ({len(g)} tests)"
            g["n_family"] = len(g)
            g["q_bh_power"] = multipletests(g.p, method="fdr_bh")[1]
            g["q_bh_46"] = g["q_bh"]
            out.append(g[["level", "power", "mode", "dyad", "estimate", "OR", "OR_lo", "OR_hi", "p", "q_bh_46", "q_bh_power", "family", "n_family"]])
    T = pd.concat(out, ignore_index=True)
    T["sig_q05_46"] = T.q_bh_46 < .05; T["sig_q05_power"] = T.q_bh_power < .05

    res = report.Result(NAME)
    res.table("bh_by_power", T)
    res.write()


if __name__ == "__main__":
    main()
