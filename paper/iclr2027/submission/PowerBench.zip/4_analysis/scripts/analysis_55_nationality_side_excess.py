import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "55_nationality_side_excess"
SRC = HERE / "results" / "45_nationality_side" / "side_per_model.csv"
MODES = ["he", "de", "pg", "control"]
SETS = ["geo", "neutral"]


def null_expected_abs_bias(n: int) -> float:
    a = np.arange(n + 1)
    return float(np.sum(stats.binom.pmf(a, n, .5) * np.abs(2 * a - n)) / n)


def main():
    pm = pd.read_csv(SRC)
    pm = pm[pm.n_discordant > 0].copy()
    pm["abs_bias"] = pm.bias.abs()
    pm["null_expected"] = pm.n_discordant.map(null_expected_abs_bias)
    pm["excess"] = pm.abs_bias - pm.null_expected
    rows = []
    for st in SETS:
        for mode in MODES:
            e = pm[(pm.set == st) & (pm["mode"] == mode)].excess.to_numpy()
            tt = stats.ttest_1samp(e, 0.0)
            half = stats.t.ppf(.975, len(e) - 1) * e.std(ddof=1) / np.sqrt(len(e))
            rows.append(dict(set=st, mode=mode, n_models=len(e), mean_abs_bias=float(pm[(pm.set == st) & (pm["mode"] == mode)].abs_bias.mean()),
                             null_expected_mean=float(pm[(pm.set == st) & (pm["mode"] == mode)].null_expected.mean()),
                             excess=float(e.mean()), lo=float(e.mean() - half), hi=float(e.mean() + half), sd_models=float(e.std(ddof=1)),
                             t=float(tt.statistic), p_t=float(tt.pvalue), n_excess_positive=int((e > 0).sum())))
    summ = pd.DataFrame(rows)
    summ["q_bh"] = summ.groupby("set").p_t.transform(lambda p: multipletests(p, method="fdr_bh")[1])
    summ["p_holm"] = summ.groupby("set").p_t.transform(lambda p: multipletests(p, method="holm")[1])

    res = report.Result(NAME)
    res.table("side_abs_bias_excess_per_model", pm[["set", "mode", "model", "origin", "n_discordant", "bias", "abs_bias", "null_expected", "excess"]])
    res.table("side_abs_bias_excess_summary", summ)
    res.write()


if __name__ == "__main__":
    main()
