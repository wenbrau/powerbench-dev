import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pandas as pd
from statsmodels.stats.multitest import multipletests

from pbanalysis import report

NAME = "83_bh_ai_agent_nationality"
SRC = {"64": HERE / "results" / "64_ai_agent_capability_glmm" / "capability_glmm.csv",
       "45": HERE / "results" / "45_nationality_side" / "side_glmm.csv"}
MODES = ["he", "de", "pg", "control"]


def bh(p):
    return multipletests(p.astype(float).to_numpy(), method="fdr_bh")[1]


def main():
    rows = []
    g = pd.read_csv(SRC["64"]); pool = g[g.run == "pooled"]
    it = pool[(pool.quantity == "ai x capability (per 1 SD)") & pool.set.isin(["power_shifting", "control"])].set_index("set").loc[["power_shifting", "control"]]
    for (st, r), q in zip(it.iterrows(), bh(it.p)):
        rows.append(dict(block=64, panel="F", family="ai x capability, pooled (power shifting, control)", n_family=2,
                         test=st, estimate=float(r.OR_or_ratio), p=float(r.p), q_bh=float(q)))
    st = pool[(pool.set == "stacked") & (pool.quantity == "slope difference (ps - control)")].iloc[0]
    rows.append(dict(block=64, panel="F", family="slope difference (single test)", n_family=1,
                     test="ps - control", estimate=float(st.OR_or_ratio), p=float(st.p), q_bh=float(st.p)))
    s = pd.read_csv(SRC["45"]); s = s[s.quantity == "side (24 models)"]
    for set_ in ("geo", "neutral"):
        t = s[s.set == set_].set_index("mode").loc[MODES]
        for (m, r), q in zip(t.iterrows(), bh(t.p)):
            rows.append(dict(block=45, panel="B", family=f"user side, set {set_} (4 types)", n_family=4,
                             test=m, estimate=float(r.OR), p=float(r.p), q_bh=float(q)))
    tab = pd.DataFrame(rows); tab["sig_p05"] = tab.p < .05; tab["sig_q05"] = tab.q_bh < .05

    res = report.Result(NAME)
    res.table("bh_families", tab)
    res.write()


if __name__ == "__main__":
    main()
