import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from pbanalysis import report
from pbanalysis.datasets import load_d1_multilingual

NAME = "26_language_rates"
LANGS = ["en", "de", "fr", "es", "zh", "pt", "hi", "sw"]


def main():
    df = load_d1_multilingual()
    tr = (df.groupby(["lang", "model", "origin"], sort=False)
            .agg(n=("row_id", "size"), valid=("valid", "sum"), over5000=("truncated", "sum"))
            .reset_index())
    tr["valid"] = tr["valid"].astype(int)
    tr["pct_over5000"] = 100 * tr.over5000 / tr.n
    trl = df.groupby("lang", sort=False).agg(n=("row_id", "size"), over5000=("truncated", "sum")).reset_index()
    trl["pct_over5000"] = 100 * trl.over5000 / trl.n
    trl = trl.set_index("lang").loc[LANGS].reset_index()
    res = report.Result(NAME)
    res.table("truncation_by_language_model", tr)
    res.table("truncation_by_language", trl)
    res.write()


if __name__ == "__main__":
    main()
