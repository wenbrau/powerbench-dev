import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from analysis_19_d1_english import point_rates
from pbanalysis import report
from pbanalysis.conditions import load_d2


def main():
    df=load_d2()
    res=report.Result('21_d2_nationality')
    res.table('per_model_rates', point_rates(df,factor='condition'))
    res.table('data_audit', df.groupby(['model','origin','condition','mode']).agg(rows=('valid','size'),valid=('valid','sum'),truncated=('truncated','sum')).reset_index())
    res.write()


if __name__=='__main__':main()
