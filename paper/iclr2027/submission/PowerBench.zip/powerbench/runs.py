import gzip
import json


def read_rows(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                yield json.loads(line)


def response_status(row):
    text = row.get("response") or ""
    if text.startswith("__ERROR__"):
        return "error"
    if not text.strip() or row.get("empty", False):
        return "empty"
    return "ok"
