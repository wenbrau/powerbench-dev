MODELS = {
    "anthropic/claude-haiku-4.5": {"short": "haiku-4.5", "origin": "US", "lab": "Anthropic"},
    "openai/gpt-5.6-luna": {"short": "gpt-5.6-luna", "origin": "US", "lab": "OpenAI"},
    "openai/gpt-5.6-sol": {"short": "gpt-5.6-sol", "origin": "US", "lab": "OpenAI"},
    "openai/gpt-5.6-terra": {"short": "gpt-5.6-terra", "origin": "US", "lab": "OpenAI"},
    "anthropic/claude-sonnet-5": {"short": "sonnet-5", "origin": "US", "lab": "Anthropic"},
    "thinkingmachines/inkling": {"short": "inkling", "origin": "US", "lab": "Thinking Machines"},
    "x-ai/grok-4.3": {"short": "grok-4.3", "origin": "US", "lab": "xAI"},
    "nvidia/nemotron-3-ultra-550b-a55b": {"short": "nemotron-3-ultra", "origin": "US", "lab": "NVIDIA"},
    "nvidia/nemotron-3.5-lightning": {"short": "nemotron-3.5-lightning", "origin": "US", "lab": "NVIDIA"},
    "google/gemma-4-31b-it": {"short": "gemma-4-31b", "origin": "US", "lab": "Google"},
    "google/gemini-3.1-flash-lite": {"short": "gemini-3.1-flash-lite", "origin": "US", "lab": "Google"},
    "amazon/nova-2-lite-v1": {"short": "nova-2-lite", "origin": "US", "lab": "Amazon"},
    "moonshotai/kimi-k3": {"short": "kimi-k3", "origin": "CN", "lab": "Moonshot"},
    "qwen/qwen3.8-flash": {"short": "qwen3.8-flash", "origin": "CN", "lab": "Alibaba"},
    "qwen/qwen3.8-27b": {"short": "qwen3.8-27b", "origin": "CN", "lab": "Alibaba"},
    "qwen/qwen3.7-plus": {"short": "qwen3.7-plus", "origin": "CN", "lab": "Alibaba"},
    "z-ai/glm-5.2": {"short": "glm-5.2", "origin": "CN", "lab": "Zhipu"},
    "bytedance-seed/seed-2-1-turbo": {"short": "seed-2-1-turbo", "origin": "CN", "lab": "ByteDance"},
    "tencent/hy3": {"short": "hy3", "origin": "CN", "lab": "Tencent"},
    "xiaomi/mimo-v2.5-pro": {"short": "mimo-v2.5-pro", "origin": "CN", "lab": "Xiaomi"},
    "inclusionai/ling-3.0-flash": {"short": "ling-3.0-flash", "origin": "CN", "lab": "InclusionAI"},
    "minimax/minimax-m3": {"short": "minimax-m3", "origin": "CN", "lab": "MiniMax"},
    "moonshotai/kimi-k2.6": {"short": "kimi-k2.6", "origin": "CN", "lab": "Moonshot"},
    "deepseek/deepseek-v4-pro-0813": {"short": "deepseek-v4-pro", "origin": "CN", "lab": "DeepSeek"},
}

PANEL = tuple(MODELS)


def short(t):
    return MODELS[t]["short"]


def origin(t):
    return MODELS[t]["origin"]


def lab(t):
    return MODELS[t]["lab"]
