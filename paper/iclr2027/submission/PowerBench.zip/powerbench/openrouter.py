import json
import time
import urllib.error
import urllib.request

URL = "https://openrouter.ai/api/v1/chat/completions"
LEAK_TOLERANCE = 1


def post(payload, key, attempts=8):
    req = urllib.request.Request(URL, json.dumps(payload).encode(),
                                 {"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    t0 = time.time()
    n429 = n429_account = 0
    error = ""
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                d = json.load(r)
            ch = d["choices"][0]
            usage = {**d.get("usage", {}), "finish_reason": ch.get("finish_reason"),
                     "service_tier": d.get("service_tier")}
            timing = {"latency_s": round(time.time() - t0, 1), "retries_429": n429,
                      "retries_429_account": n429_account}
            return ch["message"].get("content") or "", usage, d.get("provider"), timing
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode("utf-8", "replace")[:400]
            except Exception:
                detail = ""
            error = f"__ERROR__ {e} {detail}"
            if e.code == 429 and attempt < attempts - 1:
                low = detail.lower()
                if "provider returned error" in low or '"provider_name"' in low:
                    n429 += 1
                else:
                    n429_account += 1
                ra = e.headers.get("Retry-After")
                time.sleep(float(ra) if ra and ra.replace(".", "").isdigit() else min(3 * 2 ** attempt, 45))
                continue
        except Exception as e:
            error = f"__ERROR__ {e}"
        if attempt < attempts - 1:
            time.sleep(2 * (attempt + 1))
    return error, {"finish_reason": "error"}, None, None


def reasoning_tokens(usage):
    return ((usage or {}).get("completion_tokens_details") or {}).get("reasoning_tokens", 0) or 0


def verified(arm, usage):
    rt = reasoning_tokens(usage)
    return rt <= LEAK_TOLERANCE if arm == "off" else rt > LEAK_TOLERANCE
