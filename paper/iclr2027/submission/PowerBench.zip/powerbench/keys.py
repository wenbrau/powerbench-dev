import os


def api_key(required=True):
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key and required:
        raise SystemExit("Set OPENROUTER_API_KEY.")
    return key or None
