import json

from .paths import PINS


def load(path=PINS / "pins.json"):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def provider_block(pin):
    block = {"only": [pin["tag"]], "allow_fallbacks": False}
    if pin["quantization"] != "unknown":
        block["quantizations"] = [pin["quantization"]]
    return block
