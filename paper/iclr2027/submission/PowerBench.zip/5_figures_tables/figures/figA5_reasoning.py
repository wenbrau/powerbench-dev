import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import style, MODE_COLORS, ORIGIN, ORIGIN_LIGHT
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

MODES = ["he", "de", "pg", "ctl"]
LABEL = {"he": "SE", "de": "DE", "pg": "PG", "ctl": "CT"}
COLOR = {"he": MODE_COLORS["he"], "de": MODE_COLORS["de"], "pg": MODE_COLORS["pg"], "ctl": MODE_COLORS["control"]}
LEVELS = ["off", "r1", "r2"]
TICKS = ["Off", "Level 1", "Level 2"]
GROUPS = {"US": dict(color=ORIGIN["US"], band=ORIGIN_LIGHT["US"], ls="-", marker="o", label="US models (4)"),
          "CN": dict(color=ORIGIN["CN"], band=ORIGIN_LIGHT["CN"], ls="-", marker="o", label="CN models (4)"),
          "all": dict(color="#222222", band="#BBBBBB", ls="--", marker="s", label="All 8 models")}
FB, FT, FL = 6.5, 6.0, 9.0


def restyle():
    style()
    plt.rcParams.update({"legend.fontsize": FT, "axes.titlesize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "axes.labelsize": FB, "font.size": FB})


def panel(ax, d, mode):
    xs = np.arange(3)
    for g in ("US", "CN", "all"):
        s = d[(d["mode"] == mode) & (d.group == g)].set_index("level").loc[LEVELS]; st = GROUPS[g]
        ax.fill_between(xs, s.lo.clip(lower=0), s.hi, color=st["band"], alpha=.35 if g != "all" else .3, lw=0, zorder=1)
        ax.plot(xs, s.rate, ls=st["ls"], marker=st["marker"], ms=2.2, lw=.9, color=st["color"], zorder=3)
    ax.set_xticks(xs, TICKS); ax.set_xlim(-.2, 2.2); ax.grid(axis="y", alpha=.15)
    ax.set_title(LABEL[mode], loc="center", color=COLOR[mode])


def main():
    restyle()
    d = pd.read_csv(RESULTS / "68_reasoning_glmm" / "panel_a_curves.csv")
    fig = plt.figure(figsize=(5.5, 1.8), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.04, wspace=.03)
    gs = fig.add_gridspec(1, 4)
    axes = [fig.add_subplot(gs[0, 0])]
    axes += [fig.add_subplot(gs[0, i], sharey=axes[0]) for i in range(1, 4)]
    for ax, mode in zip(axes, MODES):
        panel(ax, d, mode)
    axes[0].set_ylim(0, 60); axes[0].set_ylabel("Refusal (%)")
    fig.supxlabel("Reasoning effort", fontsize=FB)
    for ax in axes[1:]:
        ax.tick_params(labelleft=False)
    axes[0].legend(handles=[Line2D([], [], color=GROUPS[g]["color"], ls=GROUPS[g]["ls"], marker=GROUPS[g]["marker"], ms=2.4, lw=.9,
                                   label=GROUPS[g]["label"]) for g in ("US", "CN", "all")],
                   frameon=False, loc="upper right", handlelength=1.8, labelspacing=.25, borderaxespad=.1)
    fig.canvas.draw()
    for ax, s in zip(axes, "ABCD"):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(max(x0 - .06, .002) if s == "A" else x0 - .02, y0 + h + .025, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA5_reasoning.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
