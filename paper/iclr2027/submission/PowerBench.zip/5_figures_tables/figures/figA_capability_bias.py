import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import ORIGIN
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

FB, FT = 6.5, 6.0
SRC = {"per_model": RESULTS / "96_capability_per_model" / "per_model_values.csv",
       "ai": RESULTS / "84_ai_agent_capability_ivw" / "capability_per_model_log_or_ivw.csv",
       "fits": RESULTS / "97_intervals_capability_fits" / "capability_bias_fits.csv",
       "glmm": RESULTS / "64_ai_agent_capability_glmm" / "capability_glmm.csv",
       "cap": RESULTS / "30_baseline_glmm" / "capability_index.csv"}
ROWS = [("ai_agent", "AI agent", "log OR, agent vs human"),
        ("nationality", "Nationality", "|bias| $-$ chance"),
        ("language", "Language", "range $-$ chance (pp)")]
COLS = [("power_shifting", "power shifting"), ("control", "control")]
COLVAL = {("nationality", "power_shifting"): "B1_geo_excess_ps", ("nationality", "control"): "B1_geo_excess_ct",
          ("language", "power_shifting"): "B2_range_excess_pp_ps", ("language", "control"): "B2_range_excess_pp_ct"}


def style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": FB, "axes.titlesize": FB + .5, "axes.titleweight": "bold", "axes.titlelocation": "left",
        "axes.titlepad": 3, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT, "legend.fontsize": FT,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .6, "xtick.major.width": .5, "ytick.major.width": .5,
        "xtick.major.size": 2.2, "ytick.major.size": 2.2, "lines.linewidth": .8, "savefig.facecolor": "white", "pdf.fonttype": 42,
    })


def points(pm, ai, exp_, st):
    if exp_ == "ai_agent":
        s = ai[ai.set == ("power_shifting_pooled" if st == "power_shifting" else "control")]
        return s.capability.to_numpy(), s.log_or.to_numpy(), s.origin.to_numpy()
    d = pm[["capability_index", COLVAL[(exp_, st)], "origin"]].dropna()
    return d.capability_index.to_numpy(), d[COLVAL[(exp_, st)]].to_numpy(), d.origin.to_numpy()


def line(fits, gl, mu, sd, exp_, st, xs):
    zs = (xs - mu) / sd
    if exp_ == "ai_agent":
        g = gl[(gl.run == "pooled") & (gl.set == st)].set_index("quantity")
        ai, it = g.loc["ai (mean capability)"], g.loc["ai x capability (per 1 SD)"]
        att = float(np.sqrt(1 + (16 * np.sqrt(3) / (15 * np.pi)) ** 2 * ai.sd_prompt ** 2))
        return (ai.estimate + it.estimate * zs) / att
    f = fits.loc[(exp_, st)]
    return f.intercept + f.slope_per_sd * zs


def main():
    style()
    pm = pd.read_csv(SRC["per_model"]); ai = pd.read_csv(SRC["ai"])
    fits = pd.read_csv(SRC["fits"]).set_index(["experiment", "set"]); gl = pd.read_csv(SRC["glmm"])
    cap = pd.read_csv(SRC["cap"]); mu, sd = cap["index"].mean(), cap["index"].std(ddof=1)
    fig, axes = plt.subplots(3, 2, figsize=(5.5, 5.2), sharex=True, layout="constrained")
    for r, (exp_, rtitle, ylab) in enumerate(ROWS):
        for c, (st, ctitle) in enumerate(COLS):
            ax = axes[r, c]
            x, y, o = points(pm, ai, exp_, st)
            for org in ("US", "CN"):
                m = o == org
                ax.plot(x[m], y[m], "o", ms=2.6, color=ORIGIN[org], alpha=.85, zorder=3)
            xs = np.linspace(np.nanmin(x) - 1, np.nanmax(x) + 1, 50); ys = line(fits, gl, mu, sd, exp_, st, xs)
            ax.plot(xs, ys, color="#222222", lw=1.0, zorder=4)
            if fits.loc[(exp_, st), "q_bh"] < .05:
                ax.text(xs[-1] + .6, ys[-1], "*", ha="left", va="center", fontsize=FB + 2, zorder=5)
            ax.axhline(0, color="black", lw=.5, ls=":", zorder=1); ax.grid(alpha=.15)
            ax.set_title(f"{rtitle}: {ctitle}", fontsize=FB)
            if c == 0:
                ax.set_ylabel(ylab)
            if r == 2:
                ax.set_xlabel("capability index (%)")
        lo = min(axes[r, 0].get_ylim()[0], axes[r, 1].get_ylim()[0]); hi = max(axes[r, 0].get_ylim()[1], axes[r, 1].get_ylim()[1])
        axes[r, 0].set_ylim(lo, hi); axes[r, 1].set_ylim(lo, hi)
    axes[0, 1].legend(handles=[Line2D([], [], marker="o", ls="", ms=3, color=ORIGIN["US"], label="US model"),
                               Line2D([], [], marker="o", ls="", ms=3, color=ORIGIN["CN"], label="CN model")], frameon=False, loc="upper left")
    fig.savefig(FIGURES / "figA_capability_bias.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
