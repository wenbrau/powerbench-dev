from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import RESULTS, FIGURES
from style import style, ORIGIN, short
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

FB, FT, FMIN, FL = 6.5, 6.0, 5.5, 9.0
MODES = ["he", "de", "pg", "control"]
SHORT = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}
KINDS = ["CN–CN", "US–US", "mixed"]
KIND_LABEL = {"CN–CN": "CN–CN", "US–US": "US–US", "mixed": "Mixed"}
KIND_COLOR = {"CN–CN": ORIGIN["CN"], "US–US": ORIGIN["US"], "mixed": "#8A7FA3"}
CHANCE = "#9AA0A6"
ALL = RESULTS / "language_all_models"


def star(ax, x, y, va="bottom"):
    ax.text(x, y, "*", ha="center", va=va, fontsize=FB + 1.5, fontweight="bold", color="#1A1A1A")


def main():
    style()
    plt.rcParams.update({"font.size": FB, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "legend.fontsize": FT, "axes.titlesize": FB + .5, "axes.titlepad": 3})
    exc = {m: pd.read_csv(ALL / f"range_excess_pp_{m}.csv").set_index("model") for m in MODES}
    r = pd.read_csv(RESULTS / "78_baseline_panels" / "rates_per_model.csv")
    r["mean4"] = r[MODES].mean(axis=1)
    r = r[r.model.isin(exc["pg"].index.tolist())]
    r = r.assign(o=r.origin.map({"US": 0, "CN": 1})).sort_values(["o", "mean4"], ascending=[True, False])
    models, origin = r.model.tolist(), dict(zip(r.model, r.origin))
    assert len(models) == 24
    E = np.array([[exc[m].loc[mod, "excess"] for m in MODES] for mod in models])
    Q = np.array([[exc[m].loc[mod, "q_bh"] for m in MODES] for mod in models])
    st = pd.read_csv(ALL / "rank_agreement_tests.csv")
    st = st[st.test == "test1_langperm"]

    fig = plt.figure(figsize=(5.5, 3.15))
    axA = fig.add_axes([.195, .135, .20, .79])
    axB = fig.add_axes([.585, .135, .405, .79])

    cmap = mcolors.LinearSegmentedColormap.from_list("exc", ["#FFFFFF", "#C9C3D6", "#6E6390", "#2E2445"])
    norm = mcolors.PowerNorm(gamma=.6, vmin=0, vmax=40)
    im = axA.imshow(np.clip(E, 0, None), cmap=cmap, norm=norm, aspect="auto")
    n = len(models)
    for i in range(n):
        for j in range(len(MODES)):
            if Q[i, j] < .05:
                axA.text(j, i + .08, "*", ha="center", va="center", fontsize=FB + 1, fontweight="bold",
                         color="white" if norm(max(E[i, j], 0)) > .55 else "#1A1A1A")
    axA.set_yticks(range(n), [short(m) for m in models])
    for lab, m in zip(axA.get_yticklabels(), models):
        lab.set_color(ORIGIN[origin[m]])
    axA.set_xticks(range(len(MODES)), [SHORT[m] for m in MODES], rotation=35, ha="right", rotation_mode="anchor")
    axA.tick_params(length=0, pad=1.5)
    axA.axhline(sum(origin[m] == "US" for m in models) - .5, color="black", lw=.6)
    for sp in axA.spines.values():
        sp.set_visible(False)
    cax = axA.inset_axes([1.06, .0, .07, .30])
    cb = fig.colorbar(im, cax=cax, orientation="vertical", ticks=[0, 10, 20, 30, 40])
    cb.ax.tick_params(labelsize=FMIN, width=.4, length=1.5, pad=1); cb.outline.set_linewidth(.4)
    cb.set_label("Excess over chance (pp)", fontsize=FMIN, labelpad=2)
    axA.set_title("Range beyond chance", x=-.3)

    x = np.arange(len(MODES)); bw = .25
    for k, kind in enumerate(KINDS):
        for xi, m in zip(x, MODES):
            row = st[(st["mode"] == m) & (st.quantity == kind)].iloc[0]
            xk = xi + (k - 1) * bw
            axB.add_patch(plt.Rectangle((xk - bw * .43, row.null_lo), bw * .86, row.null_hi - row.null_lo, facecolor=CHANCE,
                                        alpha=.35, edgecolor="none", zorder=1))
            axB.bar(xk, row.observed, width=bw * .58, color=KIND_COLOR[kind], zorder=2,
                    label=KIND_LABEL[kind] if m == MODES[0] else None)
    for xi, m in zip(x, MODES):
        s = st[st["mode"] == m].set_index("quantity").loc[KINDS]
        q = multipletests(s.p.values, method="fdr_bh")[1]
        for k, (kind, qq) in enumerate(zip(KINDS, q)):
            if qq < .05:
                y = s.loc[kind, "observed"]; xk = xi + (k - 1) * bw
                if y >= 0:
                    star(axB, xk, max(y, s.loc[kind, "null_hi"]) + .005)
                else:
                    star(axB, xk, min(y, s.loc[kind, "null_lo"]) - .005, va="top")
    axB.axhline(0, color="black", lw=.6, zorder=1.5)
    axB.set_xticks(x, [SHORT[m] for m in MODES])
    axB.set_xlim(-.55, len(MODES) - .45)
    axB.set_ylim(-.23, .3); axB.set_yticks([-.2, -.1, 0, .1, .2, .3])
    axB.set_ylabel("Mean Spearman correlation between\ntwo models' language orders")
    axB.grid(axis="y", alpha=.15)
    h, l = axB.get_legend_handles_labels()
    h.append(Patch(facecolor=CHANCE, alpha=.35, edgecolor="none")); l.append("Chance (95%)")
    axB.legend(h, l, frameon=False, ncol=2, loc="lower left", handlelength=.9, handletextpad=.4, columnspacing=.9,
               borderaxespad=.2, fontsize=FT)
    axB.set_title("Agreement by pair type")
    for ax, s, xo in ((axA, "A", .005), (axB, "B", .475)):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(xo, y0 + h + .012, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA4_by_mode.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
