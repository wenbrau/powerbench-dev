from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import RESULTS, FIGURES
from style import style, MODE_COLORS, DIVERGING_CMAP, text_on
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

FB, FT, FMIN, FL = 6.5, 6.0, 5.5, 9.0
PS = "power_shifting"
LANG_NAME = {"en": "English", "de": "German", "fr": "French", "es": "Spanish", "pt": "Portuguese", "zh": "Chinese",
             "hi": "Hindi", "sw": "Swahili"}


def main():
    style()
    plt.rcParams.update({"font.size": FB, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "legend.fontsize": FT, "axes.titlesize": FB + .5, "axes.titlepad": 3})
    summ = pd.read_csv(RESULTS / "79_language_pairwise_bias" / "pairwise_bias_summary.csv")
    summ = summ[summ.group == PS].set_index(["lang_a", "lang_b"]).bias
    pairs = pd.read_csv(RESULTS / "80_language_bias_vs_prevalence" / "pairs.csv")
    ols = pd.read_csv(RESULTS / "80_language_bias_vs_prevalence" / "summary.csv").set_index("kind").loc["ols_28_pairs"]
    order = ["de", "pt", "en", "es", "sw", "zh", "fr", "hi"]
    rows, cols = order[1:], order[:-1]
    M = np.full((len(rows), len(cols)), np.nan)
    for i, a in enumerate(rows):
        for j, b in enumerate(cols):
            if order.index(b) < order.index(a):
                M[i, j] = summ.loc[(a, b)]
    assert np.isfinite(M).sum() == 28

    fig = plt.figure(figsize=(5.5, 2.3))
    axA = fig.add_axes([.125, .195, .315, .71])
    axB = fig.add_axes([.60, .195, .385, .71])

    vlim = .25
    im = axA.imshow(np.ma.masked_invalid(M), cmap=DIVERGING_CMAP, vmin=-vlim, vmax=vlim, aspect="auto")
    for i in range(len(rows)):
        for j in range(len(cols)):
            v = M[i, j]
            if np.isfinite(v):
                s = f"{v:+.2f}".replace("0.", ".").replace("-", "−")
                axA.text(j, i, s, ha="center", va="center", fontsize=FMIN, color=text_on(im.cmap(im.norm(v))))
    axA.set_xticks(range(len(cols)), [LANG_NAME[l] for l in cols], rotation=35, ha="right", rotation_mode="anchor")
    axA.set_yticks(range(len(rows)), [LANG_NAME[l] for l in rows])
    axA.tick_params(length=0, pad=1.5)
    for sp in axA.spines.values():
        sp.set_visible(False)
    cax = axA.inset_axes([.60, .80, .36, .045])
    cb = fig.colorbar(im, cax=cax, orientation="horizontal", ticks=[-.2, 0, .2])
    cb.ax.tick_params(labelsize=FMIN, width=.4, length=1.5, pad=1); cb.outline.set_linewidth(.4)
    cb.ax.set_xticklabels(["−.2", "0", "+.2"])
    cb.set_label("Row refused more →", fontsize=FMIN, labelpad=1.5)
    cb.ax.xaxis.set_label_position("top")
    axA.set_title("Direction bias, row vs column", x=-.25)

    axB.axhline(0, color="black", lw=.6, zorder=1)
    axB.axvline(0, color="#BBBBBB", lw=.5, zorder=1)
    xx = np.array([pairs.dlog_share.min() - .2, pairs.dlog_share.max() + .2])
    axB.plot(xx, ols.intercept + ols.slope * xx, color="#222", lw=.9, zorder=2)
    axB.scatter(pairs.dlog_share, pairs.bias, s=11, color=MODE_COLORS[PS], edgecolor="white", linewidth=.4, zorder=3)
    axB.set_xlabel("log10 web-text share, row − column")
    axB.set_ylabel("Direction bias")
    axB.set_xlim(-4, 3.1); axB.set_xticks([-4, -3, -2, -1, 0, 1, 2, 3])
    axB.set_ylim(-.07, .24); axB.set_yticks([-.05, 0, .05, .1, .15, .2])
    axB.grid(alpha=.15)
    axB.set_title("Bias vs web prevalence")
    for ax, s, xo in ((axA, "A", .005), (axB, "B", .50)):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(xo, y0 + h + .012, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA4_pairs_prevalence.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
