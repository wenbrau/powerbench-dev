import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, MODE_LABEL, ORIGIN, ORIGIN_LABEL, ERR, GFMT, or_axis, tight_style
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def main():
    tight_style()
    S = pd.read_csv(RESULTS / "45_nationality_side" / "side_glmm.csv"); S = S[S.set == "geo"]
    qty = {"US": "side, US models", "CN": "side, CN models"}
    fig, ax = plt.subplots(figsize=(3.4, 1.9), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.02)
    x = np.arange(4); wd = .36; LO, HI = .6, 1.75
    for k, o in enumerate(("US", "CN")):
        r = S[S.quantity == qty[o]].set_index("mode").loc[MODES].copy(); xo = x + (k - .5) * wd
        r["OR"], r["OR_lo"], r["OR_hi"] = 1 / r.OR, 1 / r.OR_hi, 1 / r.OR_lo
        ax.bar(xo, r.OR - 1, bottom=1, width=wd, color=ORIGIN[o], zorder=2, label=f"{ORIGIN_LABEL[o]} (12)")
        ax.errorbar(xo, r.OR, yerr=[r.OR - r.OR_lo, r.OR_hi - r.OR], **ERR)
    or_axis(ax, [.7, .8, 1, 1.25, 1.5], LO, HI); ax.yaxis.set_major_formatter(GFMT)
    ax.set_xticks(x, [MODE_LABEL[m] for m in MODES]); ax.tick_params(axis="x", length=0); ax.set_xlim(-.6, 3.6)
    ax.set_ylabel("Refusal OR, US-side vs\nChina-side target")
    ax.legend(frameon=False, loc="upper left", handlelength=1.1, borderaxespad=.2)
    fig.savefig(FIGURES / "figA2_origin.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
