import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODE_LABEL, ORIGIN, ORIGIN_LABEL, axes_letters, tight_style
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandas as pd


def main():
    tight_style()
    R = pd.read_csv(RESULTS / "78_baseline_panels" / "rates_per_model.csv")
    fig, axes = plt.subplots(1, 3, figsize=(5.5, 1.95), sharex=True, sharey=True, layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.02, wspace=.06)
    lim = (0, 56)
    for ax, m in zip(axes, ("he", "de", "pg")):
        ax.plot(lim, lim, ls="--", color="#9A9A9A", lw=.6, zorder=1)
        for o in ("US", "CN"):
            s = R[R.origin == o]
            ax.scatter(s.control, s[m], s=10, color=ORIGIN[o], edgecolor="white", linewidth=.3, zorder=3)
        ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal")
        ax.set_xticks([0, 20, 40]); ax.set_yticks([0, 20, 40]); ax.grid(alpha=.15)
        ax.set_title(MODE_LABEL[m]); ax.set_xlabel("Control refusal (%)")
    axes[0].set_ylabel("Refusal in the request type (%)")
    axes[0].legend(handles=[Line2D([], [], ls="", marker="o", ms=3, mfc=ORIGIN[o], mec="white", mew=.3, label=ORIGIN_LABEL[o]) for o in ("US", "CN")],
                   frameon=False, loc="upper left", handletextpad=.2, borderaxespad=.2)
    axes_letters(zip(axes, "ABC"))
    fig.savefig(FIGURES / "figA1_model_level.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
