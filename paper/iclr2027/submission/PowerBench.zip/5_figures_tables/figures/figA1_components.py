import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, MODE_COLORS, ORIGIN, ERR, short, tight_style
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def model_order():
    R = pd.read_csv(RESULTS / "78_baseline_panels" / "rates_per_model.csv")
    R["mean4"] = R[MODES].mean(axis=1)
    return pd.concat([R[R.origin == o].sort_values("mean4", ascending=False) for o in ("US", "CN")])[["model", "origin", "mean4"]]


def main():
    tight_style()
    C = pd.read_csv(RESULTS / "25_baseline_rates" / "components_excess_per_model.csv").set_index("group")
    order = model_order(); C = C.loc[order.model]
    x = np.arange(len(C))
    fig, ax = plt.subplots(figsize=(5.5, 2.0), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.02)
    ax.bar(x, C.he + C.de, width=.82, color="#C9CCD1", zorder=2, label="Sum of SE and DE refusal")
    ax.bar(x, C.pg, width=.44, color=MODE_COLORS["pg"], zorder=3, label="PG refusal")
    ax.errorbar(x, C.pg, yerr=[C.pg - C.pg_lo, C.pg_hi - C.pg], **ERR)
    ax.set_xticks(x, [short(m) for m in C.index], rotation=45, ha="right", rotation_mode="anchor")
    ax.tick_params(axis="x", length=0, pad=1.5)
    for tk, o in zip(ax.get_xticklabels(), order.origin):
        tk.set_color(ORIGIN[o])
    ax.axvline(11.5, color="#999", lw=.5, ls=":")
    ax.set_xlim(-.7, len(C) - .3); ax.set_ylim(0, 62); ax.grid(axis="y", alpha=.15)
    ax.set_ylabel("Refusal (%)")
    ax.legend(frameon=False, loc="upper right", handlelength=1.2, borderaxespad=.2)
    fig.savefig(FIGURES / "figA1_components.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
