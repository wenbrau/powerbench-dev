import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import style, ORIGIN
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

MODES = ["he", "de", "pg", "control"]
LABEL = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}
FB, FT, FL = 6.5, 6.0, 9.0
B64 = RESULTS / "64_ai_agent_capability_glmm"


def restyle():
    style()
    plt.rcParams.update({"legend.fontsize": FT, "axes.titlesize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "axes.labelsize": FB, "font.size": FB})


def panel(ax, pm, fr, cap, mode):
    for org in ("US", "CN"):
        s = pm[pm.origin == org]
        ax.errorbar(s.capability, s.log_or, yerr=1.96 * s.se, fmt="o", color=ORIGIN[org], ecolor=ORIGIN[org], elinewidth=.5,
                    alpha=.8, ms=2.2, capsize=0, zorder=3)
    ai, it = fr.loc["ai (mean capability)"], fr.loc["ai x capability (per 1 SD)"]
    mu, sd = cap["index"].mean(), cap["index"].std(ddof=1)
    att = float(np.sqrt(1 + (16 * np.sqrt(3) / (15 * np.pi)) ** 2 * ai.sd_prompt ** 2))
    xs = np.linspace(pm.capability.min() - 1, pm.capability.max() + 1, 50); zs = (xs - mu) / sd
    ax.plot(xs, (ai.estimate + it.estimate * zs) / att, color="#222222", lw=1.0, zorder=4)
    ax.axhline(0, color="black", lw=.5, ls=":", zorder=1); ax.grid(alpha=.15)
    ax.set_title(LABEL[mode] + (" *" if it.q_bh < .05 else ""), loc="center")


def main():
    restyle()
    pm = pd.read_csv(B64 / "capability_per_model_log_or.csv")
    gl = pd.read_csv(B64 / "capability_glmm.csv")
    cap = pd.read_csv(RESULTS / "30_baseline_glmm" / "capability_index.csv")
    fig = plt.figure(figsize=(5.5, 1.7), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.04, wspace=.03)
    gs = fig.add_gridspec(1, 4)
    axes = [fig.add_subplot(gs[0, 0])]
    axes += [fig.add_subplot(gs[0, i], sharey=axes[0], sharex=axes[0]) for i in range(1, 4)]
    for ax, mode in zip(axes, MODES):
        fr = gl[(gl.run == "bymode") & (gl.set == mode)].set_index("quantity")
        panel(ax, pm[pm.set == mode], fr, cap, mode)
    axes[0].set_ylim(-2.2, 3.2); axes[0].set_yticks([-2, -1, 0, 1, 2, 3]); axes[0].set_xticks([50, 60, 70])
    axes[0].set_ylabel("log OR, AI vs human")
    for ax in axes[1:]:
        ax.tick_params(labelleft=False)
    fig.supxlabel("Capability index (%)", fontsize=FB)
    axes[3].legend(handles=[Line2D([], [], marker="o", ls="", ms=2.4, color=ORIGIN["US"], label="US model"),
                            Line2D([], [], marker="o", ls="", ms=2.4, color=ORIGIN["CN"], label="CN model"),
                            Line2D([], [], color="#222222", lw=1.0, label="GLMM")],
                   frameon=False, loc="upper left", handlelength=1.2, labelspacing=.25, borderaxespad=.1)
    fig.canvas.draw()
    for ax, s in zip(axes, "ABCD"):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(max(x0 - .06, .002) if s == "A" else x0 - .02, y0 + h + .025, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA3_capability_by_mode.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
