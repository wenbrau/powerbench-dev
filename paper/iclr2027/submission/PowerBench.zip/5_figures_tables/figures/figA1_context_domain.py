import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, MODE_LABEL, axes_letters, tight_style
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
import numpy as np
import pandas as pd

CTX = ["Fiction", "Work", "Government", "Interpersonal", "Diplomacy", "Academia", "Markets", "Media"]
DOM = ["Rank", "Wealth", "Health", "Legal", "Physical", "Epistemic", "Status", "Attentional"]


def main():
    tight_style()
    L = pd.read_csv(RESULTS / "25_baseline_rates" / "context_domain_levels_pooled.csv"); L = L[L.bloc == "all"]
    G = pd.read_csv(RESULTS / "33_baseline_domain_glmm" / "glmm_domain_by_domain.csv")
    qdom = {(r.fit.split("_")[1], r.domain): r.p_bh for r in G.itertuples()}
    cmap = LinearSegmentedColormap.from_list("refusal", ["#F7F5FA", "#B9A9D3", "#6A4C9C", "#2E1B52"])
    norm = Normalize(0, 40)
    fig = plt.figure(figsize=(5.5, 2.3), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.02, wspace=.03)
    gs = fig.add_gridspec(1, 3, width_ratios=[4, 3, .16])
    axC, axD, cax = fig.add_subplot(gs[0]), fig.add_subplot(gs[1]), fig.add_subplot(gs[2])
    for ax, fac, levels, modes, title in ((axC, "context", CTX, MODES, "By context"), (axD, "domain", DOM, MODES[:3], "By domain")):
        s = L[L.factor == fac].set_index(["level", "mode"]).rate
        M = np.array([[s.loc[(lv, m)] for m in modes] for lv in levels])
        ax.pcolormesh(np.arange(len(modes) + 1) - .5, np.arange(len(levels) + 1) - .5, M, cmap=cmap, norm=norm,
                      edgecolors="white", linewidth=.8)
        for i, lv in enumerate(levels):
            for j, m in enumerate(modes):
                q = qdom.get((m, lv), np.nan) if fac == "domain" else np.nan
                txt = f"{M[i, j]:.0f}" + ("*" if np.isfinite(q) and q < .05 else "")
                ax.text(j, i, txt, ha="center", va="center", fontsize=6.0, color="white" if M[i, j] > 22 else "#222")
        ax.set_xlim(-.5, len(modes) - .5); ax.set_ylim(len(levels) - .5, -.5)
        ax.set_xticks(range(len(modes)), [MODE_LABEL[m] for m in modes]); ax.set_yticks(range(len(levels)), levels)
        ax.tick_params(length=0)
        for sp in ax.spines.values():
            sp.set_visible(False)
        ax.set_title(title)
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax)
    cb.set_label("Refusal (%), mean of 24 models"); cb.outline.set_visible(False); cb.ax.tick_params(length=2)
    axes_letters([(axC, "A"), (axD, "B")])
    fig.savefig(FIGURES / "figA1_context_domain.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
