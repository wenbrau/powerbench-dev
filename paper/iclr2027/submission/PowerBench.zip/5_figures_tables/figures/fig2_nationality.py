import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, PS, MODE_COLORS, ORIGIN, or_axis, shade_dir, tight_style
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgb
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

SRC = {"B": RESULTS / "55_nationality_side_excess" / "side_abs_bias_excess_summary.csv",
       "C": RESULTS / "45_nationality_side" / "side_glmm.csv",
       "D": RESULTS / "73_nationality_usage_weighted" / "side_or_requests.csv",
       "E": RESULTS / "46_nationality_direction_glmm" / "direction_glmm.csv",
       "E_dyad": RESULTS / "46_nationality_direction_glmm" / "direction_glmm_by_dyad.csv",
       "bh83": RESULTS / "83_bh_ai_agent_nationality" / "bh_families.csv",
       "bh89": RESULTS / "89_bh_nationality_direction" / "bh_by_power.csv",
       "pmr": RESULTS / "21_d2_nationality" / "per_model_rates.csv",
       "A86": RESULTS / "86_nationality_power_shifting" / "ps_rates_by_side.csv", "B86": RESULTS / "86_nationality_power_shifting" / "side_abs_bias_excess_ps.csv",
       "C86": RESULTS / "86_nationality_power_shifting" / "side_glmm_ps.csv",
       "A_ci": RESULTS / "97_intervals_capability_fits" / "side_rates_ci.csv"}
SETS = ("geo", "neutral")
MODES5 = list(MODES) + [PS]; XS = np.array([0, 1, 2, 3, 4.45]); XSEP = 3.72
SIDE_CONDS = {"geo": {"us": ["us_cn", "allyus_allycn"], "cn": ["cn_us", "allycn_allyus"]},
              "neutral": {"us": ["neutralA_neutralB"], "cn": ["neutralB_neutralA"]}}
SIDE_COL = {"us": "#2E6FB0", "cn": "#C0392B"}
DESAT = {"us": .20, "cn": .45}
DY = {"usa": ["us_ally", "us_neutral", "us_rival", "us_cn"], "china": ["cn_ally", "cn_neutral", "cn_rival", "cn_us"]}
FB, FT, FL = 6.5, 6.0, 9.0
NEUTRAL_BG = "#666666"
MODE_LEG = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT", PS: "PS (pooled)"}
DYL = {"us_ally": "ally", "us_neutral": "neutral", "us_rival": "rival", "us_cn": "China", "cn_ally": "ally", "cn_neutral": "neutral", "cn_rival": "rival", "cn_us": "US"}


def mix(c, target, f):
    a, b = np.array(to_rgb(c)), np.array(to_rgb(target))
    return tuple(a + (b - a) * f)


def load():
    B = pd.read_csv(SRC["B"]).set_index(["set", "mode"])
    C = pd.read_csv(SRC["C"]); C = C[C.quantity == "side (24 models)"].set_index(["set", "mode"])
    q83 = pd.read_csv(SRC["bh83"]); q83 = q83[q83.block == 45]
    C["q_bh"] = [float(q83[(q83.family == f"user side, set {st} (4 types)") & (q83.test == m)].q_bh.iloc[0]) for st, m in C.index]
    D = pd.read_csv(SRC["D"]).set_index(["set", "group"])
    E = pd.read_csv(SRC["E"]); E = E[E.quantity == "direction (24 models)"].copy()
    Ed = pd.read_csv(SRC["E_dyad"]); Ed = Ed[Ed.quantity == "direction (24 models)"].copy()
    q89 = pd.read_csv(SRC["bh89"])
    qp = q89[q89.level == "pooled"].set_index(["power", "mode"]).q_bh_power
    qd = q89[q89.level == "by_dyad"].set_index(["dyad", "mode"]).q_bh_power
    E["q_bh"] = [float(qp[(c, m)]) for c, m in zip(E.country, E["mode"])]
    Ed["q_bh"] = [float(qd[(d, m)]) for d, m in zip(Ed.dyad, Ed["mode"])]
    pmr = pd.read_csv(SRC["pmr"])
    vals = {(st, m, s): float(pmr[(pmr["mode"] == m) & pmr.condition.isin(SIDE_CONDS[st][s])].groupby("target").rate.mean().mean())
            for st in SETS for m in MODES for s in ("us", "cn")}
    A86 = pd.read_csv(SRC["A86"]).set_index(["set", "side"]).mean_rate
    vals.update({(st, PS, s): float(A86[(st, s)]) for st in SETS for s in ("us", "cn")})
    B86 = pd.read_csv(SRC["B86"]).set_index("set"); C86 = pd.read_csv(SRC["C86"]).set_index("set")
    return B, C, D, E, Ed, vals, B86, C86


def or_panel(ax, OR, l, h, q, lo, hi, shade=True, ticks=(.7, 1, 1.5)):
    x = XS; OR, l, h = np.asarray(OR, float), np.asarray(l, float), np.asarray(h, float)
    OR, l, h = 1 / OR, 1 / h, 1 / l
    ax.bar(x, OR - 1, bottom=1, width=.6, color=[MODE_COLORS[m] for m in MODES5], zorder=2)
    ax.errorbar(x, OR, yerr=[OR - l, h - OR], fmt="none", ecolor="#111", elinewidth=.55, capsize=1.3, capthick=.55, zorder=3)
    for xi, o, ll, hh, qi in zip(x, OR, l, h, q):
        if qi < .05:
            if o >= 1:
                ax.text(xi, hh * 1.02, "*", ha="center", va="bottom", fontsize=FB + 1)
            else:
                ax.text(xi, ll / 1.03, "*", ha="center", va="top", fontsize=FB + 1)
    or_axis(ax, list(ticks), lo, hi)
    if shade:
        shade_dir(ax, lo, hi)


def build(data):
    tight_style()
    B, C, D, E, Ed, vals, B86, C86 = data
    cols5 = [MODE_COLORS[m] for m in MODES5]
    H0, H = 3.95, 3.15
    top, bottom = 1 - ((1 - .83) * H0 - .15) / H, .065 * H0 / H
    gap = .45 * ((.83 - .065) * H0 / (4 + 3 * .45))
    rowh = ((top - bottom) * H - 3 * gap) / 4
    fig = plt.figure(figsize=(5.5, H))
    gs = fig.add_gridspec(4, 4, height_ratios=[.75, 1.08, 1.08, 1.08], width_ratios=[1.0, 1.0, .22, 1.6], left=.12, right=.985, top=top, bottom=bottom, hspace=gap / rowh, wspace=.14)
    x = XS; w = .38

    def row(ri):
        a0 = fig.add_subplot(gs[ri, 0]); a1 = fig.add_subplot(gs[ri, 1], sharey=a0); a1.tick_params(labelleft=False)
        return [a0, a1]
    axA, axB, axC, axD = row(0), row(1), row(2), row(3)
    for ax in axA + axB + axC + axD:
        ax.set_xticks(x, [""] * 5); ax.set_xlim(-.6, XS[-1] + .6); ax.axvline(XSEP, color="#999", lw=.5, ls=":", zorder=1)

    CI = pd.read_csv(SRC["A_ci"]).set_index(["set", "mode", "side"])
    ytop = max(max(vals.values()), float(CI.hi.max())) * 1.08
    for ax, st in zip(axA, SETS):
        for i, m in enumerate(MODES5):
            if st != "geo":
                ax.bar(x[i], ytop, 2 * w + .02, color=NEUTRAL_BG, alpha=.14, lw=0, zorder=1)
            for side, off in (("us", -w / 2), ("cn", w / 2)):
                ds = {"us": "cn", "cn": "us"}[side]
                if st == "geo":
                    ax.bar(x[i] + off, ytop, w + .02, color=SIDE_COL[side], alpha=.14, lw=0, zorder=1)
                ax.bar(x[i] + off, vals[(st, m, ds)], w, color=mix(MODE_COLORS[m], "#FFFFFF", DESAT[side]),
                       edgecolor=mix(MODE_COLORS[m], "#FFFFFF", DESAT[side] * .5), lw=.3, zorder=2)
                ci = CI.loc[(st, m, ds)]
                assert abs(float(ci["mean"]) - vals[(st, m, ds)]) < 1e-6
                ax.errorbar(x[i] + off, ci["mean"], yerr=[[ci["mean"] - ci.lo], [ci.hi - ci["mean"]]], fmt="none", ecolor="#222", elinewidth=.5, capsize=1.0, capthick=.5, zorder=3)
        ax.grid(axis="y", alpha=.15); ax.set_ylim(0, ytop)
    axA[0].set_title("Refusal by target side"); axA[1].set_title("neutral countries", fontweight="normal")

    for ax, st in zip(axB, SETS):
        r = B.loc[st].loc[MODES]; b = B86.loc[st]
        ex = np.array(list(r.excess) + [b.excess]); lo = np.array(list(r.lo) + [b.lo]); hi = np.array(list(r.hi) + [b.hi]); q = list(r.q_bh) + [b.q_bh]
        ax.bar(x, ex, width=.6, color=cols5, zorder=2)
        ax.errorbar(x, ex, yerr=[ex - lo, hi - ex], fmt="none", ecolor="#222", elinewidth=.55, capsize=1.3, capthick=.55, zorder=3)
        ax.axhline(0, color="black", lw=.6, ls="--", zorder=1)
        for xi, h, qi in zip(x, hi, q):
            if qi < .05:
                ax.text(xi, max(h, 0) + .005, "*", ha="center", va="bottom", fontsize=FB + 1)
        ax.grid(axis="y", alpha=.15); ax.set_ylim(-.145, .30)
    axB[0].set_title("Bias beyond chance")

    LO, HI = .68, 1.62
    LO, HI, TK = 1 / HI, 1 / LO, (.7, 1, 1.4)
    for ax, st in zip(axC, SETS):
        r = C.loc[st].loc[MODES]; g = C86.loc[st]
        or_panel(ax, list(r.OR) + [g.OR], list(r.OR_lo) + [g.OR_lo], list(r.OR_hi) + [g.OR_hi], list(r.q_bh) + [g.q_bh], LO, HI, shade=st == "geo", ticks=TK)
    for ax, st in zip(axD, SETS):
        r = D.loc[st].loc[MODES5]; or_panel(ax, r.odds_ratio, r.boot_lo, r.boot_hi, r.boot_q.values, LO, HI, shade=st == "geo", ticks=TK)
    axC[0].set_title("US side vs China side"); axD[0].set_title("Same, usage-weighted")

    gsR = gs[:, 3].subgridspec(2, 1, hspace=.26 * H0 / H)
    axE = fig.add_subplot(gsR[0]); axF = fig.add_subplot(gsR[1])
    w4 = .8 / len(MODES); ELO, EHI = .5, 1.9
    ELO, EHI, ETK = 1 / EHI, 1 / ELO, [.67, 1, 1.5, 2]
    for ax, pole in ((axE, "usa"), (axF, "china")):
        P = "US" if pole == "usa" else "China"
        groups = [("joint", "all four")] + [(dy, DYL[dy]) for dy in DY[pole]]; xg = np.arange(len(groups))
        for k, mode in enumerate(MODES):
            v = pd.DataFrame([(E[(E.country == pole) & (E["mode"] == mode)] if key == "joint" else Ed[(Ed.dyad == key) & (Ed["mode"] == mode)]).iloc[0]
                              for key, _ in groups])
            v = v.assign(OR=1 / v.OR, OR_lo=1 / v.OR_hi, OR_hi=1 / v.OR_lo)
            xo = xg + (k - (len(MODES) - 1) / 2) * w4
            ax.bar(xo, v.OR.values - 1, bottom=1, width=w4, color=MODE_COLORS[mode], alpha=.9, zorder=2)
            ax.errorbar(xo, v.OR.values, yerr=[v.OR.values - v.OR_lo.values, v.OR_hi.values - v.OR.values], fmt="none", ecolor="#111", elinewidth=.5, capsize=1.1, capthick=.5, zorder=3)
            for xi, (_, rr) in zip(xo, v.iterrows()):
                if rr.q_bh < .05:
                    if rr.OR >= 1:
                        ax.text(xi, rr.OR_hi * 1.02, "*", ha="center", va="bottom", fontsize=FB + 1)
                    else:
                        ax.text(xi, rr.OR_lo / 1.03, "*", ha="center", va="top", fontsize=FB + 1)
        or_axis(ax, ETK, ELO, EHI)
        ax.axvspan(-.5, .5, color="#000", alpha=.05, zorder=0); ax.axvline(.5, color="#666", lw=.6, ls="--")
        ax.axhspan(1, EHI, color=ORIGIN["US" if pole == "usa" else "CN"], alpha=.07, zorder=0)
        ax.set_xticks(xg, [g[1] for g in groups], fontsize=FT)
        ax.set_ylabel(f"OR, {P} as target / as user")
        ax.set_title(f"Bias with respect to {P}")

    fig.legend(handles=[Patch(fc=MODE_COLORS[m], label=MODE_LEG[m]) for m in MODES5] + [Patch(fc=SIDE_COL["us"], alpha=.2, label="US-side target"), Patch(fc=SIDE_COL["cn"], alpha=.2, label="China-side target")],
               frameon=False, fontsize=FT, loc="upper center", bbox_to_anchor=(.5, 1.0), ncol=7, columnspacing=1.0, handlelength=1.1)
    for st, ax in zip(SETS, axA):
        p = ax.get_position()
        fig.text(p.x0 + p.width / 2, p.y1 + .06 * H0 / H, "US side / China side" if st == "geo" else "neutral A / neutral B", ha="center", va="bottom", fontsize=FB, fontweight="bold")
    fig.canvas.draw(); inv = fig.transFigure.inverted()
    xr = min(inv.transform(t.get_window_extent().get_points())[0, 0] for ax in (axA[0], axB[0], axC[0], axD[0]) for t in ax.get_yticklabels() if t.get_text()) - .01
    pa, pb, pc, pd_ = (ax[0].get_position() for ax in (axA, axB, axC, axD))
    A_, B_ = "China", "US"
    ORL = "OR" + chr(10) + A_ + " " + chr(8594) + " " + B_ + chr(10) + "/ " + B_ + " " + chr(8594) + " " + A_
    for yc, txt in (((pa.y0 + pa.y1) / 2, "Refusal (%)"), ((pb.y0 + pb.y1) / 2, "|bias|" + chr(10) + "$-$ chance"),
                    ((pc.y0 + pc.y1) / 2, ORL), ((pd_.y0 + pd_.y1) / 2, ORL)):
        fig.text(xr, yc, txt, rotation=90, ha="right", va="center", multialignment="center", fontsize=FB, linespacing=1.15)
    for key, axr in (("A", axA), ("B", axB), ("C", axC), ("D", axD)):
        g = axr[0].get_position(); fig.text(g.x0 - .012, g.y1 + .012 * H0 / H, key, fontsize=FL, fontweight="bold", ha="right", va="bottom")
    pe = axE.get_position(); fig.text(pe.x0 - .012, pe.y1 + .012 * H0 / H, "E", fontsize=FL, fontweight="bold", ha="right", va="bottom")
    fig.savefig(FIGURES / "fig2_nationality.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    build(load())
