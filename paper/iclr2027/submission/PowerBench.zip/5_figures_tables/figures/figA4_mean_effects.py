from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import RESULTS, FIGURES
from style import style, MODE_COLORS, or_axis
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

FB, FT, FL = 6.5, 6.0, 9.0
PS = "power_shifting"
GROUPS = ["he", "de", "pg", "control", PS]
SHORT = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT", PS: "PS"}
LANG_NAME = {"en": "English", "de": "German", "fr": "French", "es": "Spanish", "pt": "Portuguese", "zh": "Chinese",
             "hi": "Hindi", "sw": "Swahili"}


def star(ax, x, y):
    ax.text(x, y, "*", ha="center", va="bottom", fontsize=FB + 1.5, fontweight="bold", color="#1A1A1A")


def main():
    style()
    plt.rcParams.update({"font.size": FB, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "legend.fontsize": FT, "axes.titlesize": FB + .5, "axes.titlepad": 3})
    dev = pd.read_csv(RESULTS / "82_language_glmm_power_shifting" / "language_deviation_ps.csv")
    orr = pd.read_csv(RESULTS / "72_language_usage_weighted" / "usage_weighted_or_requests.csv")
    langs = dev.lang.tolist()
    fig = plt.figure(figsize=(5.5, 2.0))
    axA = fig.add_axes([.085, .275, .265, .575])
    axB = fig.add_axes([.445, .275, .545, .575])

    x = np.arange(len(langs))
    axA.bar(x, dev.estimate, width=.62, color=MODE_COLORS[PS], zorder=2)
    axA.errorbar(x, dev.estimate, yerr=[dev.estimate - dev.lo, dev.hi - dev.estimate], fmt="none", ecolor="#222",
                 elinewidth=.6, capsize=1.4, capthick=.6, zorder=3)
    axA.axhline(0, color="black", lw=.6, zorder=1)
    for xi, r in zip(x, dev.itertuples()):
        if r.p_bh < .05:
            star(axA, xi, r.hi + .02)
    axA.set_xticks(x, [LANG_NAME[l] for l in langs], rotation=50, ha="right", rotation_mode="anchor")
    axA.set_xlim(-.6, len(langs) - .4)
    axA.set_ylim(-.5, .65); axA.set_yticks([-.4, -.2, 0, .2, .4, .6])
    axA.set_ylabel("Deviation (log-odds)")
    axA.grid(axis="y", alpha=.15)
    axA.set_title("Pooled power shifting")

    langsB = [l for l in langs if l != "en"]
    xb = np.arange(len(langsB)); bw = .16
    for k, g in enumerate(GROUPS):
        t = orr[orr.group == g].set_index("lang").loc[langsB]
        xs = xb + (k - 2) * bw
        axB.bar(xs, t.odds_ratio - 1, bottom=1, width=bw * .92, color=MODE_COLORS[g], label=SHORT[g], zorder=2)
        axB.errorbar(xs, t.odds_ratio, yerr=[t.odds_ratio - t.boot_lo, t.boot_hi - t.odds_ratio], fmt="none",
                     ecolor="#222", elinewidth=.5, capsize=1.0, capthick=.5, zorder=3)
        for xi, r in zip(xs, t.itertuples()):
            if r.boot_q < .05:
                star(axB, xi, r.boot_hi * 1.01)
    or_axis(axB, [.5, .67, 1, 1.5, 2], .52, 2.75)
    axB.set_yticks([.5, .67, 1, 1.5, 2], ["0.5", "0.67", "1", "1.5", "2"])
    axB.yaxis.set_minor_locator(mticker.NullLocator())
    axB.set_xticks(xb, [LANG_NAME[l] for l in langsB], rotation=30, ha="right", rotation_mode="anchor")
    axB.set_xlim(-.55, len(langsB) - .45)
    axB.set_ylabel("Odds ratio vs English")
    axB.legend(frameon=False, ncol=5, loc="lower left", bbox_to_anchor=(-.01, .985), handlelength=.9, handletextpad=.4,
               columnspacing=.9, borderaxespad=0, fontsize=FT)
    for ax, s, xo in ((axA, "A", .005), (axB, "B", .365)):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(xo, y0 + h + .012, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA4_mean_effects.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
