import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, PS, MODE_LABEL, MODE_COLORS, ORIGIN, letters, short, tight_style
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

B78 = RESULTS / "78_baseline_panels"
SRC = {"A": B78 / "pA_mean_by_mode.csv", "B": B78 / "pB_by_origin.csv", "B_all": B78 / "origin_overall_glmm.csv",
       "C": RESULTS / "70_baseline_model_mean_refusal" / "model_mean_refusal.csv",
       "C_ci": RESULTS / "97_intervals_capability_fits" / "model_mean_refusal_ci.csv", "DE": B78 / "pDE_levels.csv",
       "bh": RESULTS / "77_bh_baseline_language" / "bh_families.csv", "FG": B78 / "pFG_context_domain.csv", "omni": B78 / "glmm_omnibus.csv"}
GROUPS = MODES + [PS]
FACTORS = {"scale": ["individual", "group", "society"], "standing": ["low", "med", "high"]}
LEVEL_LABEL = {"individual": "Individual", "group": "Group", "society": "Society", "low": "Low", "med": "Med", "high": "High"}
FB, FT = 6.5, 6.0
SHORT = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT", PS: "PS"}
CTRL_COLOR = "#9A9EA3"
CTX_SHORT = {"Interpersonal": "Interpers.", "Government": "Governm.", "Diplomacy": "Diplomacy", "Attentional": "Attention."}


def load():
    A = pd.read_csv(SRC["A"]).set_index("group"); B = pd.read_csv(SRC["B"]); Ball = pd.read_csv(SRC["B_all"]).iloc[0]
    C = pd.read_csv(SRC["C"]); LV = pd.read_csv(SRC["DE"]); bh = pd.read_csv(SRC["bh"])
    CD = pd.read_csv(SRC["FG"]); omni = pd.read_csv(SRC["omni"]).set_index("fit")
    bhq = {}
    for fac, pan in (("scale", "Figure 1 · C scale"), ("standing", "Figure 1 · D standing")):
        sub = bh[(bh.panel == pan) & bh.family.str.startswith(f"slope of {fac} by type")]
        bhq[fac] = dict(zip(sub.test, sub.q_bh)); assert set(bhq[fac]) == set(MODES), (fac, bhq[fac])
    return A, B, Ball, C, LV, bhq, CD, omni


def star(ax, x, y, q):
    if q < .05:
        ax.text(x, y, "*", ha="center", va="bottom", fontsize=FB + 1, zorder=5)


def panel_a(ax, A):
    x = np.arange(len(MODES)); a = A.loc[MODES]
    ax.bar(x, a["mean"], width=.62, color=[MODE_COLORS[g] for g in MODES], zorder=2)
    ax.errorbar(x, a["mean"], yerr=[a["mean"] - a.lo, a.hi - a["mean"]], fmt="none", ecolor="#222", elinewidth=.6, capsize=1.5, capthick=.6, zorder=3)
    ax.set_xticks(x, [SHORT[g] for g in MODES])
    ax.set_ylabel("Refusal (%)"); ax.grid(axis="y", alpha=.15); ax.set_title("By request type")


def panel_b(ax, B):
    x = np.arange(len(GROUPS)); wd = .38
    for k, o in enumerate(("US", "CN")):
        s = B[B.origin == o].set_index("group").loc[GROUPS]; xo = x + (k - .5) * wd
        ax.bar(xo, s["mean"], width=wd, color=[MODE_COLORS[g] for g in GROUPS], alpha=.5 if o == "US" else .95,
               edgecolor=[MODE_COLORS[g] for g in GROUPS], lw=.5, zorder=2)
        ax.errorbar(xo, s["mean"], yerr=[s["mean"] - s.lo, s.hi - s["mean"]], fmt="none", ecolor="#222", elinewidth=.55, capsize=1.3, capthick=.55, zorder=3)
    q = B.drop_duplicates("group").set_index("group").q
    for xi, g in zip(x, GROUPS):
        star(ax, xi, float(B[B.group == g].hi.max()) + .6, q[g])
    ax.legend(handles=[Patch(facecolor="#888", alpha=.5, edgecolor="#888", label="US (12)"), Patch(facecolor="#888", alpha=.95, label="CN (12)")],
              frameon=False, loc="upper left", handlelength=1.1, borderaxespad=.2)
    ax.set_xticks(x, [SHORT[g] for g in GROUPS])
    ax.set_ylabel("Refusal (%)"); ax.grid(axis="y", alpha=.15); ax.set_title("US vs CN by request type")
    ax.set_ylim(0, float(B.hi.max()) * 1.25)


def panel_c(ax, C):
    Cs = pd.concat([C[C.origin == "US"].sort_values("mean_all", ascending=False), C[C.origin == "CN"].sort_values("mean_all", ascending=False)])
    x = np.arange(len(Cs))
    ax.bar(x, Cs.mean_all, width=.75, color=[ORIGIN[o] for o in Cs.origin], zorder=2)
    ci = pd.read_csv(SRC["C_ci"]).set_index("model").loc[Cs.model]
    assert np.allclose(ci.mean_all.round(2).values, Cs.mean_all.values, atol=.011)
    ax.errorbar(x, Cs.mean_all, yerr=[Cs.mean_all.values - ci.lo.values, ci.hi.values - Cs.mean_all.values], fmt="none", ecolor="#222", elinewidth=.45, capsize=.8, capthick=.45, zorder=3)
    ax.set_xticks(x, [short(m) for m in Cs.model], fontsize=FT, rotation=90); ax.tick_params(axis="x", length=0, pad=1.2)
    for tk, o in zip(ax.get_xticklabels(), Cs.origin):
        tk.set_color(ORIGIN[o])
    ax.axvline(11.5, color="#999", lw=.5, ls=":"); ax.set_xlim(-.7, len(Cs) - .3); ax.grid(axis="y", alpha=.15)
    ax.set_ylabel("Refusal (%)"); ax.set_title("Mean refusal by model")


def panel_de(ax, LV, bhq, fac, first):
    lv = LV[LV.factor == fac]; xs = np.arange(3)
    for mode in MODES:
        s = lv[lv["mode"] == mode].set_index("level").loc[FACTORS[fac]]
        ax.plot(xs, s["mean"], marker="o", ms=2.2, color=MODE_COLORS[mode], lw=1.0, label=MODE_LABEL[mode], zorder=3)
        ax.fill_between(xs, s.lo, s.hi, color=MODE_COLORS[mode], alpha=.15, lw=0, zorder=2)
        if bhq[fac][mode] < .05:
            ax.text(2.12, float(s["mean"].iloc[-1]), "*", ha="left", va="center", fontsize=FB + 1, color=MODE_COLORS[mode])
    ax.set_xticks(xs, [LEVEL_LABEL[s_] for s_ in FACTORS[fac]]); ax.set_xlim(-.15, 2.35)
    ax.set_ylabel("Refusal (%)" if first else ""); ax.set_xlabel("scale of the target" if fac == "scale" else "user's prior power standing")
    ax.grid(axis="y", alpha=.15); ax.set_ylim(0, 50)
    if not first:
        ax.legend(frameon=False, loc="upper left", handlelength=1.3, labelspacing=.2, borderaxespad=.1)
    ax.set_title("By scale" if fac == "scale" else "By power standing")


def control_by_context():
    L = pd.read_csv(RESULTS / "25_baseline_rates" / "context_domain_levels_pooled.csv")
    L = L[(L.bloc == "all") & (L["mode"] == "control") & (L.factor == "context")]
    return L.set_index("level")[["rate", "lo", "hi"]]


def panel_fg(ax, CD, fac):
    s = CD[CD.factor == fac].sort_values("mean", ascending=True); y = np.arange(len(s))
    if fac == "context":
        c = control_by_context().loc[s.level]; h = .38
        ax.barh(y + h / 2, s["mean"], height=h, color=MODE_COLORS[PS], alpha=.85, zorder=2, label="PS")
        ax.barh(y - h / 2, c.rate, height=h, color=CTRL_COLOR, alpha=.85, zorder=2, label="CT")
        ax.errorbar(s["mean"], y + h / 2, xerr=[s["mean"] - s.lo, s.hi - s["mean"]], fmt="none", ecolor="#222", elinewidth=.55, capsize=1.1, capthick=.55, zorder=3)
        ax.errorbar(c.rate, y - h / 2, xerr=[c.rate - c.lo, c.hi - c.rate], fmt="none", ecolor="#222", elinewidth=.55, capsize=1.1, capthick=.55, zorder=3)
        ax.legend(frameon=False, loc="lower right", handlelength=1.0, labelspacing=.15, borderaxespad=.1, fontsize=FT)
        xmax = max(float(s.hi.max()), float(c.hi.max()))
        ystar = y + h / 2
    else:
        ax.barh(y, s["mean"], height=.78, color=MODE_COLORS[PS], alpha=.85, zorder=2)
        ax.errorbar(s["mean"], y, xerr=[s["mean"] - s.lo, s.hi - s["mean"]], fmt="none", ecolor="#222", elinewidth=.55, capsize=1.3, capthick=.55, zorder=3)
        xmax = float(s.hi.max()); ystar = y
    ax.set_ylim(-.6, len(s) - .4)
    ax.axvline(float(s["mean"].mean()), color="black", lw=.6, ls="--", zorder=1)
    for yi, (_, r) in zip(ystar, s.iterrows()):
        if r.dev_q_bh < .05:
            ax.text(r.hi + .6, yi, "*", va="center", ha="left", fontsize=FB + 1)
    ax.set_yticks(y, [CTX_SHORT.get(l, l) for l in s.level], fontsize=FT); ax.tick_params(axis="y", length=0, pad=1.2); ax.grid(axis="x", alpha=.15)
    ax.set_xlim(0, xmax * 1.2); ax.set_xlabel("Refusal (%)")
    ax.set_title("By context" if fac == "context" else "By domain")


def build(data):
    tight_style()
    A, B, _, C, LV, bhq, CD, _ = data
    fig = plt.figure(figsize=(5.5, 2.45), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.02, hspace=.08, wspace=.02)
    gs = fig.add_gridspec(2, 1, height_ratios=[1.05, 1.0])
    g1 = gs[0].subgridspec(1, 3, width_ratios=[.85, 1.3, 2.1], wspace=.06)
    g2 = gs[1].subgridspec(1, 4, width_ratios=[1.1, 1.1, 1.0, 1.0], wspace=.06)
    axA, axB, axC = (fig.add_subplot(g1[0, i]) for i in range(3))
    axD, axE, axF, axG = (fig.add_subplot(g2[0, i]) for i in range(4))
    panel_a(axA, A); panel_b(axB, B); panel_c(axC, C)
    panel_de(axD, LV, bhq, "scale", True); panel_de(axE, LV, bhq, "standing", False)
    panel_fg(axF, CD, "context"); panel_fg(axG, CD, "domain")
    fig.canvas.draw()
    letters(fig, [(axA, "A", .004), (axB, "B", None), (axC, "C", None), (axD, "D", .004), (axE, "E", None), (axF, "F", None), (axG, "G", None)])
    fig.savefig(FIGURES / "fig1_baseline.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    build(load())
