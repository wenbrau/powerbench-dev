from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import RESULTS, FIGURES
from style import style, ORIGIN, short
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

FB, FT, FMIN, FL = 6.5, 6.0, 5.5, 9.0
MODES = ["he", "de", "pg", "control"]
EXCLUDED = {"nemotron-3.5-lightning", "nova-2-lite"}
CHANCE = "#9AA0A6"


def main():
    style()
    plt.rcParams.update({"font.size": FB, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "legend.fontsize": FT, "axes.titlesize": FB + .5, "axes.titlepad": 3})
    pm = pd.read_csv(RESULTS / "language" / "concordance" / "per_model.csv").set_index("model")
    assert len(pm) == 22 and not (set(pm.index) & EXCLUDED)
    r = pd.read_csv(RESULTS / "78_baseline_panels" / "rates_per_model.csv")
    r["mean4"] = r[MODES].mean(axis=1)
    r = r[r.model.isin(pm.index.tolist())]
    r = r.assign(o=r.origin.map({"US": 0, "CN": 1})).sort_values(["o", "mean4"], ascending=[True, False])
    models, origin = r.model.tolist(), dict(zip(r.model, r.origin))
    pm = pm.loc[models]
    fig = plt.figure(figsize=(5.5, 2.3))
    axA = fig.add_axes([.075, .372, .41, .553])
    axB = fig.add_axes([.585, .372, .41, .553])
    x = np.arange(len(models))
    cols = [ORIGIN[origin[m]] for m in models]

    def draw(ax, obs, lo, hi, mu, sep_ymin=0):
        ax.vlines(x, lo, hi, color=CHANCE, alpha=.55, lw=3.2, zorder=1)
        ax.scatter(x, mu, marker="_", s=14, color="#555", linewidths=.8, zorder=2)
        ax.scatter(x, obs, s=12, color=cols, edgecolor="white", linewidth=.35, zorder=3)
        ax.set_xticks(x, [short(m) for m in models], rotation=90, fontsize=FMIN)
        for lab, m in zip(ax.get_xticklabels(), models):
            lab.set_color(ORIGIN[origin[m]])
        ax.set_xlim(-.7, len(models) - .3)
        ax.tick_params(axis="x", length=0, pad=1.5)
        ax.grid(axis="y", alpha=.15)
        ax.axvline(sum(origin[m] == "US" for m in models) - .5, ymin=sep_ymin, color="#BBBBBB", lw=.5, zorder=0)

    draw(axA, pm.W_ps, pm.W_ps_null_lo, pm.W_ps_null_hi, pm.W_ps_null)
    axA.set_ylim(0, 1); axA.set_yticks([0, .25, .5, .75, 1])
    axA.set_ylabel("Kendall's W")
    axA.set_title("Agreement across power-shifting types")
    draw(axB, pm.rho_control_vs_ps, pm.rho_null_lo, pm.rho_null_hi, pm.rho_null, sep_ymin=.13)
    axB.axhline(0, color="black", lw=.6, zorder=0)
    axB.set_ylim(-1.14, 1.04); axB.set_yticks([-1, -.5, 0, .5, 1])
    axB.set_ylabel("Spearman correlation")
    axB.set_title("CT vs power-shifting types")
    leg = [Line2D([], [], ls="none", marker="o", ms=3.4, color="#444", label="Observed"),
           Line2D([], [], color=CHANCE, alpha=.55, lw=3.2, label="Chance (95%)"),
           Line2D([], [], ls="none", marker="_", ms=4, mew=.8, color="#555", label="Chance mean")]
    axB.legend(handles=leg, frameon=False, ncol=3, loc="lower left", handlelength=1.2, handletextpad=.6,
               columnspacing=1.2, borderaxespad=.1, fontsize=FMIN)
    for ax, s, xo in ((axA, "A", .005), (axB, "B", .505)):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(xo, y0 + h + .012, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA4_concordance.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
