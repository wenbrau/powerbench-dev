from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "4_analysis" / "scripts" / "language"))
from _common import OUT, LANGS, LANG_NAME, load22
from pbanalysis.datasets import MODES
from powerbench.paths import FIGURES
from rank_agreement import rank_corr, KINDS, CAPS
from style import short, MODE_LABEL, MODE_COLORS, ORIGIN, ORIGIN_LIGHT, DIVERGING_CMAP
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.patches import Patch, Rectangle
import numpy as np
import pandas as pd

FB, FT, FL = 6.5, 6.0, 9.0
H0, H = 4.7, 3.81
LANGS_BY_RANK = ["de", "pt", "en", "es", "sw", "zh", "fr", "hi"]
LANG_ABBR = {"en": "Eng", "es": "Spa", "de": "Ger", "fr": "Fre", "hi": "Hin", "sw": "Swa", "zh": "Chi", "pt": "Por"}
LANG_COLORS = {"hi": "#A44255", "fr": "#B68534", "zh": "#D8578E", "sw": "#2E8B57", "es": "#456B91", "en": "#222222", "pt": "#8A7FA3", "de": "#777C83"}


def panel_a(ax, d):
    per_model = d.groupby(["mode", "lang", "model"]).refuse.mean().reset_index()
    rate = per_model.groupby(["mode", "lang"]).refuse.mean().mul(100)
    order = rate.reset_index().query("mode in ['he','de','pg']").groupby("lang").refuse.mean().sort_values().index.tolist()
    dev = pd.read_csv(OUT / "deviation_bootstrap.csv").set_index(["mode", "lang"])
    q = pd.read_csv(OUT / "glmm" / "glmm_language_by_language.csv").set_index(["fit", "lang"]).p_bh
    x = np.arange(len(order)); w = .21
    for k, mode in enumerate(MODES):
        xk = x + (k - 1.5) * w
        rr = np.array([rate[(mode, l)] for l in order])
        a = dev.loc[mode].loc[order]
        assert np.allclose(a.rate, rr)
        up = np.clip(a.hi.to_numpy() - a.dev.to_numpy(), 0, None)
        ax.bar(xk, rr, width=w, color=MODE_COLORS[mode], alpha=.85, label=MODE_LABEL[mode], zorder=2)
        ax.axhline(rate[mode].mean(), color=MODE_COLORS[mode], lw=.6, ls="--", alpha=.9, zorder=1)
        ax.errorbar(xk, rr, yerr=[np.clip(a.dev.to_numpy() - a.lo.to_numpy(), 0, None), up], fmt="none", ecolor="#222",
                    elinewidth=.55, capsize=1.3, capthick=.55, zorder=3)
        for xi, ti, l in zip(xk, rr + up, order):
            if q[(f"A_{mode}", l)] < .05:
                ax.text(xi, ti + .3, "*", ha="center", va="bottom", fontsize=FT, color="#222", zorder=4)
    ax.set_xticks(x, [LANG_ABBR[l] for l in order])
    ax.set_xlim(-.6, len(order) - .4)
    ax.set_ylabel("Refusal (%)"); ax.set_ylim(0, 35); ax.grid(axis="y", alpha=.15)
    ax.legend(frameon=False, loc="upper left", ncol=4, handlelength=1.1, columnspacing=1.0, borderaxespad=.2)
    ax.set_title("Refusal by language and request type")


def panel_b(ax):
    bump = pd.read_csv(OUT / "concordance" / "mean_rank_by_mode.csv").set_index("lang")[list(MODES)].rank()
    x = np.arange(len(MODES))
    off = {}
    for j, md in enumerate(MODES):
        for ls in bump[md].groupby(bump[md]).groups.values():
            ls = [l for l in LANGS_BY_RANK if l in ls]
            for k, l in enumerate(ls):
                off[(l, j)] = k - (len(ls) - 1) / 2
    for l in LANGS_BY_RANK:
        y = [bump.loc[l, md] for md in MODES]
        xs = x + np.array([off[(l, j)] * .22 for j in range(len(MODES))])
        ax.plot(xs[:3], y[:3], marker="o", color=LANG_COLORS[l], lw=1.1, ms=2.6, zorder=3, solid_capstyle="round")
        ax.plot(xs[3:], y[3:], marker="o", color=LANG_COLORS[l], ls="none", ms=2.6, zorder=3)
        ax.text(-.14, y[0] + off[(l, 0)] * .55, LANG_NAME[l], ha="right", va="center", fontsize=FT, color=LANG_COLORS[l])
    ax.axvline(2.5, color="#999", lw=.6, ls=":")
    ax.set_xticks(x, [MODE_LABEL[md] for md in MODES]); ax.set_xlim(-1.35, 3.35)
    ax.set_yticks(range(1, 9), [""] * 8); ax.set_ylim(8.5, .5); ax.grid(axis="y", alpha=.15)
    ax.tick_params(axis="y", length=0); ax.spines["left"].set_visible(False)
    ax.set_title("Language order")


def panel_c(ax):
    s = pd.read_csv(OUT / "concordance" / "summary.csv")
    vals = [s[s.question.str.startswith(key)].iloc[0] for key in ("Q1 in rho", "Q2")]
    ax.bar([0, 1], [v["mean"] for v in vals], width=.6, color=["#5B3F8C", "#777C83"], zorder=2)
    ax.errorbar([0, 1], [v["mean"] for v in vals], yerr=[[v["mean"] - v.lo for v in vals], [v.hi - v["mean"] for v in vals]],
                fmt="none", ecolor="#222", elinewidth=.7, capsize=2, capthick=.7, zorder=3)
    for xi, v in enumerate(vals):
        if v.p_t < .05:
            ax.text(xi, v.hi + .02, "*", ha="center", va="bottom", fontsize=FB + 1)
    ax.axhline(0, color="black", lw=.6, ls="--", zorder=1)
    ax.set_xlim(-.6, 1.6); ax.set_xticks([0, 1], ["PS", "CT"])
    ax.set_ylim(-.05, .8); ax.set_yticks([0, .2, .4, .6, .8]); ax.grid(axis="y", alpha=.15)
    ax.set_title("Order across\nrequest types")


def panel_d(ax):
    tab = pd.read_csv(OUT / "range_excess_bootstrap.csv").set_index(["mode", "weights"])
    x = np.arange(len(MODES)); wb = .38
    for wname, off, alpha, lw, label in (("eq", -wb / 2, .4, .6, "equal"), ("use", wb / 2, None, .8, "usage")):
        t = tab.xs(wname, level="weights").loc[list(MODES)]
        ax.bar(x + off, t.excess_or - 1, bottom=1, width=wb, color=[MODE_COLORS[m] for m in MODES], alpha=alpha, label=label, zorder=2)
        ax.errorbar(x + off, t.excess_or, yerr=[t.excess_or - t.lo95_or, t.hi95_or - t.excess_or], fmt="none", ecolor="#222",
                    elinewidth=lw, capsize=1.6, capthick=lw, zorder=3)
    ax.axhline(1, color="k", lw=.6, ls="--", zorder=1)
    for xi, m in zip(x, MODES):
        for wname, off in (("eq", -wb / 2), ("use", wb / 2)):
            if tab.loc[(m, wname), "q_bh"] < .05:
                ax.text(xi + off, tab.loc[(m, wname), "hi95_or"] * 1.03, "*", ha="center", va="bottom", fontsize=FB)
    ax.set_yscale("log"); ax.set_yticks([.5, .7, 1, 1.5, 2, 3, 4]); ax.yaxis.set_major_formatter(mticker.ScalarFormatter())
    ax.yaxis.set_minor_formatter(mticker.NullFormatter())
    ax.set_ylim(min(.85, tab.lo95_or.min() * .92), tab.hi95_or.max() * 1.35)
    ax.set_ylabel("odds ratio / chance")
    ax.set_xticks(x, [MODE_LABEL[m] for m in MODES])
    ax.grid(axis="y", alpha=.15)
    ax.legend(frameon=False, loc="lower right", handlelength=1.0, borderaxespad=.1, labelspacing=.2)
    ax.set_title("Range beyond\nchance")


def panel_e(ax):
    tab = pd.read_csv(OUT / "range_excess_pp_ps.csv").sort_values("excess", ascending=False).reset_index(drop=True)
    n = len(tab); y = np.arange(n)
    ax.barh(y, tab.null_mean, color=[ORIGIN_LIGHT[o] for o in tab.origin], height=.72, zorder=2)
    ax.barh(y, tab.excess.clip(lower=0), left=tab.null_mean, color=[ORIGIN[o] for o in tab.origin], height=.72, zorder=3)
    neg = tab.excess < 0
    ax.barh(y[neg], tab.excess[neg], left=tab.null_mean[neg], color="none", edgecolor=[ORIGIN[o] for o in tab.origin[neg]], height=.72,
            zorder=3, hatch="////", lw=.4)
    ax.scatter(tab.null_p95, y, marker="|", s=24, color="#222", lw=.7, zorder=4)
    for i, r in tab.iterrows():
        if r.q_bh < .05:
            ax.text(max(r.range_pp, r.null_p95) + .6, i, "*", va="center", ha="left", fontsize=FB + 1)
    ax.set_yticks(y, [short(m) for m in tab.model]); ax.tick_params(axis="y", length=0, pad=1.2)
    for lab, o in zip(ax.get_yticklabels(), tab.origin):
        lab.set_color(ORIGIN[o])
    ax.set_ylim(n - .4, -.6); ax.set_xlabel("refusal range (pp)"); ax.set_xlim(0, float(tab.range_pp.max()) * 1.15); ax.grid(axis="x", alpha=.15)
    ax.legend(handles=[Patch(color="#C9C9C9", label="chance"), Patch(color="#666", label="excess"),
                       Patch(color=ORIGIN["US"], label="US"), Patch(color=ORIGIN["CN"], label="CN")], frameon=False, loc="lower right",
              handlelength=1.0, labelspacing=.2, borderaxespad=.2)
    ax.set_title("Range per model")


def panel_f(ax, d):
    origin = d.drop_duplicates("model").set_index("model").origin
    cap = pd.read_csv(CAPS).set_index("model")["index"]
    models = sorted(origin.index, key=lambda m: (origin[m] != "CN", -cap[m]))
    n = len(models)
    is_cn = np.array([origin[m] == "CN" for m in models]); ncn = int(is_cn.sum())
    dm = d[d["mode"].isin(["he", "de", "pg"])]
    cube = np.stack([dm[dm.model == m].pivot(index="prompt_id", columns="lang", values="refuse").reindex(columns=LANGS).to_numpy(float)
                     for m in models])
    C = rank_corr(np.nanmean(cube, axis=1)); np.fill_diagonal(C, np.nan)
    st = pd.read_csv(OUT / "rank_agreement_tests_power_shifting.csv")
    S = st[st.test == "test1_langperm"].set_index("quantity")
    contrast_p = float(st[(st.test == "test2_blockperm") & (st.quantity == "within − mixed")].p.iloc[0])
    bhq = pd.read_csv(OUT / "bh_q_values.csv")
    q = bhq[(bhq.panel == "F") & bhq.test.isin(KINDS)].set_index("test").q
    iu = np.triu_indices(n, 1); a, b = is_cn[iu[0]], is_cn[iu[1]]
    pk = np.where(a & b, "CN–CN", np.where(~a & ~b, "US–US", "mixed")); vals = C[iu]
    for k in KINDS:
        assert abs(float(np.nanmean(vals[pk == k])) - S.loc[k, "observed"]) < 1e-9, k
    cmap = plt.get_cmap(DIVERGING_CMAP).copy(); cmap.set_bad("white")
    im = ax.imshow(np.where(np.triu(np.ones((n, n), bool), k=0), np.nan, C), cmap=cmap, vmin=-1, vmax=1)
    ax.set_xticks([])
    ax.set_yticks(range(n), [short(m) for m in models])
    ax.tick_params(length=0, pad=1.5)
    for tk, m in zip(ax.get_yticklabels(), models):
        tk.set_color(ORIGIN[origin[m]])
    ax.plot([-.5, ncn - .5], [ncn - .5, ncn - .5], color="black", lw=.7)
    ax.plot([ncn - .5, ncn - .5], [ncn - .5, n - .5], color="black", lw=.7)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_title("Model agreement")
    cb = plt.colorbar(im, cax=ax.inset_axes([.02, -.07, .42, .03]), orientation="horizontal", ticks=[-1, 0, 1])
    cb.ax.tick_params(labelsize=FT, width=.4, length=1.5, pad=1); cb.outline.set_linewidth(.4)
    cb.set_label("Spearman", fontsize=FT, labelpad=1)
    axb = ax.inset_axes([.43, .60, .56, .36])
    obs = [float(S.loc[k, "observed"]) for k in KINDS]
    axb.bar(range(3), obs, color=[ORIGIN["CN"], ORIGIN["US"], "#8A7FA3"], alpha=.9, width=.66, zorder=2)
    for i, k in enumerate(KINDS):
        axb.add_patch(Rectangle((i - .4, float(S.loc[k, "null_lo"])), .8, float(S.loc[k, "null_hi"] - S.loc[k, "null_lo"]),
                                facecolor="#9AA0A6", alpha=.30, edgecolor="none", zorder=1))
        if q[k] < .05:
            axb.text(i, obs[i] + .01, "*", ha="center", va="bottom", fontsize=FB + 1)
    axb.axhline(0, color="black", lw=.5, zorder=3)
    yb, tk = .215, .015
    axb.plot([0, 0, 1, 1], [yb - tk, yb, yb, yb - tk], color="#222", lw=.5)
    axb.plot([.5, .5, 2, 2], [yb, yb + tk, yb + tk, yb - tk], color="#222", lw=.5)
    if contrast_p < .05:
        axb.text(1.25, yb + tk + .003, "*", ha="center", va="bottom", fontsize=FB + 1)
    axb.set_xticks(range(3), ["CN–CN", "US–US", "mixed"]); axb.set_xlim(-.6, 2.6); axb.set_ylim(-.12, .29); axb.set_yticks([0, .1, .2])
    axb.set_ylabel("mean ρ", fontsize=FT, labelpad=1); axb.tick_params(labelsize=FT, width=.4, length=1.5, pad=1)
    for sp in ("top", "right"):
        axb.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        axb.spines[sp].set_linewidth(.5)


def main():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": FB, "axes.titlesize": FB + .5, "axes.titleweight": "bold",
        "axes.titlelocation": "left", "axes.titlepad": 3, "axes.labelsize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
        "legend.fontsize": FT, "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .6,
        "xtick.major.width": .5, "ytick.major.width": .5, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
        "lines.linewidth": .8, "savefig.facecolor": "white", "pdf.fonttype": 42,
    })
    d = load22()

    def pos(x, y_in, w, h_in):
        return [x, y_in / H, w, h_in / H]
    fig = plt.figure(figsize=(5.5, H))
    axA = fig.add_axes(pos(.075, 2.776, .43, .658))
    axB = fig.add_axes(pos(.635, 2.776, .15, .658))
    axC = fig.add_axes(pos(.84, 2.776, .15, .658))
    axD = fig.add_axes(pos(.075, .423, .15, 1.836))
    axE = fig.add_axes(pos(.335, .3525, .17, 1.9065))
    axF = fig.add_axes(pos(.63, .423, .36, 1.836)); axF.set_anchor("N")
    panel_a(axA, d); panel_b(axB); panel_c(axC); panel_d(axD); panel_e(axE); panel_f(axF, d)
    fig.canvas.draw()
    for ax, s, xo in ((axA, "A", .008), (axB, "B", .525), (axC, "C", .812), (axD, "D", .008), (axE, "E", .255), (axF, "F", .545)):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(xo, y0 + h + .012 * H0 / H, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "fig4_language.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
