import os
import tempfile
import warnings

os.environ.setdefault("MPLCONFIGDIR", os.path.join(tempfile.gettempdir(), "powerbench-mpl"))
warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

MODES = ["he", "de", "pg", "control"]
PS = "power_shifting"
MODE_LABEL = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}
MODEL_SHORT = {
    "deepseek-v4-pro": "dsk-v4", "gemini-3.1-flash-lite": "gem-3.1fl", "gemma-4-31b": "gemma-4", "glm-5.2": "glm-5.2",
    "gpt-5.6-luna": "luna", "gpt-5.6-sol": "sol", "gpt-5.6-terra": "terra", "grok-4.3": "grok-4.3", "haiku-4.5": "haiku-4.5",
    "hy3": "hy3", "inkling": "inkling", "kimi-k2.6": "kimi-k2.6", "kimi-k3": "kimi-k3", "ling-3.0-flash": "ling-3.0",
    "mimo-v2.5-pro": "mimo-2.5", "minimax-m3": "mmax-m3", "nemotron-3-ultra": "nemo-3u", "nemotron-3.5-lightning": "nemo-3.5l",
    "nova-2-lite": "nova-2", "qwen3.7-plus": "qwen3.7+", "qwen3.8-27b": "q3.8-27b", "qwen3.8-flash": "q3.8-fl",
    "seed-2-1-turbo": "seed-2.1", "sonnet-5": "sonnet-5",
}

def short(m):
    return MODEL_SHORT.get(m, m)

MODE_COLORS = {"he": "#456B91", "de": "#B68534", "pg": "#A44255", "control": "#777C83", PS: "#5B3F8C"}
ORIGIN = {"US": "#326CA0", "CN": "#B44941"}
ORIGIN_LIGHT = {"US": "#B9CDE0", "CN": "#E6BDB9"}
ORIGIN_LABEL = {"US": "US models", "CN": "CN models"}
DIVERGING_CMAP = "PRGn"
ERR = dict(fmt="none", ecolor="#222", elinewidth=.55, capsize=1.3, capthick=.55, zorder=4)
GFMT = mticker.FuncFormatter(lambda v, _: f"{v:g}")


def text_on(rgba, dark="#1A1A1A"):
    lin = [c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4 for c in rgba[:3]]
    return "white" if .2126 * lin[0] + .7152 * lin[1] + .0722 * lin[2] < .2 else dark


def style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 6.5, "axes.titlesize": 7.2, "axes.titleweight": "bold",
        "axes.titlelocation": "left", "axes.titlepad": 4, "axes.labelsize": 6.5, "xtick.labelsize": 6.0, "ytick.labelsize": 6.0,
        "legend.fontsize": 5.2, "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .6,
        "xtick.major.width": .5, "ytick.major.width": .5, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
        "xtick.major.pad": 2, "ytick.major.pad": 2, "axes.labelpad": 2,
        "lines.linewidth": .8, "savefig.facecolor": "white", "pdf.fonttype": 42,
    })


def tight_style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 6.5, "axes.titlesize": 7.0, "axes.titleweight": "bold", "axes.titlelocation": "left",
        "axes.titlepad": 3, "axes.labelsize": 6.5, "xtick.labelsize": 6.0, "ytick.labelsize": 6.0, "legend.fontsize": 6.0,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .6, "xtick.major.width": .5, "ytick.major.width": .5,
        "xtick.major.size": 2.2, "ytick.major.size": 2.2, "xtick.major.pad": 1.5, "ytick.major.pad": 1.5, "axes.labelpad": 1.5,
        "lines.linewidth": .8, "savefig.facecolor": "white", "pdf.fonttype": 42,
    })


def or_axis(ax, ticks, lo, hi):
    ax.set_yscale("log"); ax.set_yticks(ticks); ax.yaxis.set_major_formatter(mticker.ScalarFormatter())
    ax.yaxis.set_minor_formatter(mticker.NullFormatter()); ax.set_ylim(lo, hi)
    ax.axhline(1, color="black", lw=.6); ax.grid(axis="y", alpha=.15)


def shade_dir(ax, lo, hi):
    ax.axhspan(1, hi, color=ORIGIN["US"], alpha=.06, zorder=0); ax.axhspan(lo, 1, color=ORIGIN["CN"], alpha=.06, zorder=0)


def letters(fig, items):
    for ax, s, xo in items:
        x0, y0, w, h = ax.get_position().bounds
        fig.text((x0 - .012) if xo is None else xo, y0 + h + .006, s, fontsize=9.5, fontweight="bold", ha="right" if xo is None else "left", va="bottom")


def axes_letters(items):
    for ax, s in items:
        ax.annotate(s, xy=(0, 1), xycoords="axes fraction", xytext=(-5, plt.rcParams["axes.titlepad"]), textcoords="offset points",
                    fontsize=9.0, fontweight="bold", ha="right", va="baseline", annotation_clip=False)
