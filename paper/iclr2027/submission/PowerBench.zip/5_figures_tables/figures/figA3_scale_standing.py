import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import style, MODE_COLORS
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

MODES = ["he", "de", "pg", "control"]
LABEL = {"he": "SE", "de": "DE", "pg": "PG", "control": "CT"}
LEVELS = {"scale": ["individual", "group", "society"], "standing": ["low", "med", "high"]}
TICK = {"individual": "Individual", "group": "Group", "society": "Society", "low": "Low", "med": "Medium", "high": "High"}
XLAB = {"scale": "Scale of the target", "standing": "Requester's prior power standing"}
TITLE = {"scale": "By scale", "standing": "By power standing"}
FB, FT, FL = 6.5, 6.0, 9.0
DODGE = {"he": -.15, "de": -.05, "pg": .05, "control": .15}


def restyle():
    style()
    plt.rcParams.update({"legend.fontsize": FT, "axes.titlesize": FB, "xtick.labelsize": FT, "ytick.labelsize": FT,
                         "axes.labelsize": FB, "font.size": FB})


def panel(ax, lv, tt, dim, first):
    s = lv[lv.dim == dim]; xs = np.arange(3)
    q = tt[tt.dim == dim].set_index("mode").q_bh
    for mode in MODES:
        r = s[s["mode"] == mode].set_index("level").loc[LEVELS[dim]]
        x = xs + DODGE[mode]
        ax.errorbar(x, r.bias, yerr=[r.bias - r.lo, r.hi - r.bias], fmt="-o", color=MODE_COLORS[mode], ecolor=MODE_COLORS[mode],
                    ms=2.4, lw=.9, elinewidth=.6, capsize=1.2, capthick=.6, zorder=3)
        if q[mode] < .05:
            ax.text(2.27, float(r.bias.iloc[-1]), "*", ha="left", va="center", fontsize=FB + 1.5, color=MODE_COLORS[mode], zorder=5)
    ax.axhline(0, color="black", lw=.6, ls="--", zorder=1)
    ax.set_xticks(xs, [TICK[l] for l in LEVELS[dim]]); ax.set_xlim(-.4, 2.45)
    ax.set_ylim(-.35, 1.1); ax.set_yticks([-.25, 0, .25, .5, .75, 1]); ax.grid(axis="y", alpha=.15)
    ax.set_xlabel(XLAB[dim])
    if first:
        ax.set_ylabel("Bias toward refusing the AI")
    ax.set_title(TITLE[dim])


def main():
    restyle()
    lv = pd.read_csv(RESULTS / "59_ai_agent_by_dimension" / "bias_direction_by_level.csv")
    tt = pd.read_csv(RESULTS / "60_ai_agent_level_glmm" / "bias_direction_paired_t.csv")
    fig = plt.figure(figsize=(5.5, 1.9), layout="constrained")
    fig.get_layout_engine().set(w_pad=.02, h_pad=.04, wspace=.06)
    gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, .42])
    axA = fig.add_subplot(gs[0, 0]); axB = fig.add_subplot(gs[0, 1], sharey=axA); axL = fig.add_subplot(gs[0, 2]); axL.axis("off")
    panel(axA, lv, tt, "scale", True); panel(axB, lv, tt, "standing", False)
    axB.tick_params(labelleft=False)
    axL.legend(handles=[Line2D([], [], color=MODE_COLORS[m], marker="o", ms=2.4, lw=.9, label=LABEL[m]) for m in MODES],
               frameon=False, loc="center left", handlelength=1.4, labelspacing=.5, borderaxespad=0)
    fig.canvas.draw()
    for ax, s in ((axA, "A"), (axB, "B")):
        x0, y0, w, h = ax.get_position().bounds
        fig.text(max(x0 - .07, .002) if ax is axA else x0 - .03, y0 + h + .02, s, fontsize=FL, fontweight="bold", ha="left", va="bottom")
    fig.savefig(FIGURES / "figA3_scale_standing.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
