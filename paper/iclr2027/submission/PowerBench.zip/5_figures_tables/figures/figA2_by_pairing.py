import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, RESULTS
from style import MODES, MODE_LABEL, MODE_COLORS, ERR, GFMT, or_axis, shade_dir, axes_letters, tight_style
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

B75 = RESULTS / "75_nationality_by_pairing"


def star(ax, x, y, q, below=False):
    if np.isfinite(q) and q < .05:
        ax.text(x, y, "*", ha="center", va="top" if below else "bottom", fontsize=7.5, zorder=6)


def main():
    tight_style()
    A = pd.read_csv(B75 / "pA_excess_by_dyad.csv").set_index(["set", "mode"])
    B = pd.read_csv(B75 / "pB_side_glmm_by_dyad.csv").set_index(["set", "mode"])
    C = pd.read_csv(B75 / "pC_requests_by_dyad.csv").set_index(["set", "group"])
    sets = [("us_cn", "US–China"), ("allies", "US ally–China ally"), ("neutral", "Neutral–neutral")]
    x = np.arange(4); cols = [MODE_COLORS[m] for m in MODES]
    fig = plt.figure(figsize=(5.5, 3.3))
    gs = fig.add_gridspec(3, 3, left=.105, right=.99, top=.875, bottom=.03, hspace=.28, wspace=.08)
    axes = [[None] * 3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            ax = fig.add_subplot(gs[i, j], sharey=axes[i][0] if j else None); axes[i][j] = ax
            if j:
                ax.tick_params(labelleft=False)
            ax.set_xticks(x, [""] * 4); ax.tick_params(axis="x", length=0); ax.set_xlim(-.6, 3.6)
    OLO, OHI = .6, 1.62
    for j, (st, title) in enumerate(sets):
        a = A.loc[st].loc[MODES]; ax = axes[0][j]
        ax.bar(x, a.excess, width=.62, color=cols, zorder=2)
        ax.errorbar(x, a.excess, yerr=[a.excess - a.lo, a.hi - a.excess], **ERR)
        ax.axhline(0, color="black", lw=.6, ls="--", zorder=1)
        for xi, e, l, h, q in zip(x, a.excess, a.lo, a.hi, a.q_bh):
            star(ax, xi, max(h, 0) + .004, q) if e >= 0 else star(ax, xi, min(l, 0) - .004, q, below=True)
        ax.set_ylim(-.16, .31); ax.grid(axis="y", alpha=.15); ax.set_title(title)
        for i, (T, est, lo, hi, qc) in ((1, (B, "OR", "OR_lo", "OR_hi", "q_bh")), (2, (C, "odds_ratio", "boot_lo", "boot_hi", "boot_q"))):
            r = T.loc[st].loc[MODES].copy(); ax = axes[i][j]
            r[est], r[lo], r[hi] = 1 / r[est], 1 / r[hi], 1 / r[lo]
            ax.bar(x, r[est] - 1, bottom=1, width=.62, color=cols, zorder=2)
            ax.errorbar(x, r[est], yerr=[r[est] - r[lo], r[hi] - r[est]], **ERR)
            for xi, e, l, h, q in zip(x, r[est], r[lo], r[hi], r[qc]):
                star(ax, xi, h * 1.01, q) if e >= 1 else star(ax, xi, l / 1.01, q, below=True)
            or_axis(ax, [.7, 1, 1.4], OLO, OHI); shade_dir(ax, OLO, OHI); ax.yaxis.set_major_formatter(GFMT)
    axes[0][0].set_ylabel("|Bias| $-$ chance"); axes[0][0].set_yticks([-.1, 0, .1, .2, .3])
    axes[1][0].set_ylabel("OR (GLMM)"); axes[2][0].set_ylabel("OR (usage-wt.)")
    fig.legend(handles=[Patch(fc=MODE_COLORS[m], label=MODE_LABEL[m]) for m in MODES], frameon=False, loc="upper center",
               bbox_to_anchor=(.55, 1.0), ncol=4, columnspacing=1.2, handlelength=1.1)
    axes_letters([(axes[i][0], s) for i, s in enumerate("ABC")])
    fig.savefig(FIGURES / "figA2_by_pairing.pdf", dpi=300, metadata={"CreationDate": None})


if __name__ == "__main__":
    main()
