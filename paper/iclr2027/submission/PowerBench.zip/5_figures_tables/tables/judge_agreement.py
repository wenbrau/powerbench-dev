import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import FIGURES, TABLES
sys.path.insert(0, str(FIGURES))
from figA_judges import agreement_sets


def main():
    ag, _ = agreement_sets()
    lines = ["\\begin{tabular}{lrrrrr}", "\\toprule",
             "Set & Responses & Agreement (\\%) & $\\kappa$ & Refusal, adopted (\\%) & Refusal, independent (\\%) \\\\", "\\midrule"]
    for _, r in ag.iterrows():
        if r.set in ("Spanish", "Seven other languages"):
            lines.append("\\midrule")
        lines.append(f"{r.set} & {r.n:,} & {r.agree:.1f} & {r.kappa:.2f} & {r.R_adopted:.1f} & {r.R_indep:.1f} \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    (TABLES / "judge_agreement.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
