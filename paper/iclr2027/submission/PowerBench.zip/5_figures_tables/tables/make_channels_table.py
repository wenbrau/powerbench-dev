import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench.paths import RESULTS, TABLES

MODES = ("he", "de", "pg", "control")
MODE = {"he": "\\he", "de": "\\de", "pg": "\\pg", "control": "Control"}
G = ["US", "USal", "neu", "CNal", "CN"]
DYADS = [("us_ally", "US and its allies", "US", "USal"), ("us_neutral", "US and neutral countries", "US", "neu"),
         ("us_rival", "US and its rivals", "US", "CNal"), ("us_cn", "US and China", "US", "CN"),
         ("cn_ally", "China and its allies", "CN", "CNal"), ("cn_neutral", "China and neutral countries", "CN", "neu"),
         ("cn_rival", "China and its rivals", "CN", "USal")]
QA = [(c, q) for c in ("user", "target") for q in ("CN_minus_US", "bloc_CN_minus_US")]


def ci(est, se):
    return f"{np.exp(est):.2f} [{np.exp(est - 1.96 * se):.2f}; {np.exp(est + 1.96 * se):.2f}]"


def main():
    a = pd.read_csv(RESULTS / "101_nationality_channels" / "glmm_channels.csv")
    obs = pd.read_csv(RESULTS / "46_nationality_direction_glmm" / "direction_glmm_by_dyad.csv")
    obs = obs[obs.quantity == "direction (24 models)"].set_index(["mode", "dyad"]).OR

    L = ["\\begin{tabular}{@{}lllll@{}}", "\\toprule",
         "\\multicolumn{5}{@{}l}{\\textit{(A) Odds ratio of refusal, China against the US, in each role}} \\\\",
         " & \\multicolumn{2}{c}{User} & \\multicolumn{2}{c}{Target} \\\\",
         "\\cmidrule(l{2pt}r{2pt}){2-3}\\cmidrule(l{2pt}r{2pt}){4-5}",
         "Request type & China / US & China bloc / US bloc & China / US & China bloc / US bloc \\\\", "\\midrule"]
    for m in MODES:
        s = a[a["mode"] == m].set_index(["channel", "quantity"])
        assert (s.loc[QA, "q_bh"] < .001).all(), m
        L.append(" & ".join([MODE[m]] + [ci(s.loc[k, "estimate"], s.loc[k, "se"]) for k in QA]) + " \\\\")
    L += ["\\midrule", "\\multicolumn{5}{@{}l}{\\textit{(B) Country as target against the same country as user: predicted by the two effects / observed}} \\\\",
          "Pairing & \\he & \\de & \\pg & Control \\\\", "\\midrule"]
    for key, label, x, y in DYADS:
        cells = []
        for m in MODES:
            s = a[(a["mode"] == m) & a.quantity.str.startswith("dev_")].set_index(["channel", "quantity"]).estimate
            u = {g: s.loc[("user", "dev_" + g)] for g in G}
            t = {g: s.loc[("target", "dev_" + g)] for g in G}
            pred = np.exp((u[y] - u[x]) + (t[x] - t[y]))
            cells.append(f"{pred:.2f} / {1 / obs.loc[(m, key)]:.2f}")
        L.append(" & ".join([label] + cells) + " \\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    (TABLES / "channels.tex").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
