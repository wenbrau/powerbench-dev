import io
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from powerbench import paths

RAW = paths.COUNTRIES / "raw"

ip = pd.read_csv(RAW / "idealpoints_1946_2024.csv")
ip["iso3c"] = ip.iso3c.replace({"YUG": "SRB"})
ip24 = ip[ip.year == 2024].dropna(subset=["iso3c"]).copy()
UNIVERSE = set(ip[ip.year >= 2021].dropna(subset=["iso3c"]).iso3c) | {"TWN", "XKX"}
CCODE2ISO = ip.dropna(subset=["iso3c"]).drop_duplicates("ccode", keep="last").set_index("ccode").iso3c.to_dict()
NAME2ISO = {}
for _, r in ip.dropna(subset=["iso3c"]).drop_duplicates("countryname", keep="last").iterrows():
    NAME2ISO[r.countryname.strip().lower()] = r.iso3c


def _norm(s):
    s = s.strip().lower()
    s = re.sub(r"[’'`’]", "", s)
    s = re.sub(r"\s+", " ", s)
    return s


NAME_FIX = {
    "united states": "USA", "russia": "RUS", "china": "CHN", "south korea": "KOR",
    "north korea": "PRK", "viet nam": "VNM", "vietnam": "VNM", "syria": "SYR",
    "iran": "IRN", "laos": "LAO", "bolivia": "BOL", "venezuela": "VEN", "tanzania": "TZA",
    "moldova": "MDA", "cote divoire": "CIV", "ivory coast": "CIV", "dr congo": "COD",
    "congo, dr": "COD", "democratic republic of the congo": "COD", "congo": "COG",
    "republic of the congo": "COG", "cape verde": "CPV", "cabo verde": "CPV",
    "bosnia-herzegovina": "BIH", "bosnia and herzegovina": "BIH", "brunei": "BRN",
    "brunei darussalam": "BRN", "czechia": "CZE", "czech republic": "CZE",
    "timor-leste": "TLS", "east timor": "TLS", "north macedonia": "MKD",
    "macedonia (fyrom)": "MKD", "micronesia": "FSM", "myanmar": "MMR", "burma": "MMR",
    "taiwan": "TWN", "trinidad and tobago": "TTO", "trinidad & tobago": "TTO",
    "turkey": "TUR", "turkiye": "TUR", "uae": "ARE", "united arab emirates": "ARE",
    "united kingdom": "GBR", "uk": "GBR", "kosovo": "XKX", "palestine": "PSE",
    "gambia": "GMB", "the gambia": "GMB", "bahamas": "BHS", "the bahamas": "BHS",
    "eswatini": "SWZ", "swaziland": "SWZ", "st kitts and nevis": "KNA",
    "saint kitts and nevis": "KNA", "st lucia": "LCA", "saint lucia": "LCA",
    "st vincent and the grenadines": "VCT", "saint vincent and the grenadines": "VCT",
    "sao tome and principe": "STP", "guinea-bissau": "GNB", "equatorial guinea": "GNQ",
    "central african republic": "CAF", "south sudan": "SSD", "sri lanka": "LKA",
    "papua new guinea": "PNG", "solomon islands": "SLB", "marshall islands": "MHL",
    "dominican republic": "DOM", "el salvador": "SLV", "burkina faso": "BFA",
    "sierra leone": "SLE", "saudi arabia": "SAU", "south africa": "ZAF",
    "new zealand": "NZL", "netherlands": "NLD", "the netherlands": "NLD",
    "russian federation": "RUS", "republic of korea": "KOR", "korea, south": "KOR",
    "korea, north": "PRK", "cambodia": "KHM", "libya": "LBY",
    "serbia": "SRB", "antigua and barbuda": "ATG",
}


def to_iso3(name):
    n = _norm(name)
    if n in NAME_FIX:
        return NAME_FIX[n]
    return NAME2ISO.get(n)


ISO2TO3 = {
 'AF':'AFG','AL':'ALB','DZ':'DZA','AD':'AND','AO':'AGO','AG':'ATG','AR':'ARG','AM':'ARM',
 'AU':'AUS','AT':'AUT','AZ':'AZE','BS':'BHS','BH':'BHR','BD':'BGD','BB':'BRB','BY':'BLR',
 'BE':'BEL','BZ':'BLZ','BJ':'BEN','BT':'BTN','BO':'BOL','BA':'BIH','BW':'BWA','BR':'BRA',
 'BN':'BRN','BG':'BGR','BF':'BFA','BI':'BDI','CV':'CPV','KH':'KHM','CM':'CMR','CA':'CAN',
 'CF':'CAF','TD':'TCD','CL':'CHL','CN':'CHN','CO':'COL','KM':'COM','CD':'COD','CG':'COG',
 'CR':'CRI','CI':'CIV','HR':'HRV','CU':'CUB','CY':'CYP','CZ':'CZE','DK':'DNK','DJ':'DJI',
 'DM':'DMA','DO':'DOM','EC':'ECU','EG':'EGY','SV':'SLV','GQ':'GNQ','ER':'ERI','EE':'EST',
 'SZ':'SWZ','ET':'ETH','FJ':'FJI','FI':'FIN','FR':'FRA','GA':'GAB','GM':'GMB','GE':'GEO',
 'DE':'DEU','GH':'GHA','GR':'GRC','GD':'GRD','GT':'GTM','GN':'GIN','GW':'GNB','GY':'GUY',
 'HT':'HTI','HN':'HND','HK':'HKG','HU':'HUN','IS':'ISL','IN':'IND','ID':'IDN','IR':'IRN',
 'IQ':'IRQ','IE':'IRL','IL':'ISR','IT':'ITA','JM':'JAM','JP':'JPN','JO':'JOR','KZ':'KAZ',
 'KE':'KEN','KI':'KIR','KP':'PRK','KR':'KOR','KW':'KWT','KG':'KGZ','LA':'LAO','LV':'LVA',
 'LB':'LBN','LS':'LSO','LR':'LBR','LY':'LBY','LT':'LTU','LU':'LUX','MO':'MAC','MG':'MDG',
 'MW':'MWI','MY':'MYS','MV':'MDV','ML':'MLI','MT':'MLT','MH':'MHL','MR':'MRT','MU':'MUS',
 'MX':'MEX','FM':'FSM','MD':'MDA','MC':'MCO','MN':'MNG','ME':'MNE','MA':'MAR','MZ':'MOZ',
 'MM':'MMR','NA':'NAM','NR':'NRU','NP':'NPL','NL':'NLD','NZ':'NZL','NI':'NIC','NE':'NER',
 'NG':'NGA','MK':'MKD','NO':'NOR','OM':'OMN','PK':'PAK','PW':'PLW','PA':'PAN','PG':'PNG',
 'PY':'PRY','PE':'PER','PH':'PHL','PL':'POL','PT':'PRT','QA':'QAT','RO':'ROU','RU':'RUS',
 'RW':'RWA','WS':'WSM','SM':'SMR','ST':'STP','SA':'SAU','SN':'SEN','RS':'SRB','SC':'SYC',
 'SL':'SLE','SG':'SGP','SK':'SVK','SI':'SVN','SB':'SLB','SO':'SOM','ZA':'ZAF','SS':'SSD',
 'ES':'ESP','LK':'LKA','KN':'KNA','LC':'LCA','VC':'VCT','SD':'SDN','SR':'SUR','SE':'SWE',
 'CH':'CHE','SY':'SYR','TW':'TWN','TJ':'TJK','TZ':'TZA','TH':'THA','TL':'TLS','TG':'TGO',
 'TO':'TON','TT':'TTO','TN':'TUN','TR':'TUR','TM':'TKM','TV':'TUV','UG':'UGA','UA':'UKR',
 'AE':'ARE','GB':'GBR','US':'USA','UY':'URY','UZ':'UZB','VU':'VUT','VE':'VEN','VN':'VNM',
 'YE':'YEM','ZM':'ZMB','ZW':'ZWE','XK':'XKX','KV':'XKX','AW':'ABW','CW':'CUW',
}

ag = pd.read_csv(RAW / "agreement_us_cn_2015plus.csv")
ag = ag[ag.year.between(2022, 2024)]


def pole_agreement(pole_ccode):
    a = ag[(ag.ccode1 == pole_ccode) | (ag.ccode2 == pole_ccode)].copy()
    a["other"] = np.where(a.ccode1 == pole_ccode, a.ccode2, a.ccode1)
    m = a.groupby("other").agree.mean()
    m.index = m.index.map(CCODE2ISO)
    return m.dropna()


unga_us_raw = pole_agreement(2)
unga_cn_raw = pole_agreement(710)


def minmax(s):
    return (s - s.min()) / (s.max() - s.min())


unga_us = minmax(unga_us_raw)
unga_cn = minmax(unga_cn_raw)

ipt = ip24.set_index("iso3c").idealpointfp
ideal_reldist = (ipt - ipt["USA"]).abs() - (ipt - ipt["CHN"]).abs()


def read_sipri(fname):
    txt = open(RAW / fname, encoding="utf8").read()
    lines = txt.splitlines()
    start = next(i for i, l in enumerate(lines) if l.startswith("Recipient,"))
    body = [l for l in lines[start:] if l.strip()]
    df = pd.read_csv(io.StringIO("\n".join(body)))
    total_col = next(c for c in df.columns if re.match(r"^\d{4}-\d{4}$", c))
    df = df[["Recipient", total_col]].rename(columns={total_col: "tiv"})
    df = df[~df.Recipient.str.contains(r"\*|Total", na=False)]
    df["iso3"] = df.Recipient.map(to_iso3)
    return df.dropna(subset=["iso3"]).set_index("iso3").tiv


arms_total = read_sipri("sipri_importexport_2020_2025.csv")
arms_us = read_sipri("sipri_from_USA_2020_2025.csv")
arms_cn = read_sipri("sipri_from_CHI_2020_2025.csv")
arms_ru = read_sipri("sipri_from_RUS_2020_2025.csv")

MIN_TIV = 50


def arms_share(from_pole):
    sh = (from_pole.reindex(arms_total.index).fillna(0) / arms_total).clip(0, 1)
    return sh[arms_total >= MIN_TIV]


arms_share_us = arms_share(arms_us)
arms_share_cn = arms_share(arms_cn)
arms_share_ru = arms_share(arms_ru)

dt = pd.read_csv(RAW / "dots_trade.csv")
dt = dt[dt.year.between(2022, 2024)]
dt["iso3"] = dt.ref_area.map(ISO2TO3)
dt = dt.dropna(subset=["iso3"])
piv = dt.pivot_table(index=["iso3", "year"], columns=["counterpart", "indicator"],
                     values="value", aggfunc="sum")


def trade_share(pole):
    x = piv.get((pole, "TXG_FOB_USD"), pd.Series(dtype=float))
    m = piv.get((pole, "TMG_CIF_USD"), pd.Series(dtype=float))
    xw = piv.get(("W00", "TXG_FOB_USD"), pd.Series(dtype=float))
    mw = piv.get(("W00", "TMG_CIF_USD"), pd.Series(dtype=float))
    tot = xw.add(mw, fill_value=0)
    with_p = x.reindex(tot.index).fillna(0).add(m.reindex(tot.index).fillna(0), fill_value=0)
    sh = (with_p / tot).groupby("iso3").mean().clip(0, 1)
    return (sh / 0.50).clip(0, 1)


trade_us = trade_share("US")
trade_cn = trade_share("CN")

tr = pd.read_csv(RAW / "us_troops_2022_2024.csv")
troops = tr.groupby("iso3c").troops_ad.mean()
troops = troops[troops >= 100]
troops_us = np.log10(troops) / np.log10(troops.max())
troops_us = troops_us.clip(0, 1)

TIES = pd.read_csv(paths.COUNTRIES / "ties.csv", dtype=str, keep_default_na=False)


def ties(pole, layer):
    t = TIES[(TIES.pole == pole) & (TIES.layer == layer)]
    return {iso: float(v) for iso, v in zip(t.iso3, t.value)}


US_ALLY, CN_ALLY = ties("us", "alliance"), ties("cn", "alliance")
US_HOSTILITY, CN_HOSTILITY = ties("us", "hostility"), ties("cn", "hostility")

W_UNGA = W_SEC = W_TRADE = 1 / 3

rows = []
for iso in sorted(UNIVERSE):
    r = {"iso3": iso}
    r["unga_us"] = unga_us.get(iso, np.nan);  r["unga_cn"] = unga_cn.get(iso, np.nan)
    r["unga_us_raw"] = unga_us_raw.get(iso, np.nan); r["unga_cn_raw"] = unga_cn_raw.get(iso, np.nan)
    r["arms_us"] = arms_share_us.get(iso, np.nan); r["arms_cn"] = arms_share_cn.get(iso, np.nan)
    r["arms_ru"] = arms_share_ru.get(iso, np.nan)
    r["trade_us"] = trade_us.get(iso, np.nan); r["trade_cn"] = trade_cn.get(iso, np.nan)
    r["troops_us"] = troops_us.get(iso, np.nan)
    r["ally_us"] = US_ALLY.get(iso, 0.0); r["ally_cn"] = CN_ALLY.get(iso, 0.0)
    r["host_us"] = US_HOSTILITY.get(iso, 0.0); r["host_cn"] = CN_HOSTILITY.get(iso, 0.0)
    r["ideal_reldist"] = ideal_reldist.get(iso, np.nan)

    def sub(parts):
        parts = [(w, v) for w, v in parts if not pd.isna(v)]
        if not parts: return np.nan
        tw = sum(w for w, _ in parts)
        return sum(w * v for w, v in parts) / tw
    sec_us = sub([(0.5, r["ally_us"]), (0.3, r["arms_us"]), (0.2, r["troops_us"])])
    sec_cn = sub([(0.6, r["ally_cn"]), (0.4, r["arms_cn"])])
    r["sec_us"], r["sec_cn"] = sec_us, sec_cn

    eng_us = sub([(W_UNGA, r["unga_us"]), (W_SEC, sec_us), (W_TRADE, r["trade_us"])])
    eng_cn = sub([(W_UNGA, r["unga_cn"]), (W_SEC, sec_cn), (W_TRADE, r["trade_cn"])])
    r["eng_us"], r["eng_cn"] = eng_us, eng_cn
    r["axis_us"] = (eng_us if not pd.isna(eng_us) else 0) - r["host_us"]
    r["axis_cn"] = (eng_cn if not pd.isna(eng_cn) else 0) - r["host_cn"]
    rows.append(r)

df = pd.DataFrame(rows).set_index("iso3")
complete_cols = ["unga_us", "sec_us", "trade_us", "unga_cn", "sec_cn", "trade_cn"]
df = df.dropna(subset=complete_cols).copy()
df["net_lean_us"] = df.axis_us - df.axis_cn

names = ip.dropna(subset=["iso3c"]).drop_duplicates("iso3c", keep="last").set_index("iso3c").countryname
names.loc["TWN"] = "Taiwan"; names.loc["XKX"] = "Kosovo"
PRETTY = {"DEU": "Germany", "SRB": "Serbia", "FSM": "Micronesia", "MMR": "Myanmar",
          "RUS": "Russia", "TZA": "Tanzania", "LAO": "Laos", "MDA": "Moldova",
          "BOL": "Bolivia", "VEN": "Venezuela", "IRN": "Iran", "SYR": "Syria",
          "PRK": "North Korea", "KOR": "South Korea", "VNM": "Vietnam", "CIV": "Ivory Coast",
          "STP": "Sao Tome and Principe"}
for k, v in PRETTY.items():
    names.loc[k] = v
df["name"] = names.reindex(df.index)

field = df.drop(index=["USA", "CHN"], errors="ignore")
mx, my = field.axis_us.median(), field.axis_cn.median()


def quad(r):
    if r.axis_us < 0 and r.axis_cn < 0: return "rival of both"
    if r.axis_us < 0: return "rival of the US"
    if r.axis_cn < 0: return "rival of China"
    hi_us, hi_cn = r.axis_us >= mx, r.axis_cn >= my
    if hi_us and not hi_cn: return "pro-US"
    if hi_cn and not hi_us: return "pro-China"
    if hi_us and hi_cn: return "hedger"
    return "non-aligned (low with both)"


df["quadrant"] = df.apply(quad, axis=1)

df = df.sort_values("net_lean_us", ascending=False)
out_cols = ["name", "axis_us", "axis_cn", "net_lean_us", "quadrant",
            "eng_us", "eng_cn", "host_us", "host_cn",
            "unga_us", "unga_cn", "unga_us_raw", "unga_cn_raw",
            "sec_us", "sec_cn", "ally_us", "ally_cn",
            "arms_us", "arms_cn", "arms_ru", "troops_us",
            "trade_us", "trade_cn", "ideal_reldist"]
df[out_cols].round(4).to_csv(paths.COUNTRIES / "alignment_axes.csv", encoding="utf-8-sig")


def strict_group(v):
    if v >= 0.45: return "ally_of_us"
    if v < -0.45: return "ally_of_china"
    if -0.15 <= v < 0.15: return "neutral"
    return None


groups = df.assign(group=df.net_lean_us.map(strict_group)).dropna(subset=["group"])
groups = groups.reset_index().sort_values(["group", "name"])
groups[["iso3", "name", "group", "axis_us", "axis_cn", "net_lean_us"]].round(4).to_csv(
    paths.COUNTRIES / "alignment_groups.csv", index=False, encoding="utf-8-sig")
